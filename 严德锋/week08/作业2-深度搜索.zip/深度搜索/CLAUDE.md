# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目

**深度研究助手（Deep Research Assistant）**——输入一个研究主题，自动完成规划 → 多轮检索 → 阅读抽取 → 综合，产出一份带来源引用的结构化研究报告。目标把市场/产品同学 2~3 小时的人工调研压缩到分钟级。

产品定位与输出形态详见 `README.md`（含报告四要素：结构化报告 / 来源列表 / 研究过程记录 / 置信度说明）。

## 技术栈（v1.1 已定）

| 层 | 选型 |
|---|---|
| 后端 | Python 3.11+ / FastAPI（async） |
| LLM 编排 | LangChain（4 个独立 AgentExecutor + 手动编排，**不用 LangGraph**）|
| LLM 模型 | Claude Sonnet 5（4 Agent 全程统一） |
| 搜索 | Bocha `web-search` API（**只用这一个端点**，不用 `ai-search`） |
| 流式 | SSE（FastAPI `StreamingResponse`） |
| 报告存储 | Markdown 文件（按 `run_id` 命名）+ SQLite 索引 |
| 前端 | Next.js 14+ App Router / TypeScript |
| 样式 | Tailwind CSS + shadcn/ui |
| PDF 导出 | weasyprint（HTML 中转）|
| DOCX 导出 | python-docx（手写 Markdown → DOCX 解析） |
| 日志 | loguru JSON + SQLite `event_log` 表 |
| 部署 | 本地双进程（uvicorn :8000 + next dev :3000）+ Docker Compose |

## Bocha 搜索 API

唯一外部依赖。基础信息：

```
POST https://api.bocha.cn/v1/web-search
Headers: Authorization: Bearer <KEY>, Content-Type: application/json
Body:   {"query": "...", "summary": true, "count": 10}
```

- **Key 管理**：`.env`（`BOCHA_API_KEY`）优先；缺失时回退到 README 里的开发 key（`sk-3d2293ad83aa4823a7c7ce8dd5ff8c72`）。`.env` 必须 `.gitignore`。
- **默认参数**：`summary=true`（返回 AI 摘要）、`count=10`
- **摘要阈值**：返回的 `summary` 字段 < 200 字或缺失 → 用 httpx + readability 全页面抓取补齐

## 多 Agent 架构

**核心约定**：4 个独立 Agent，每个有自己的 system prompt + 自己的 message history。`orchestrator.py` 串行编排，通过 `ResearchState` TypedDict 传递数据。**不引入 LangGraph**——直接用 LangChain `AgentExecutor` + 手动状态机。

| Agent | 文件 | 输入 | 输出 | 工具 |
|---|---|---|---|---|
| Planner | `agent/planner.py` | `{topic}` | `sub_questions: List[str]`（3~5 个） | 无 |
| Researcher | `agent/researcher.py` | `{topic, sub_question, round}` | `evidence: List[{url, title, summary, snippet}]` | `bocha_search` / `fetch_full_page` |
| Judge | `agent/judge.py` | `{topic, evidence_so_far, round}` | `{decision: "continue" \| "sufficient", refined_query?: str}` | 无 |
| Writer | `agent/writer.py` | `{topic, all_evidence}` | `report_markdown` | 无 |

**编排主流程**（`agent/orchestrator.py`）：

```
Planner(topic)                       → sub_questions
for each sub_question:
    accumulated_evidence = []
    for round in 1..5:
        Researcher(...)              → new_evidence
        accumulated_evidence += new_evidence
        Judge(...)                   → decision
        if decision == "sufficient": break
Writer(topic, all_evidence)          → report_markdown
save_markdown + insert_db
```

**关键不变量**：
- 每个子问题独立循环（一个子问题的「够」不影响另一个继续跑）
- 终止条件：≤5 轮上限 **或** Judge 返回 `sufficient`（满足任一即跳出）
- 终止判断由 Judge 独立完成，不让 Researcher 的搜索噪声污染

## SSE 事件 schema（前端契约）

只发**状态事件**，不流 LLM token。事件类型与归属 Agent：

| 事件 | 来自 | data 字段 |
|---|---|---|
| `sub_questions_generated` | Planner | `{questions: [...]}` |
| `search_started` | Researcher | `{round, query}` |
| `page_read` | Researcher | `{round, url, title, summary_length, fetched_full}` |
| `round_done` | Judge | `{round, decision}` |
| `synthesis_started` | Writer | `{total_rounds}` |
| `report_done` | Writer | `{report_id, report_markdown}` |
| `error` | 任意 | `{code, message}` |
| `done` | orchestrator | `{status: completed\|cancelled\|failed}` |

## 置信度算法（纯函数）

```
high   = 来源数 ≥3 AND 来源类型多样（域名集合 ≥3 个不同）
medium = 来源数 1~2
low    = 纯模型推断（无来源）
```

粒度：节级（每节一个综合置信度）+ 关键论断级（`[来源:3, 置信:高]` 或 `[模型推断]`）。

## 报告结构（半固定）

4 个章节必出，LLM 可在「分节正文」内自定子章节：

1. **摘要**（必出）
2. **分节正文**（按子问题组织）
3. **关键结论**（必出）
4. **遗留问题**（必出）

## 数据模型

**`researches`**：`id (UUID)` / `topic` / `status: pending|running|completed|failed|cancelled` / `created_at` / `updated_at` / `report_path` / `summary` / `total_rounds` / `error`

**`event_log`**：`id` / `run_id` (INDEX) / `event_type` / `payload (JSON)` / `created_at`

## 后端 API 端点（前端契约）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/research` | 启动研究 |
| GET | `/api/research/{run_id}/events` | SSE 流 |
| DELETE | `/api/research/{run_id}` | 取消（前端关 SSE 触发） |
| GET | `/api/reports?limit=50` | 历史列表 |
| GET | `/api/reports/{id}` | 单个报告元数据 |
| GET | `/api/reports/{id}/markdown` | 下载 .md |
| GET | `/api/reports/{id}/pdf` | 下载 .pdf |
| GET | `/api/reports/{id}/docx` | 下载 .docx |
| POST | `/api/reports/{id}/rerun` | 重跑（`overwrite` / `new`） |
| POST | `/api/reports/{id}/retry` | 重试失败 |

## 前端页面

- `/` 首页 / 新建研究：输入框 + 实时 SSE 进度面板
- `/history` 历史列表：主题 / 时间 / 状态 / 摘要前 100 字 + 行菜单（重跑/重试）
- `/report/[id]` 详情：Markdown 渲染 + 引用链接新窗口打开 + 三按钮导出组（MD/PDF/DOCX）+ 底部「研究日志」折叠区

## 并发与取消

- **多任务并行**：每个 SSE 连接一个独立 `asyncio.create_task`，互不干扰
- **取消**：前端「停止」按钮触发 `DELETE /api/research/{id}`，后端用 `asyncio.CancelledError` 自然中断，状态标记 `cancelled`

## 测试

- **范围**：纯函数（`confidence.py` / `bocha.py` / `fetcher.py` / `exporters/*` / `event_log.py`）写 pytest 单测；agent 循环跑 1~2 个 happy-path 冒烟（mock LLM + mock Bocha）
- **不过度工程**：不写完整集成测试套件

## 不做清单（明确排除）

不要把这些「增量」加进代码，除非用户明确要求：

- ❌ 用户系统 / 登录 / 权限 / 鉴权
- ❌ 分享报告链接 / 公网可访问
- ❌ 多语言切换（默认中文 UI + 中文报告）
- ❌ 实时 token 计费 / 成本面板
- ❌ LangGraph / LangSmith / 其他 agent 编排框架
- ❌ Bocha `ai-search` 端点（只用 `web-search`）
- ❌ 模型分级（Haiku 拆问题 + Sonnet 综合这种）—— 全程 Sonnet 5

## 开发约定

- 后端 `agent/` 目录下每个 Agent 一个文件（planner/researcher/judge/writer/orchestrator），不要把多个 Agent 塞进同一个文件
- 工具（`bocha_search` / `fetch_full_page`）只在 `tools/` 定义，Agent 通过 LangChain tool 机制调用，不要在 Agent 内直接 `httpx.post`
- 置信度算法是纯函数，**禁止**在 Writer prompt 里让 LLM 自己判断置信度
- 报告 Markdown 落盘路径：`reports/{YYYY-MM-DD}/{run_id}.md`
- 前端 SSE 用原生 `EventSource`，不引入额外 SSE 客户端库

## 命令（待骨架完成后补充）

代码尚未生成。`backend/pyproject.toml` 和 `frontend/package.json` 出现后，按以下预期补全（仅作占位，实际以生成的文件为准）：

- 后端启动：`cd backend && uvicorn app.main:app --reload --port 8000`
- 前端启动：`cd frontend && npm run dev`
- 测试：`cd backend && pytest`
- 一键启动：`docker compose up`