# 深度研究助手（Deep Research Assistant）

输入一个研究主题，自动完成 **规划 → 多轮检索 → 阅读抽取 → 综合**，产出一份带来源引用的结构化研究报告。

技术架构：**Python (FastAPI + LangChain) 后端** + **Next.js (App Router) 前端** + **Bocha 搜索 API** + **Claude Sonnet 5**。

---

## 快速开始

### 选项 A：Docker Compose（推荐）

```bash
# 1. 配置环境变量（可选 — 缺失时使用 README 兜底 key）
cp .env.example .env
# 编辑 .env，至少设置 ANTHROPIC_API_KEY

# 2. 一键启动
docker compose up --build

# 3. 浏览器访问
# 前端：http://localhost:3000
# 后端：http://localhost:8000/docs（OpenAPI）
```

数据 & 报告自动持久化到 `backend/data/` 与 `backend/reports/`，重启容器不丢。

### 选项 B：本地双进程开发

需要 Python 3.11+ 与 Node.js 20+。

#### 后端

```bash
cd backend
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -e .
cp .env.example .env         # 可选

uvicorn app.main:app --reload --port 8000
```

#### 前端

```bash
cd frontend
npm install
npm run dev                  # 起 3000 端口
```

`next.config.js` 已配置 `/api/*` 自动 rewrite 到 `http://localhost:8000`，无需后端 CORS 配置（兜底 origin 是 `http://localhost:3000`）。

---

## 环境变量

| 变量 | 必填 | 说明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ | Claude API key。所有 Agent 都用 Sonnet 5 |
| `BOCHA_API_KEY` | ⚠️ 可选 | 缺失时兜底使用 README 的开发 key（仅供本地调试） |
| `DB_PATH` | ❌ | SQLite 数据库路径，默认 `backend/data/research.db` |
| `REPORTS_DIR` | ❌ | Markdown 报告落盘目录，默认 `backend/reports/` |
| `CORS_ORIGINS` | ❌ | 允许的前端 origin 列表，默认 `["http://localhost:3000"]` |
| `LLM_MODEL` | ❌ | 默认 `claude-sonnet-5` |
| `MAX_ROUNDS_PER_SUBQUESTION` | ❌ | 每个子问题最大检索轮数，默认 5 |
| `SUMMARY_MIN_LENGTH` | ❌ | Bocha summary 长度阈值（< 此值触发全页面抓取），默认 200 |

---

## 项目结构

```
深度搜索/
├── backend/                       # FastAPI + LangChain
│   ├── app/
│   │   ├── main.py                # FastAPI 入口
│   │   ├── settings.py            # .env + README key 兜底
│   │   ├── logging_config.py      # loguru JSON
│   │   ├── models.py              # Pydantic 模型
│   │   ├── routes/                # /api/research/* 与 /api/reports/*
│   │   ├── agent/                 # 4 个独立 Agent + orchestrator
│   │   │   ├── planner.py         # 主题 → 3-5 子问题
│   │   │   ├── researcher.py      # 子问题 → 下一轮搜索 query
│   │   │   ├── judge.py           # 证据是否足够
│   │   │   ├── writer.py          # 全部证据 → 最终 Markdown
│   │   │   ├── orchestrator.py    # 主循环
│   │   │   ├── confidence.py      # 置信度（纯函数）
│   │   │   └── state.py           # 状态 helper
│   │   ├── tools/                 # 工具层
│   │   │   ├── bocha.py           # Bocha API 客户端
│   │   │   ├── fetcher.py         # httpx + readability 全页面抓取
│   │   │   └── search.py          # Bocha + 兜底 fetch 包装
│   │   ├── exporters/             # 导出
│   │   │   ├── markdown.py        # 落盘 reports/{date}/{id}.md
│   │   │   ├── pdf.py             # markdown → weasyprint PDF
│   │   │   └── docx.py            # markdown → python-docx
│   │   └── storage/               # SQLite + event_log
│   ├── tests/                     # pytest 套件（80+ 测试）
│   ├── pyproject.toml
│   ├── Dockerfile
│   └── .env.example
├── frontend/                      # Next.js 14 App Router
│   ├── app/
│   │   ├── layout.tsx             # 根布局 + 全局导航
│   │   ├── page.tsx               # 首页：输入框 + 实时 SSE 进度
│   │   ├── history/page.tsx       # 历史报告列表
│   │   ├── report/[id]/page.tsx   # 详情：Markdown 渲染 + 3 导出按钮 + 日志折叠
│   │   └── globals.css            # Tailwind + 主题变量 + Markdown 样式
│   ├── components/ui/             # shadcn 风格基础组件（手写，无 CLI）
│   ├── lib/                       # api / sse / types / utils
│   ├── package.json
│   ├── tailwind.config.ts
│   ├── next.config.js             # /api/* → backend rewrite
│   └── Dockerfile
├── docker-compose.yml
├── README.md                      # ← 你正在读的
├── CLAUDE.md                      # AI 协作约定
└── .env.example                   # compose 用 env 模板
```

---

## 4 Agent 架构

每个 Agent 独立 system prompt + 独立 message history。`orchestrator.py` 串行编排。

| Agent | 输入 | 输出 | 工具 |
|---|---|---|---|
| **Planner** | `{topic}` | 3-5 子问题 | 无 |
| **Researcher** | `{topic, sub_question, round}` | 下一轮 query + stop 信号 | `bocha_search` / `fetch_full_page` |
| **Judge** | `{topic, sub_question, evidence}` | sufficient / continue + 可选 refined_query | 无 |
| **Writer** | `{topic, all_evidence}` | 最终 Markdown 报告 | 无 |

主循环：

```
Planner(topic)                          → sub_questions
for each sub_question:
    for round in 1..5:
        Researcher → next_query
        search_fn(next_query)           → new evidence
        Judge → sufficient / continue
        if sufficient: break
Writer(all evidence)                    → report Markdown
save Markdown + 更新 SQLite
```

---

## SSE 事件 schema（前端契约）

| 事件 | 来自 | data 字段 |
|---|---|---|
| `started` | route | `{topic}` |
| `sub_questions_generated` | Planner | `{questions: [...]}` |
| `search_started` | Researcher | `{round, query, sub_index}` |
| `page_read` | Researcher | `{round, url, title, summary_length, fetched_full}` |
| `round_done` | Judge | `{round, decision, reason}` |
| `synthesis_started` | Writer | `{total_sub_questions}` |
| `report_done` | Writer | `{report_id, report_markdown}` |
| `error` | orchestrator | `{code, message}` |
| `done` | route | `{status: completed\|cancelled\|failed}` |

SSE 流终止条件：收到 `done` 或 `error`。

---

## API 端点

| 方法 | 路径 | 说明 |
|---|---|---|
| `POST` | `/api/research` | 启动研究，body `{topic}`，返回 `{run_id}` |
| `GET` | `/api/research/{run_id}/events` | SSE 实时事件流 |
| `DELETE` | `/api/research/{run_id}` | 取消正在运行的研究 |
| `GET` | `/api/reports?limit=50` | 历史报告列表 |
| `GET` | `/api/reports/{id}` | 单个报告详情（含 events） |
| `GET` | `/api/reports/{id}/markdown` | 下载 .md |
| `GET` | `/api/reports/{id}/pdf` | 下载 .pdf（503 on Windows 无 libpango） |
| `GET` | `/api/reports/{id}/docx` | 下载 .docx |
| `POST` | `/api/reports/{id}/rerun?mode=new\|overwrite` | 重跑 |
| `POST` | `/api/reports/{id}/retry` | 重试 failed/cancelled |

---

## 测试

后端 pytest 套件覆盖纯函数 + Agent smoke + 路由：

```bash
cd backend
pytest -v
```

预期：~80 通过，1 跳过（仅 Linux 跑的 PDF 集成测试）。

---

## 已知限制 / 不做清单

明确不做（v1.1 范围外）：

- ❌ 用户系统 / 登录 / 权限
- ❌ 分享报告链接 / 公网可访问
- ❌ 多语言切换（默认中文）
- ❌ 实时 token 计费 / 成本面板
- ❌ LangGraph（用 LangChain 手写循环）
- ❌ Bocha `ai-search` 端点（只用 `web-search`）
- ❌ 模型分级（全程 Sonnet 5）
- ❌ PDF 在 Windows 裸环境（需 libpango，Docker 内正常）

---

## 常见问题

**Q：研究跑多久？**
A：每个子问题 ≤5 轮检索 + 1 次综合生成。3-5 个子问题通常 30 秒 ~ 3 分钟，取决于 LLM 响应速度。

**Q：取消后能继续吗？**
A：当前不能「续跑」。取消/失败后可点详情页「重试」，从零重跑同主题。

**Q：报告存哪里？**
A：Markdown 落 `backend/reports/{YYYY-MM-DD}/{run_id}.md`，元数据进 `backend/data/research.db`。容器化时通过 volume 持久化。

**Q：怎么换 LLM 模型？**
A：改 `LLM_MODEL` 环境变量（如 `claude-opus-5`）。所有 4 Agent 共享同模型。

**Q：为什么用 SSE 而不是 WebSocket？**
A：研究过程是后端单向推流，SSE 一行 `EventSource` 就能接住，比 WebSocket 少一半代码。