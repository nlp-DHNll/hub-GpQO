"use client";

import { useState, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CollapsibleProps {
  trigger: ReactNode;
  children: ReactNode;
  defaultOpen?: boolean;
  className?: string;
}

export function Collapsible({ trigger, children, defaultOpen = false, className }: CollapsibleProps) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={cn("border rounded-md", className)}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-4 py-2 text-sm font-medium hover:bg-accent"
      >
        {trigger}
        <span className="text-muted-foreground">{open ? "▼" : "▶"}</span>
      </button>
      {open && <div className="border-t p-4">{children}</div>}
    </div>
  );
}