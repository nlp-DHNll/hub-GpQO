export type ResearchStatus = "pending" | "running" | "completed" | "failed" | "cancelled";

export interface ResearchSummary {
  id: string;
  topic: string;
  status: ResearchStatus;
  created_at: string;
  updated_at: string;
  summary: string;
  total_rounds: number;
  error?: string | null;
}

export interface EventLogEntry {
  event_type: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface ResearchDetail extends ResearchSummary {
  report_path: string | null;
  events: EventLogEntry[];
}

export interface StartResearchResponse {
  run_id: string;
}

export type SSEEvent =
  | { event: "started"; data: { topic: string } }
  | { event: "sub_questions_generated"; data: { questions: string[] } }
  | { event: "search_started"; data: { round: number; query: string; sub_index: number } }
  | { event: "page_read"; data: { round: number; url: string; title: string; summary_length: number; fetched_full: boolean } }
  | { event: "round_done"; data: { round: number; decision: string; reason: string } }
  | { event: "synthesis_started"; data: { total_sub_questions: number } }
  | { event: "report_done"; data: { report_id: string; report_markdown: string } }
  | { event: "error"; data: { code: string; message: string } }
  | { event: "done"; data: { status: string } };