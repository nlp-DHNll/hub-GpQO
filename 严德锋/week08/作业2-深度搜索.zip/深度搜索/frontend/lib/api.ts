/** 与后端的 fetch 封装。所有路径都是相对的（next.config.js 把 /api/* rewrite 到后端）。 */
import type { ResearchDetail, ResearchSummary, StartResearchResponse } from "./types";

export async function startResearch(topic: string): Promise<StartResearchResponse> {
  const r = await fetch("/api/research", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ topic }),
  });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`启动研究失败: ${r.status} ${body}`);
  }
  return r.json();
}

export async function cancelResearch(runId: string): Promise<void> {
  await fetch(`/api/research/${runId}`, { method: "DELETE" });
}

export async function listReports(limit = 50): Promise<ResearchSummary[]> {
  const r = await fetch(`/api/reports?limit=${limit}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`list reports failed: ${r.status}`);
  return r.json();
}

export async function getReport(id: string): Promise<ResearchDetail> {
  const r = await fetch(`/api/reports/${id}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`get report failed: ${r.status}`);
  return r.json();
}

export function downloadUrl(id: string, format: "markdown" | "pdf" | "docx"): string {
  return `/api/reports/${id}/${format}`;
}

export async function rerunReport(id: string, mode: "new" | "overwrite"): Promise<{ run_id: string }> {
  const r = await fetch(`/api/reports/${id}/rerun?mode=${mode}`, { method: "POST" });
  if (!r.ok) throw new Error(`rerun failed: ${r.status}`);
  return r.json();
}

export async function retryReport(id: string): Promise<{ run_id: string }> {
  const r = await fetch(`/api/reports/${id}/retry`, { method: "POST" });
  if (!r.ok) throw new Error(`retry failed: ${r.status}`);
  return r.json();
}