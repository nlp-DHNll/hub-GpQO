/** SSE 客户端：包装 EventSource，按 event 类型回调。
 *
 * 用法：
 *   const conn = connectSSE("/api/research/abc/events", {
 *     onSearchStarted: (data) => ...,
 *     onDone: (data) => { conn.close(); },
 *   });
 */
"use client";

import type { SSEEvent } from "./types";

type EventHandlers = {
  [K in SSEEvent["event"]]?: (data: Extract<SSEEvent, { event: K }>["data"]) => void;
};

export function connectSSE(url: string, handlers: EventHandlers): {
  close: () => void;
} {
  const es = new EventSource(url);

  // 为每种事件类型注册监听
  (Object.keys(handlers) as Array<SSEEvent["event"]>).forEach((eventName) => {
    const fn = handlers[eventName];
    if (!fn) return;
    es.addEventListener(eventName, (ev) => {
      try {
        const data = JSON.parse((ev as MessageEvent).data);
        (fn as (d: unknown) => void)(data);
      } catch (e) {
        console.error(`SSE parse failed for ${eventName}:`, e);
      }
    });
  });

  es.onerror = (e) => {
    console.error("SSE error:", e);
    // EventSource 会自动重连；这里只 log
  };

  return {
    close: () => es.close(),
  };
}