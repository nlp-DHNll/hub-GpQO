/** Tailwind class merge helper — 简化 cn() 实现，不引 clsx/tailwind-merge 依赖。 */
export function cn(...classes: (string | false | null | undefined)[]): string {
  return classes.filter(Boolean).join(" ");
}