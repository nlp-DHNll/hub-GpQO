import Link from "next/link";
import { notFound } from "next/navigation";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import { getReport, downloadUrl, rerunReport, retryReport } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible } from "@/components/ui/collapsible";
import type { ResearchStatus } from "@/lib/types";

const statusBadge: Record<
  ResearchStatus,
  "success" | "info" | "danger" | "warning" | "secondary"
> = {
  pending: "secondary",
  running: "info",
  completed: "success",
  failed: "danger",
  cancelled: "warning",
};

const statusLabel: Record<ResearchStatus, string> = {
  pending: "待开始",
  running: "运行中",
  completed: "完成",
  failed: "失败",
  cancelled: "已取消",
};

export const dynamic = "force-dynamic";

async function rerunAction(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const mode = (formData.get("mode") as "new" | "overwrite") || "new";
  await rerunReport(id, mode);
}

async function retryAction(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  await retryReport(id);
}

export default async function ReportPage({ params }: { params: { id: string } }) {
  let report;
  try {
    report = await getReport(params.id);
  } catch {
    notFound();
  }

  return (
    <div className="space-y-6">
      {/* 顶部：标题 + 导出按钮 */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <Link
            href="/history"
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            ← 返回历史
          </Link>
          <h1 className="mt-2 text-3xl font-bold break-words">{report.topic}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <Badge variant={statusBadge[report.status]}>
              {statusLabel[report.status]}
            </Badge>
            <span>·</span>
            <span>{new Date(report.created_at).toLocaleString()}</span>
            <span>·</span>
            <span>{report.total_rounds} 轮</span>
            {report.report_path && (
              <>
                <span>·</span>
                <span className="font-mono text-xs">{report.report_path}</span>
              </>
            )}
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="flex flex-wrap gap-2">
            <a href={downloadUrl(report.id, "markdown")} download>
              <Button>Markdown</Button>
            </a>
            <a href={downloadUrl(report.id, "pdf")} download>
              <Button variant="outline">PDF</Button>
            </a>
            <a href={downloadUrl(report.id, "docx")} download>
              <Button variant="outline">DOCX</Button>
            </a>
          </div>
          <div className="flex gap-2">
            <form action={rerunAction}>
              <input type="hidden" name="id" value={report.id} />
              <input type="hidden" name="mode" value="new" />
              <Button variant="ghost" size="sm" type="submit">
                重跑（新 ID）
              </Button>
            </form>
            {(report.status === "failed" || report.status === "cancelled") && (
              <form action={retryAction}>
                <input type="hidden" name="id" value={report.id} />
                <Button variant="ghost" size="sm" type="submit">
                  重试
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>

      {report.error && (
        <Card>
          <CardContent className="pt-6 text-sm text-red-600">
            错误：{report.error}
          </CardContent>
        </Card>
      )}

      {/* 报告正文 */}
      <Card>
        <CardContent className="pt-6 prose max-w-none">
          {report.report_path ? (
            <ReportBody reportPath={report.report_path} />
          ) : (
            <p className="text-muted-foreground">
              研究尚未完成或报告未生成。
            </p>
          )}
        </CardContent>
      </Card>

      {/* 研究日志折叠区 */}
      <Collapsible trigger={`研究日志（${report.events.length} 条）`}>
        <ul className="space-y-1 text-xs font-mono">
          {report.events.map((e, i) => (
            <li key={i} className="flex gap-2">
              <span className="text-muted-foreground shrink-0">
                {new Date(e.created_at).toLocaleTimeString()}
              </span>
              <span className="font-semibold shrink-0 w-32 truncate">
                {e.event_type}
              </span>
              <span className="text-muted-foreground truncate">
                {JSON.stringify(e.payload).slice(0, 100)}
              </span>
            </li>
          ))}
        </ul>
      </Collapsible>
    </div>
  );
}

async function ReportBody({ reportPath }: { reportPath: string }) {
  // 服务端 fetch 后端 markdown 文件
  let markdown = "";
  try {
    const r = await fetch(
      `${process.env.BACKEND_URL || "http://localhost:8000"}/api/reports/${
        reportPath.split("/").pop()?.replace(".md", "") || ""
      }/markdown`,
      { cache: "no-store" },
    );
    if (r.ok) markdown = await r.text();
  } catch {
    markdown = "_（无法加载报告内容）_";
  }
  return <ReactMarkdown remarkPlugins={[remarkGfm]}>{markdown}</ReactMarkdown>;
}