"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { startResearch, cancelResearch } from "@/lib/api";
import { connectSSE } from "@/lib/sse";

interface ProgressEvent {
  type: string;
  data: Record<string, unknown>;
  ts: number;
}

type RunStatus = "idle" | "running" | "done" | "error";

export default function Home() {
  const router = useRouter();
  const [topic, setTopic] = useState("");
  const [runId, setRunId] = useState<string | null>(null);
  const [status, setStatus] = useState<RunStatus>("idle");
  const [events, setEvents] = useState<ProgressEvent[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [subQuestions, setSubQuestions] = useState<string[]>([]);

  function pushEvent(type: string, data: Record<string, unknown> = {}) {
    setEvents((prev) => [...prev, { type, data, ts: Date.now() }]);
  }

  async function handleStart() {
    if (!topic.trim() || status === "running") return;
    setEvents([]);
    setErrorMsg(null);
    setSubQuestions([]);
    setStatus("running");

    try {
      const { run_id } = await startResearch(topic);
      setRunId(run_id);

      connectSSE(`/api/research/${run_id}/events`, {
        started: (d) => pushEvent("started", d),
        sub_questions_generated: (d) => {
          pushEvent("sub_questions_generated", d);
          setSubQuestions(d.questions);
        },
        search_started: (d) => pushEvent("search_started", d),
        page_read: (d) => pushEvent("page_read", d),
        round_done: (d) => pushEvent("round_done", d),
        synthesis_started: (d) => pushEvent("synthesis_started", d),
        report_done: (d) => pushEvent("report_done", d),
        error: (d) => {
          pushEvent("error", d);
          setErrorMsg(d.message);
        },
        done: (d) => {
          pushEvent("done", d);
          setStatus("done");
          // 1.5 秒后跳详情
          setTimeout(() => router.push(`/report/${run_id}`), 1500);
        },
      });
    } catch (e) {
      setErrorMsg(String(e));
      setStatus("error");
    }
  }

  async function handleCancel() {
    if (!runId) return;
    try {
      await cancelResearch(runId);
    } catch (e) {
      console.error("cancel failed:", e);
    }
    setStatus("idle");
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>新建研究</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            placeholder="输入要研究的主题，例如：中国新能源汽车市场"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            disabled={status === "running"}
            onKeyDown={(e) => {
              if (e.key === "Enter" && status !== "running") handleStart();
            }}
          />
          <div className="flex items-center gap-3">
            {status === "running" ? (
              <Button variant="destructive" onClick={handleCancel}>
                停止
              </Button>
            ) : (
              <Button onClick={handleStart} disabled={!topic.trim()}>
                开始研究
              </Button>
            )}
            <Badge
              variant={
                status === "running"
                  ? "info"
                  : status === "done"
                    ? "success"
                    : status === "error"
                      ? "danger"
                      : "secondary"
              }
            >
              {status === "idle"
                ? "就绪"
                : status === "running"
                  ? "运行中"
                  : status === "done"
                    ? "完成"
                    : "错误"}
            </Badge>
            {errorMsg && <span className="text-sm text-red-600">错误：{errorMsg}</span>}
          </div>
        </CardContent>
      </Card>

      {subQuestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">子问题</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-decimal pl-5 space-y-1 text-sm">
              {subQuestions.map((q, i) => (
                <li key={i}>{q}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {events.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">研究过程（最近 30 条）</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1 text-xs font-mono">
              {events.slice(-30).map((e, i) => (
                <li key={i} className="flex gap-2">
                  <span className="text-muted-foreground shrink-0">
                    {new Date(e.ts).toLocaleTimeString()}
                  </span>
                  <span className="font-semibold shrink-0 w-32 truncate">{e.type}</span>
                  <span className="text-muted-foreground truncate">{summarize(e.type, e.data)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {status === "done" && runId && (
        <Card>
          <CardContent className="pt-6">
            <Link href={`/report/${runId}`} className="text-primary underline">
              查看完整报告 →
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function summarize(type: string, data: Record<string, unknown>): string {
  switch (type) {
    case "search_started":
      return `round=${data.round} q="${data.query}"`;
    case "page_read":
      return `${data.title} (${data.summary_length}字)`;
    case "round_done":
      return `round=${data.round} → ${data.decision}`;
    case "sub_questions_generated":
      return `${(data.questions as string[]).length} 个子问题`;
    case "report_done":
      return `report_id=${data.report_id}`;
    case "done":
      return `status=${data.status}`;
    default:
      return JSON.stringify(data).slice(0, 80);
  }
}