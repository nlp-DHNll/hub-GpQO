import Link from "next/link";
import { listReports } from "@/lib/api";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { ResearchStatus } from "@/lib/types";

const statusBadge: Record<
  ResearchStatus,
  "success" | "info" | "danger" | "warning" | "secondary"
> = {
  pending: "secondary",
  running: "info",
  completed: "success",
  failed: "danger",
  cancelled: "warning",
};

const statusLabel: Record<ResearchStatus, string> = {
  pending: "待开始",
  running: "运行中",
  completed: "完成",
  failed: "失败",
  cancelled: "已取消",
};

export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  let reports: Awaited<ReturnType<typeof listReports>> = [];
  let error: string | null = null;
  try {
    reports = await listReports();
  } catch (e) {
    error = String(e);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">历史报告</h1>
        <Link href="/">
          <Button>新建研究</Button>
        </Link>
      </div>

      {error && (
        <p className="text-sm text-red-600">加载失败：{error}</p>
      )}

      {reports.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            还没有任何研究。点击「新建研究」开始第一次。
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {reports.map((r) => (
            <Card key={r.id}>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base truncate">{r.topic}</CardTitle>
                    <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                      {r.summary || "（无摘要）"}
                    </p>
                    <p className="mt-2 text-xs text-muted-foreground">
                      {new Date(r.created_at).toLocaleString()} ·{" "}
                      {r.total_rounds} 轮检索
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <Badge variant={statusBadge[r.status]}>
                      {statusLabel[r.status]}
                    </Badge>
                    <Link
                      href={`/report/${r.id}`}
                      className="text-sm text-primary underline"
                    >
                      查看
                    </Link>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}