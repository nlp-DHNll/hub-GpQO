"""exporter 单测：PDF / DOCX / Markdown。

DOCX 在所有平台都应通过（纯 Python）。
PDF 依赖 weasyprint + 系统库，Windows 裸环境通常不可用——测试做条件断言：
- 可用时：bytes 起始 4 字节为 b"%PDF"
- 不可用时：抛 RuntimeError 含 "weasyprint" 字样
"""
from __future__ import annotations

import pytest

from app.exporters import docx as docx_exporter
from app.exporters import markdown as md_exporter
from app.exporters import pdf as pdf_exporter


SAMPLE_MD = """# 标题 H1

这是引言段落。

## 子标题 H2

- 列表项 1
- 列表项 2
- 列表项 3

### 三级标题

1. 有序 1
2. 有序 2

> 引用块内容。

---

最后一段。
"""


# ---- markdown ----

def test_markdown_save_and_summary_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("REPORTS_DIR", str(tmp_path))
    from app.settings import get_settings
    get_settings.cache_clear()
    path = md_exporter.save_report("r1", SAMPLE_MD)
    assert path.exists()
    assert path.read_text(encoding="utf-8") == SAMPLE_MD


def test_markdown_extract_summary():
    md_with_summary = """## 摘要\n\n这是摘要内容。\n\n## 正文\n\n略。"""
    s = md_exporter.extract_summary(md_with_summary, max_chars=50)
    assert "摘要" in s
    assert "略" not in s


# ---- PDF ----

def test_pdf_availability_reported():
    """无论是否可用，is_available 应返回 bool。"""
    result = pdf_exporter.is_available()
    assert isinstance(result, bool)


def test_pdf_handles_unavailable_gracefully():
    """如果 weasyprint 不可用，调用应抛 RuntimeError 含安装提示。"""
    if pdf_exporter.is_available():
        pytest.skip("weasyprint available on this platform")
    with pytest.raises(RuntimeError) as exc:
        pdf_exporter.markdown_to_pdf(SAMPLE_MD)
    assert "weasyprint" in str(exc.value).lower() or "system" in str(exc.value).lower()


@pytest.mark.skipif(
    not __import__("os").environ.get("CI_WEASYPRINT")
    and not __import__("sys").platform.startswith("linux"),
    reason="weasyprint usually needs Linux/macOS system libs",
)
def test_pdf_generates_valid_pdf_bytes():
    """在 Linux/Docker 或 CI 上验证 PDF 输出。"""
    if not pdf_exporter.is_available():
        pytest.skip("weasyprint not available")
    pdf_bytes = pdf_exporter.markdown_to_pdf(SAMPLE_MD)
    assert pdf_bytes[:4] == b"%PDF"
    assert len(pdf_bytes) > 1000


# ---- DOCX ----

def test_docx_generates_valid_bytes():
    """DOCX 是 zip，bytes 起始为 'PK'。"""
    docx_bytes = docx_exporter.markdown_to_docx(SAMPLE_MD)
    assert isinstance(docx_bytes, bytes)
    assert len(docx_bytes) > 500
    # zip 文件 magic
    assert docx_bytes[:2] == b"PK"


def test_docx_contains_sample_content():
    """DOCX 解压后应包含 SAMPLE_MD 中的文本。"""
    import io
    import zipfile

    docx_bytes = docx_exporter.markdown_to_docx(SAMPLE_MD)
    with zipfile.ZipFile(io.BytesIO(docx_bytes)) as zf:
        with zf.open("word/document.xml") as f:
            xml_content = f.read().decode("utf-8")
    # 标题与列表项应进入 XML
    assert "标题 H1" in xml_content
    assert "子标题 H2" in xml_content
    assert "列表项 1" in xml_content
    assert "引用块内容" in xml_content


def test_docx_handles_empty_input():
    docx_bytes = docx_exporter.markdown_to_docx("")
    assert docx_bytes[:2] == b"PK"


def test_docx_handles_only_whitespace():
    docx_bytes = docx_exporter.markdown_to_docx("\n\n   \n\n")
    assert docx_bytes[:2] == b"PK"


def test_docx_paragraphs_merged():
    """连续非空行应合并为一个段落。"""
    md = """第一段第一行
第一段第二行
第一段第三行

第二段"""
    import io
    import zipfile
    docx_bytes = docx_exporter.markdown_to_docx(md)
    with zipfile.ZipFile(io.BytesIO(docx_bytes)) as zf:
        xml = zf.open("word/document.xml").read().decode("utf-8")
    # 两段：合并后的「第一段...」 + 「第二段」
    assert "第一段第一行" in xml and "第一段第二行" in xml
    assert "第二段" in xml