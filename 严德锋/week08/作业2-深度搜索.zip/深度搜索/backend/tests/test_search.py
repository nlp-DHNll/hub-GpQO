"""search.py 单测：验证 Bocha + fetcher 兜底逻辑。

mock 掉 bocha.search 与 fetcher.fetch_full_page，验证：
- summary 足够长时直接用 summary
- summary 太短时调 fetcher 抓全页面
- summary 缺失时用 snippet
- 都没有时跳过该条
- 全部失败时返回空列表
"""
from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from app.tools import bocha
from app.tools.search import search_with_fallback


def _br(url: str, summary: str = "", snippet: str = "", domain: str = "") -> bocha.BochaResult:
    return bocha.BochaResult(
        url=url,
        title=f"title of {url}",
        snippet=snippet,
        summary=summary,
        source_domain=domain or url.split("/")[2] if "://" in url else "",
    )


@pytest.mark.asyncio
async def test_uses_long_summary_directly():
    """summary >= min_length 不调 fetcher。"""
    long_summary = "x" * 300
    br = _br("https://a.com/x", summary=long_summary, domain="a.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[br])):
        with patch("app.tools.search.fetcher.fetch_full_page", AsyncMock()) as mock_fetch:
            evidence = await search_with_fallback("q")

    assert len(evidence) == 1
    assert evidence[0].summary == long_summary
    assert evidence[0].fetched_full is False
    mock_fetch.assert_not_called()


@pytest.mark.asyncio
async def test_falls_back_to_fetch_when_summary_too_short():
    """summary 太短时调 fetcher。"""
    short_summary = "too short"
    br = _br("https://a.com/x", summary=short_summary, domain="a.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[br])):
        with patch(
            "app.tools.search.fetcher.fetch_full_page",
            AsyncMock(return_value="这是从原始页面抓取的长文本。" * 30),
        ) as mock_fetch:
            evidence = await search_with_fallback("q")

    assert len(evidence) == 1
    assert evidence[0].fetched_full is True
    assert "从原始页面抓取" in evidence[0].summary
    mock_fetch.assert_called_once_with("https://a.com/x")


@pytest.mark.asyncio
async def test_uses_snippet_when_summary_missing():
    """summary 缺失时用 snippet。"""
    br = _br("https://a.com/x", summary="", snippet="a snippet long enough " * 20, domain="a.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[br])):
        with patch("app.tools.search.fetcher.fetch_full_page", AsyncMock()) as mock_fetch:
            evidence = await search_with_fallback("q")

    assert len(evidence) == 1
    assert evidence[0].summary == "a snippet long enough " * 20
    mock_fetch.assert_not_called()


@pytest.mark.asyncio
async def test_skips_items_with_no_summary_and_no_snippet():
    """summary 与 snippet 都为空时跳过。"""
    br = _br("https://a.com/x", summary="", snippet="", domain="a.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[br])):
        with patch("app.tools.search.fetcher.fetch_full_page", AsyncMock(return_value="")):
            evidence = await search_with_fallback("q")

    assert evidence == []


@pytest.mark.asyncio
async def test_returns_empty_when_bocha_returns_empty():
    """Bocha 返回空时直接空列表，不调 fetcher。"""
    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[])):
        with patch("app.tools.search.fetcher.fetch_full_page", AsyncMock()) as mock_fetch:
            evidence = await search_with_fallback("q")

    assert evidence == []
    mock_fetch.assert_not_called()


@pytest.mark.asyncio
async def test_keeps_summary_when_fetch_fails():
    """summary 太短 + fetcher 抓取失败时，仍保留原 short summary。"""
    short_summary = "too short"
    br = _br("https://a.com/x", summary=short_summary, domain="a.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[br])):
        with patch("app.tools.search.fetcher.fetch_full_page", AsyncMock(return_value="")):
            evidence = await search_with_fallback("q")

    assert len(evidence) == 1
    assert evidence[0].summary == short_summary
    assert evidence[0].fetched_full is False


@pytest.mark.asyncio
async def test_fetches_only_short_summaries_in_mixed_batch():
    """混合批次里只对 short summary 调 fetcher。"""
    long = _br("https://long.com/x", summary="x" * 300, domain="long.com")
    short = _br("https://short.com/x", summary="short", domain="short.com")
    missing = _br("https://missing.com/x", summary="", snippet="snippet " * 30, domain="missing.com")

    with patch("app.tools.search.bocha.search", AsyncMock(return_value=[long, short, missing])):
        with patch(
            "app.tools.search.fetcher.fetch_full_page",
            AsyncMock(return_value="fetched " * 50),
        ) as mock_fetch:
            evidence = await search_with_fallback("q")

    assert len(evidence) == 3
    # 只有 short.com 被 fetch
    mock_fetch.assert_called_once_with("https://short.com/x")
    fetched_flags = {e.source_domain: e.fetched_full for e in evidence}
    assert fetched_flags == {"long.com": False, "short.com": True, "missing.com": False}