"""confidence.py 单测。"""
from __future__ import annotations

import pytest

from app.agent.confidence import Confidence, confidence_from_sources, confidence_label
from app.models import EvidenceItem


def _ev(url: str, domain: str = "") -> EvidenceItem:
    return EvidenceItem(url=url, title="t", source_domain=domain)


# ---- confidence_from_sources ----

def test_low_when_no_evidence():
    assert confidence_from_sources([]) == Confidence.LOW


def test_medium_when_one_evidence():
    assert confidence_from_sources([_ev("https://a.com/x", "a.com")]) == Confidence.MEDIUM


def test_medium_when_two_evidence():
    assert confidence_from_sources(
        [_ev("https://a.com/x", "a.com"), _ev("https://b.com/x", "b.com")]
    ) == Confidence.MEDIUM


def test_high_when_three_diverse_domains():
    evs = [
        _ev("https://a.com/x", "a.com"),
        _ev("https://b.com/x", "b.com"),
        _ev("https://c.com/x", "c.com"),
    ]
    assert confidence_from_sources(evs) == Confidence.HIGH


def test_medium_when_three_evidence_same_domain():
    evs = [
        _ev("https://a.com/x", "a.com"),
        _ev("https://a.com/y", "a.com"),
        _ev("https://a.com/z", "a.com"),
    ]
    assert confidence_from_sources(evs) == Confidence.MEDIUM


def test_high_requires_three_distinct_domains():
    """3+ evidence 但 domains<3 仍 MEDIUM。"""
    evs = [
        _ev("https://a.com/x", "a.com"),
        _ev("https://a.com/y", "a.com"),
        _ev("https://b.com/x", "b.com"),
    ]
    assert confidence_from_sources(evs) == Confidence.MEDIUM


def test_evidence_with_empty_domain_counts_as_no_domain():
    evs = [
        _ev("https://a.com/x", ""),
        _ev("https://b.com/x", ""),
        _ev("https://c.com/x", ""),
    ]
    assert confidence_from_sources(evs) == Confidence.MEDIUM


# ---- confidence_label ----

def test_label_low_when_no_evidence():
    assert confidence_label([]) == "[模型推断]"


def test_label_medium_when_one_evidence():
    assert confidence_label([_ev("https://a.com/x", "a.com")]) == "[来源:1, 置信:中]"


def test_label_high_when_three_diverse():
    evs = [
        _ev("https://a.com/x", "a.com"),
        _ev("https://b.com/x", "b.com"),
        _ev("https://c.com/x", "c.com"),
    ]
    assert confidence_label(evs) == "[来源:3, 置信:高]"