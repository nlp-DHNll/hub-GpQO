"""端到端冒烟测试 — 4 个 Agent 串行编排 + state 流转。

所有 LLM 与 search_fn 用 mock 替代，验证：
- Planner 输出子问题被写入
- 每个子问题走完 ≤5 轮的 Researcher+search+Judge 循环
- Judge 返回 sufficient 后跳出
- Writer 被调用一次并把 report_markdown 写入 state
- 所有 SSE 事件按顺序发出
"""
from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

from app.agent.orchestrator import run_research
from app.models import EvidenceItem, ResearchStatus


# ---- mock LLM ----

class MockLLM:
    """模拟 ChatAnthropic：每次 ainvoke 从队列头部 pop 一个预设响应。
    队列空时返回 stop=true，避免循环跑飞。
    """

    def __init__(self, responses):
        if isinstance(responses, str):
            self._responses = [responses]
        else:
            self._responses = list(responses)
        self._calls: list[list[Any]] = []

    async def ainvoke(self, messages, **kwargs):
        self._calls.append(messages)
        if not self._responses:
            return _FakeMessage('{"next_query": null, "stop": true}')
        text = self._responses.pop(0)
        return _FakeMessage(text)


class _FakeMessage:
    def __init__(self, content: str):
        self.content = content


def _make_search_fn(items_per_query: list[list[EvidenceItem]]):
    """生成一个 search_fn，每次调用返回下一批预定义 evidence。"""
    queue = list(items_per_query)
    calls: list[str] = []

    async def search_fn(query: str) -> list[EvidenceItem]:
        calls.append(query)
        if queue:
            return queue.pop(0)
        return [
            EvidenceItem(
                url=f"https://fallback.com/{len(calls)}",
                title=f"fallback for {query}",
                source_domain="fallback.com",
            )
        ]

    return search_fn, calls


# ---- 事件收集 ----

class EventCollector:
    def __init__(self):
        self.events: list[tuple[str, dict]] = []

    async def __call__(self, event: str, data: dict) -> None:
        self.events.append((event, data))


# ---- tests ----

@pytest.mark.asyncio
async def test_smoke_full_pipeline_completes():
    """完整流程：Planner → Researcher × N → Judge → Writer。"""
    # Planner 一次性返回 3 个子问题
    planner_resp = '["子问题 A", "子问题 B", "子问题 C"]'

    # 每个子问题：
    #   round 1: Researcher 给 query + Judge 给 continue
    #   round 2: Researcher 给 query + Judge 给 sufficient
    # 即每个子问题调 2 次 Researcher + 2 次 Judge

    # Researcher 模板：第一次 next_query="X", stop=false；第二次 stop=true
    researcher_resp_round1 = '{"next_query": "query A", "stop": false}'
    researcher_resp_round2 = '{"next_query": null, "stop": true}'

    # Judge 模板：第一次 continue；第二次 sufficient
    judge_resp_continue = '{"decision": "continue", "refined_query": null, "reason": "需要更多"}'
    judge_resp_sufficient = '{"decision": "sufficient", "reason": "够了"}'

    # Writer 输出报告
    writer_resp = "## 摘要\n\n测试报告。"

    # 编排顺序：
    #   planner (1) →
    #   for each sub_question (3)：
    #     round 1: researcher(continue), search, judge(continue)
    #     round 2: researcher(stop=True), break
    #   writer (1)
    # 每个角色用自己的 mock 队列，避免响应错位

    planner_mock = MockLLM(planner_resp)

    researcher_resp_round1 = '{"next_query": "query A", "stop": false}'
    researcher_resp_round2 = '{"next_query": null, "stop": true}'
    researcher_mock = MockLLM(
        [researcher_resp_round1, researcher_resp_round2] * 3
    )

    judge_resp_continue = '{"decision": "continue", "refined_query": null, "reason": "需要更多"}'
    judge_mock = MockLLM([judge_resp_continue] * 3)

    writer_mock = MockLLM(writer_resp)

    search_fn, _ = _make_search_fn([
        [EvidenceItem(url="https://a.com/1", title="A1", source_domain="a.com", summary="s" * 300)],
    ] * 3)

    collector = EventCollector()

    state = await run_research(
        topic="测试主题",
        run_id="test-run-1",
        search_fn=search_fn,
        on_event=collector,
        planner_llm=planner_mock,
        researcher_llm=researcher_mock,
        judge_llm=judge_mock,
        writer_llm=writer_mock,
    )

    # ---- 断言 ----
    assert state.status == ResearchStatus.COMPLETED
    assert state.sub_questions == ["子问题 A", "子问题 B", "子问题 C"]
    assert len(state.sub_question_results) == 3
    # 每个子问题有 evidence
    for sub in state.sub_question_results:
        assert sub.question != ""
        assert len(sub.evidence) > 0
    # Writer 报告写入
    assert "测试报告" in state.report_markdown
    assert "置信度说明" in state.report_markdown  # apply_confidence_tags 追加

    # SSE 事件顺序
    event_types = [e[0] for e in collector.events]
    assert "sub_questions_generated" in event_types
    assert "search_started" in event_types
    assert "page_read" in event_types
    assert "round_done" in event_types
    assert "synthesis_started" in event_types
    assert "report_done" in event_types

    # sub_questions_generated 第一个发
    assert collector.events[0][0] == "sub_questions_generated"


@pytest.mark.asyncio
async def test_smoke_respects_max_rounds():
    """当 Judge 一直 continue 时，到达 max_rounds 上限后跳出。"""
    planner_resp = '["子问题 X"]'
    researcher_resp = '{"next_query": "不断搜", "stop": false}'
    judge_resp = '{"decision": "continue", "reason": "还不够"}'
    writer_resp = "## 摘要\n\n报告。"

    # 每角色独立 mock：5 轮 × (1 researcher + 1 judge)
    planner_mock = MockLLM(planner_resp)
    researcher_mock = MockLLM([researcher_resp] * 5)
    judge_mock = MockLLM([judge_resp] * 5)
    writer_mock = MockLLM(writer_resp)

    search_fn, _ = _make_search_fn([[
        EvidenceItem(url="https://x.com", title="x", source_domain="x.com")
    ]])

    state = await run_research(
        topic="测试",
        run_id="test-run-2",
        search_fn=search_fn,
        planner_llm=planner_mock,
        researcher_llm=researcher_mock,
        judge_llm=judge_mock,
        writer_llm=writer_mock,
    )

    assert state.status == ResearchStatus.COMPLETED
    # 子问题 X 最多 5 轮
    assert state.sub_question_results[0].rounds_used == 5
    assert len(state.sub_question_results[0].evidence) == 5


@pytest.mark.asyncio
async def test_smoke_planner_fallback():
    """Planner 输出无法解析时回退为 [topic]。"""
    planner_resp = "no JSON here, just garbage"
    researcher_resp = '{"next_query": null, "stop": true}'
    judge_resp = '{"decision": "sufficient", "reason": "ok"}'
    writer_resp = "## 摘要\n\nfallback 报告。"

    # planner + 1 researcher + 1 judge + writer
    planner_mock = MockLLM(planner_resp)
    researcher_mock = MockLLM(researcher_resp)
    judge_mock = MockLLM(judge_resp)
    writer_mock = MockLLM(writer_resp)

    state = await run_research(
        topic="原始主题",
        run_id="test-fallback",
        planner_llm=planner_mock,
        researcher_llm=researcher_mock,
        judge_llm=judge_mock,
        writer_llm=writer_mock,
    )

    assert state.sub_questions == ["原始主题"]
    assert state.status == ResearchStatus.COMPLETED