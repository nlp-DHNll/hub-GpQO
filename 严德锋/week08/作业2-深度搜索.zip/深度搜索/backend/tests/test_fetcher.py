"""fetcher.py 单测 — mock httpx 验证：
- 成功路径：返回 readability 提取后的纯文本
- 失败路径：超时 / 非 2xx / 任意异常都返回空串
- 文本长度上限生效
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from app.tools import fetcher
from app.tools.fetcher import fetch_full_page


HTML_WITH_ARTICLE = """
<html><head><title>Test Page</title></head>
<body>
<header>
<nav>
<a href="/home">首页</a>
<a href="/about">关于我们</a>
<a href="/products">产品介绍</a>
<a href="/blog">博客文章</a>
<a href="/careers">招贤纳士</a>
<a href="/contact">联系我们</a>
<a href="/privacy">隐私政策</a>
<a href="/terms">服务条款</a>
<a href="/sitemap">网站地图</a>
<a href="/help">帮助中心</a>
</nav>
<div class="sidebar">
<p>这是侧边栏广告区域，包含很多营销文案与推广链接，与正文无关。</p>
<p>本侧边栏持续展示品牌故事、合作案例、用户评价、媒体报道、订阅引导等大量干扰内容。</p>
<p>还有最新动态、热门标签、相关推荐、热门文章、下载二维码等内容。</p>
</div>
</header>
<article>
<h1>深度研究助手测试文章</h1>
<p>这是一段正文内容，用于验证 readability 提取主内容的能力。
包含了多个段落和重要的关键词：研究助手 / LangChain / Bocha / Sonnet 5。</p>
<p>第二段继续补充信息。这是测试用的虚构内容，包含更多关键词：FastAPI / Next.js / SSE / SQLite。</p>
<p>第三段再补充一些信息，讨论实现细节。这是测试文章的最后一段。</p>
</article>
<footer>
<p>页脚区域：备案号、地址、电话、邮箱、社交媒体链接等。</p>
<p>Copyright 2026 Test Company. All rights reserved. 联系我们 contact@example.com</p>
</footer>
</body></html>
"""


def _mock_response(html: str, status_code: int = 200) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = html
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    return resp


# ---- happy path ----

@pytest.mark.asyncio
async def test_fetch_extracts_main_content():
    """成功抓取：返回 readability 提取后的纯文本。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        return_value=_mock_response(HTML_WITH_ARTICLE)
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x")

    assert "深度研究助手测试文章" in text
    assert "LangChain" in text
    # readability 应过滤掉侧边栏广告/营销文案
    assert "侧边栏广告区域" not in text
    assert "推广链接" not in text
    assert "订阅引导" not in text


@pytest.mark.asyncio
async def test_fetch_respects_max_chars():
    """超过 max_chars 的文本被截断。"""
    long_html = "<html><body><article><p>" + ("测试内容。" * 1000) + "</p></article></body></html>"
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        return_value=_mock_response(long_html)
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x", max_chars=100)

    assert len(text) <= 100


@pytest.mark.asyncio
async def test_fetch_decodes_html_entities():
    """常见 HTML 实体应被解码。"""
    html = "<html><body><article><p>Tom &amp; Jerry &nbsp; are &quot;friends&quot;</p></article></body></html>"
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        return_value=_mock_response(html)
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x")

    assert "Tom & Jerry" in text
    assert '"friends"' in text


# ---- failure paths ----

@pytest.mark.asyncio
async def test_fetch_returns_empty_on_timeout():
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        side_effect=httpx.TimeoutException("timeout")
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x", timeout=1.0)

    assert text == ""


@pytest.mark.asyncio
async def test_fetch_returns_empty_on_http_error():
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        return_value=_mock_response("", status_code=404)
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x")

    assert text == ""


@pytest.mark.asyncio
async def test_fetch_returns_empty_on_unexpected_exception():
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        side_effect=RuntimeError("weird error")
    )

    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        text = await fetch_full_page("https://example.com/x")

    assert text == ""


@pytest.mark.asyncio
async def test_fetch_returns_empty_when_readability_fails():
    """readability 解析失败时也返回空串。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.get = AsyncMock(
        return_value=_mock_response("<html></html>")
    )

    # readability 失败
    with patch("app.tools.fetcher.httpx.AsyncClient", return_value=mock_client):
        with patch(
            "app.tools.fetcher.Document",
            side_effect=Exception("readability broke"),
        ):
            text = await fetch_full_page("https://example.com/x")

    assert text == ""