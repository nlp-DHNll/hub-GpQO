"""Bocha 客户端单测 — 用 pytest-mock 模拟 httpx，验证：
- 正常响应解析
- 多种响应 schema（兼容）
- 失败处理（超时 / 非 2xx / 异常 / 空响应）
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from app.tools import bocha
from app.tools.bocha import BochaResult, search


# ---- fixtures ----

def _mock_response(json_data: dict, status_code: int = 200) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    return resp


# ---- happy paths ----

@pytest.mark.asyncio
async def test_search_parses_standard_webpages_structure():
    """标准结构 data.webPages.value[]。"""
    bocha_data = {
        "code": 200,
        "data": {
            "webPages": {
                "value": [
                    {
                        "name": "天空为什么是蓝色的",
                        "url": "https://example.com/blue-sky",
                        "snippet": "短摘要",
                        "summary": "完整 AI 摘要超过两百字" * 20,
                    }
                ]
            }
        },
    }
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        return_value=_mock_response(bocha_data)
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("天空为什么是蓝色的")

    assert len(results) == 1
    assert results[0].url == "https://example.com/blue-sky"
    assert results[0].title == "天空为什么是蓝色的"
    assert results[0].summary.startswith("完整 AI 摘要")
    assert results[0].source_domain == "example.com"


@pytest.mark.asyncio
async def test_search_parses_alternative_structure():
    """回退结构 data.results[]。"""
    bocha_data = {
        "data": {
            "results": [
                {
                    "title": "备用结构",
                    "link": "https://alt.com/x",
                    "description": "desc",
                }
            ]
        },
    }
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        return_value=_mock_response(bocha_data)
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert len(results) == 1
    assert results[0].title == "备用结构"
    assert results[0].url == "https://alt.com/x"
    assert results[0].snippet == "desc"
    assert results[0].source_domain == "alt.com"


@pytest.mark.asyncio
async def test_search_skips_items_without_url():
    """无 url 的 record 直接跳过。"""
    bocha_data = {
        "data": {"webPages": {"value": [{"name": "no url"}, {"url": "https://ok.com"}]}},
    }
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        return_value=_mock_response(bocha_data)
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert len(results) == 1
    assert results[0].url == "https://ok.com"


# ---- failure paths ----

@pytest.mark.asyncio
async def test_search_returns_empty_on_timeout():
    """超时返回空列表（不抛异常）。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        side_effect=httpx.TimeoutException("timeout")
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test", timeout=1.0)

    assert results == []


@pytest.mark.asyncio
async def test_search_returns_empty_on_http_error():
    """非 2xx 返回空列表。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        return_value=_mock_response({}, status_code=500)
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert results == []


@pytest.mark.asyncio
async def test_search_returns_empty_on_json_error():
    """JSON 解析失败返回空列表。"""
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    resp.json.side_effect = ValueError("bad json")

    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(return_value=resp)

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert results == []


@pytest.mark.asyncio
async def test_search_returns_empty_on_unexpected_exception():
    """任意异常兜底返回空列表。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        side_effect=RuntimeError("weird error")
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert results == []


@pytest.mark.asyncio
async def test_search_returns_empty_when_no_pages():
    """空响应返回空列表。"""
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value.post = AsyncMock(
        return_value=_mock_response({"data": {"webPages": {"value": []}}})
    )

    with patch("app.tools.bocha.httpx.AsyncClient", return_value=mock_client):
        results = await search("test")

    assert results == []


@pytest.mark.asyncio
async def test_search_uses_resolved_bocha_key():
    """确认 Authorization 头使用 resolved_bocha_key。"""
    captured = {}

    def capture_client(**kwargs):
        async def fake_post(url, json, headers):
            captured["headers"] = headers
            return _mock_response({"data": {"webPages": {"value": []}}})
        mock = AsyncMock()
        mock.__aenter__.return_value.post = fake_post
        return mock

    with patch("app.tools.bocha.httpx.AsyncClient", side_effect=capture_client):
        await search("test")

    auth = captured["headers"]["Authorization"]
    assert auth.startswith("Bearer ")
    # README 兜底 key 至少 32 字符
    assert len(auth) > 40