"""storage 层单测 — researches + event_log + markdown 落盘。

策略：用 tmp_path 临时目录覆盖 settings.db_path / reports_dir，避免污染真实数据。
通过 monkeypatch + get_settings.cache_clear() 切换 settings。
"""
from __future__ import annotations

import pytest

from app.exporters import markdown as md_exporter
from app.models import ResearchState, ResearchStatus
from app.settings import get_settings
from app.storage import db, event_log


@pytest.fixture
def temp_storage(tmp_path, monkeypatch):
    """临时数据库 + 报告目录。"""
    db_path = tmp_path / "test.db"
    reports_dir = tmp_path / "reports"
    monkeypatch.setenv("DB_PATH", str(db_path))
    monkeypatch.setenv("REPORTS_DIR", str(reports_dir))
    get_settings.cache_clear()
    db.init_db()
    yield {"db_path": db_path, "reports_dir": reports_dir}
    get_settings.cache_clear()


# ---- db ----

def test_init_db_is_idempotent(temp_storage):
    db.init_db()
    db.init_db()  # 不报错


def test_insert_and_get_research(temp_storage):
    state = ResearchState(
        run_id="r1",
        topic="测试主题",
        status=ResearchStatus.RUNNING,
    )
    db.insert_research(state)
    row = db.get_research("r1")
    assert row is not None
    assert row["topic"] == "测试主题"
    assert row["status"] == "running"
    assert row["created_at"]


def test_get_research_returns_none_when_missing(temp_storage):
    assert db.get_research("nope") is None


def test_update_research_partial(temp_storage):
    db.insert_research(ResearchState(run_id="r1", topic="t"))
    db.update_research(
        "r1",
        status="completed",
        summary="ok",
        total_rounds=3,
    )
    row = db.get_research("r1")
    assert row["status"] == "completed"
    assert row["summary"] == "ok"
    assert row["total_rounds"] == 3
    # 没传的字段不动
    assert row["report_path"] is None
    assert row["error"] is None


def test_update_research_does_not_overwrite_unset_fields(temp_storage):
    db.insert_research(ResearchState(run_id="r1", topic="t"))
    db.update_research("r1", error="failed")
    db.update_research("r1", status="completed")  # 不传 error
    row = db.get_research("r1")
    assert row["status"] == "completed"
    assert row["error"] == "failed"  # 之前设的值仍在


def test_list_researches_orders_newest_first(temp_storage):
    db.insert_research(ResearchState(run_id="r1", topic="A"))
    db.insert_research(ResearchState(run_id="r2", topic="B"))
    db.insert_research(ResearchState(run_id="r3", topic="C"))
    rows = db.list_researches()
    assert [r["id"] for r in rows] == ["r3", "r2", "r1"]


def test_list_researches_respects_limit(temp_storage):
    for i in range(5):
        db.insert_research(ResearchState(run_id=f"r{i}", topic=f"T{i}"))
    rows = db.list_researches(limit=2)
    assert len(rows) == 2


def test_insert_research_with_report_stores_derived_summary(temp_storage):
    """带 report_markdown 的 state 插入后能从「## 摘要」section 抽出 summary。"""
    state = ResearchState(
        run_id="r1",
        topic="t",
        report_markdown="## 摘要\n\n这是测试摘要内容，应该被提取。\n\n## 正文\n\n其他内容。",
    )
    db.insert_research(state)
    row = db.get_research("r1")
    assert row["summary"].startswith("这是测试摘要")
    assert len(row["summary"]) <= 100


# ---- event_log ----

def test_insert_and_query_events(temp_storage):
    event_log.insert_event("r1", "search_started", {"round": 1, "query": "x"})
    event_log.insert_event("r1", "page_read", {"url": "https://a.com"})
    event_log.insert_event("r2", "search_started", {"round": 1})

    r1_events = event_log.get_events("r1")
    assert len(r1_events) == 2
    assert r1_events[0]["event_type"] == "search_started"
    assert r1_events[1]["payload"]["url"] == "https://a.com"

    r2_events = event_log.get_events("r2")
    assert len(r2_events) == 1


def test_events_returned_in_insertion_order(temp_storage):
    for i in range(5):
        event_log.insert_event("r1", "round_done", {"round": i})
    events = event_log.get_events("r1")
    assert [e["payload"]["round"] for e in events] == [0, 1, 2, 3, 4]


def test_count_events(temp_storage):
    event_log.insert_event("r1", "a", {})
    event_log.insert_event("r1", "b", {})
    assert event_log.count_events("r1") == 2
    assert event_log.count_events("r2") == 0


# ---- markdown exporter ----

def test_save_report_creates_dated_subdir(temp_storage):
    path = md_exporter.save_report("r1", "# 标题\n\n正文")
    assert path.exists()
    # 路径形如 reports/2026-09-12/r1.md
    assert path.parent.parent == temp_storage["reports_dir"]
    assert path.name == "r1.md"
    assert path.read_text(encoding="utf-8") == "# 标题\n\n正文"


def test_extract_summary_returns_first_section_text():
    md = """
## 摘要
这是一段测试摘要。包含中文与 English。

## 正文
其他内容
"""
    summary = md_exporter.extract_summary(md, max_chars=50)
    assert "测试摘要" in summary
    assert "其他内容" not in summary
    assert len(summary) <= 50


def test_extract_summary_returns_empty_when_no_summary_section():
    assert md_exporter.extract_summary("## 正文\n\n其他") == ""


def test_extract_summary_handles_empty_input():
    assert md_exporter.extract_summary("") == ""