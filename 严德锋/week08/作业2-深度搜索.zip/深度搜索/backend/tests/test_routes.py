"""FastAPI 路由测试。

覆盖：
- POST /api/research 启动研究（mock LLM 与 search）
- GET /api/research/{id}/events 收 SSE 流
- DELETE /api/research/{id} 取消
- GET /api/reports 列表
- GET /api/reports/{id} 详情
- GET /api/reports/{id}/markdown 下载
- GET /api/reports/{id}/pdf|docx stub（501）
- POST /api/reports/{id}/rerun 重跑
- POST /api/reports/{id}/retry 重试

策略：用 monkeypatch 把 settings 切到 tmp_path，把 LLM/search 全 mock。
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from app.main import app
from app.settings import get_settings
from app.storage import db


# ---- fixtures ----

@pytest.fixture
def temp_app(tmp_path, monkeypatch):
    """切换 settings 到 tmp_path，monkeypatch LLM + search 让启动可控。"""
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    monkeypatch.setenv("REPORTS_DIR", str(tmp_path / "reports"))
    get_settings.cache_clear()
    db.init_db()

    # 默认 mock：LLM 返回简单响应，search 返回固定 evidence
    llm_responses = {
        "planner": '["子问题 A", "子问题 B"]',
        "researcher": '{"next_query": null, "stop": true}',
        "judge": '{"decision": "sufficient", "reason": "ok"}',
        "writer": "## 摘要\n\n测试报告内容。\n\n## 正文\n\n更多内容。\n\n## 关键结论\n\n- 结论1\n\n## 遗留问题\n\n- 问题1",
    }

    class FakeMsg:
        def __init__(self, content):
            self.content = content

    async def fake_ainvoke(messages, **kwargs):
        # 根据 system prompt 推测用哪个 role
        sys_content = ""
        for m in messages:
            if hasattr(m, "content") and isinstance(m.content, str):
                sys_content = m.content
                break
        if "research planning" in sys_content or "研究规划助手" in sys_content:
            return FakeMsg(llm_responses["planner"])
        if "research investigator" in sys_content or "研究调查员" in sys_content:
            return FakeMsg(llm_responses["researcher"])
        if "research quality judge" in sys_content or "研究质量判定员" in sys_content:
            return FakeMsg(llm_responses["judge"])
        if "research report writer" in sys_content or "研究报告撰写员" in sys_content:
            return FakeMsg(llm_responses["writer"])
        return FakeMsg("{}")

    # Patch 所有 LLM 构造点
    monkeypatch.setattr("app.agent.planner.make_planner", lambda **kw: AsyncMock(ainvoke=fake_ainvoke))
    monkeypatch.setattr("app.agent.researcher.make_researcher", lambda **kw: AsyncMock(ainvoke=fake_ainvoke))
    monkeypatch.setattr("app.agent.judge.make_judge", lambda **kw: AsyncMock(ainvoke=fake_ainvoke))
    monkeypatch.setattr("app.agent.writer.make_writer", lambda **kw: AsyncMock(ainvoke=fake_ainvoke))

    # Patch search_fn 让它立即返回 1 条 evidence
    from app.models import EvidenceItem

    async def fake_search(query):
        return [EvidenceItem(
            url=f"https://{query}.example.com",
            title=f"title {query}",
            summary="s" * 300,
            source_domain=f"{query}.example.com",
        )]

    monkeypatch.setattr("app.tools.search.search_with_fallback", fake_search)

    yield {"tmp_path": tmp_path}
    get_settings.cache_clear()


@pytest.fixture
async def client(temp_app):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as c:
        yield c


# ---- / ----

@pytest.mark.asyncio
async def test_root(client):
    r = await client.get("/")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_health(client):
    r = await client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


# ---- research routes ----

@pytest.mark.asyncio
async def test_start_research_returns_run_id(client):
    r = await client.post("/api/research", json={"topic": "测试主题"})
    assert r.status_code == 200
    data = r.json()
    assert "run_id" in data
    assert len(data["run_id"]) > 0


@pytest.mark.asyncio
async def test_start_research_validates_topic(client):
    r = await client.post("/api/research", json={"topic": ""})
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_cancel_unknown_run_returns_404(client):
    r = await client.delete("/api/research/nonexistent-id")
    assert r.status_code == 404


@pytest.mark.asyncio
async def test_cancel_known_run_returns_200(client):
    start = await client.post("/api/research", json={"topic": "测试"})
    run_id = start.json()["run_id"]
    # 立刻 cancel（任务还在跑）
    r = await client.delete(f"/api/research/{run_id}")
    assert r.status_code == 200
    body = r.json()
    assert body["run_id"] == run_id
    assert isinstance(body["cancelled"], bool)


@pytest.mark.asyncio
async def test_sse_stream_returns_events(client):
    """SSE 流应该能收到至少几个事件（started + sub_questions_generated 等）。"""
    start = await client.post("/api/research", json={"topic": "测试主题"})
    run_id = start.json()["run_id"]

    events: list[tuple[str, dict]] = []
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        assert resp.status_code == 200
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events.append((current_event, json.loads(current_data)))
                    current_event = None
                    current_data = None
            # 收到 done 终止
            if any(e[0] == "done" for e in events):
                break

    event_types = [e[0] for e in events]
    assert "started" in event_types
    assert "sub_questions_generated" in event_types
    assert "done" in event_types


@pytest.mark.asyncio
async def test_sse_unknown_run_returns_404(client):
    async with client.stream("GET", "/api/research/nonexistent-id/events") as resp:
        assert resp.status_code == 404


# ---- reports routes ----

@pytest.mark.asyncio
async def test_list_reports_empty(client):
    r = await client.get("/api/reports")
    assert r.status_code == 200
    assert r.json() == []


@pytest.mark.asyncio
async def test_list_reports_after_run(client):
    # 跑一次研究
    start = await client.post("/api/research", json={"topic": "列表测试"})
    run_id = start.json()["run_id"]

    # 等完成
    events: list[tuple[str, dict]] = []
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events.append((current_event, json.loads(current_data)))
                    current_event = None
                    current_data = None
            if any(e[0] == "done" for e in events):
                break

    r = await client.get("/api/reports")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) >= 1
    assert any(row["id"] == run_id for row in rows)


@pytest.mark.asyncio
async def test_get_report_detail(client):
    start = await client.post("/api/research", json={"topic": "详情测试"})
    run_id = start.json()["run_id"]

    # 等完成
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.get(f"/api/reports/{run_id}")
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == run_id
    assert data["topic"] == "详情测试"
    assert "events" in data
    assert len(data["events"]) > 0


@pytest.mark.asyncio
async def test_get_report_unknown_returns_404(client):
    r = await client.get("/api/reports/nonexistent")
    assert r.status_code == 404


@pytest.mark.asyncio
async def test_download_markdown(client):
    start = await client.post("/api/research", json={"topic": "下载测试"})
    run_id = start.json()["run_id"]

    # 等完成
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.get(f"/api/reports/{run_id}/markdown")
    assert r.status_code == 200
    assert "text/markdown" in r.headers["content-type"]
    assert "## 摘要" in r.text


@pytest.mark.asyncio
async def test_download_pdf_returns_pdf_or_503(client):
    """PDF 端点：weasyprint 可用时返回 200 + PDF；不可用时返回 503。"""
    # 先跑一次研究拿一个有效 run_id
    start = await client.post("/api/research", json={"topic": "PDF 测试"})
    run_id = start.json()["run_id"]
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.get(f"/api/reports/{run_id}/pdf")
    # 200 = weasyprint 可用，503 = Windows 裸环境降级
    assert r.status_code in (200, 503)
    if r.status_code == 200:
        assert r.headers["content-type"] == "application/pdf"
        assert r.content[:4] == b"%PDF"
    else:
        assert "weasyprint" in r.text.lower()


@pytest.mark.asyncio
async def test_download_docx_returns_docx(client):
    """DOCX 端点：python-docx 是纯 Python，所有平台应返回 200。"""
    start = await client.post("/api/research", json={"topic": "DOCX 测试"})
    run_id = start.json()["run_id"]
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.get(f"/api/reports/{run_id}/docx")
    assert r.status_code == 200
    assert r.content[:2] == b"PK"


@pytest.mark.asyncio
async def test_rerun_new_mode(client):
    # 第一次跑
    start = await client.post("/api/research", json={"topic": "重跑测试"})
    run_id = start.json()["run_id"]
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.post(f"/api/reports/{run_id}/rerun?mode=new")
    assert r.status_code == 200
    body = r.json()
    assert body["mode"] == "new"
    assert body["topic"] == "重跑测试"
    assert body["run_id"] != run_id  # 新 ID


@pytest.mark.asyncio
async def test_rerun_invalid_mode_returns_400(client):
    r = await client.post("/api/reports/some-id/rerun?mode=bogus")
    assert r.status_code == 400


@pytest.mark.asyncio
async def test_retry_only_for_failed_or_cancelled(client):
    # 默认 mock 下研究是 completed，retry 应被拒
    r = await client.post("/api/reports/some-id/retry")
    assert r.status_code == 404  # id 不存在

    # 跑一个成功的
    start = await client.post("/api/research", json={"topic": "retry 测试"})
    run_id = start.json()["run_id"]
    async with client.stream("GET", f"/api/research/{run_id}/events") as resp:
        async for line in resp.aiter_lines():
            if line.startswith("event:"):
                current_event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                current_data = line.split(":", 1)[1].strip()
                if current_event and current_data:
                    events_list = [(current_event, json.loads(current_data))]
                    current_event = None
                    current_data = None
                    if any(e[0] == "done" for e in events_list):
                        break

    r = await client.post(f"/api/reports/{run_id}/retry")
    assert r.status_code == 400  # 状态是 completed，不能 retry


# ---- state_store ----

@pytest.mark.asyncio
async def test_state_store_register_and_cancel(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    get_settings.cache_clear()

    from app.state_store import register, cancel, get, unregister

    async def dummy():
        await asyncio.sleep(10)

    task = asyncio.create_task(dummy())
    register("r1", task)
    assert get("r1") is task
    assert cancel("r1") is True
    task.cancel()
    await asyncio.sleep(0)
    unregister("r1")
    assert get("r1") is None


def test_state_store_cancel_nonexistent(tmp_path, monkeypatch):
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    get_settings.cache_clear()
    from app.state_store import cancel
    assert cancel("nope") is False