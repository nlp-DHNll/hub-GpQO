"""Markdown → DOCX 导出（手写解析）。

覆盖报告里实际出现的元素：
- 标题（# / ## / ### / ####）
- 段落
- 有序列表（1. 2. 3.）
- 无序列表（- * +）
- 引用块（>）
- 分隔线（---）

未覆盖（v1 故意不做）：
- 表格 / 代码块 / 内联粗体斜体链接
- 留给后续需求出现时再加
"""
from __future__ import annotations

import re
from io import BytesIO

from docx import Document
from docx.shared import Pt


_LIST_RE = re.compile(r"^(\s*)([-*+])\s+(.*)$")
_ORDERED_RE = re.compile(r"^(\s*)\d+[.)]\s+(.*)$")
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
_HR_RE = re.compile(r"^-{3,}\s*$")


def markdown_to_docx(md_content: str) -> bytes:
    """Markdown 文本 → DOCX bytes。"""
    doc = Document()
    _set_default_style(doc)
    _parse_lines(doc, md_content.split("\n"))
    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _set_default_style(doc: Document) -> None:
    style = doc.styles["Normal"]
    style.font.name = "PingFang SC"
    style.font.size = Pt(11)


def _parse_lines(doc: Document, lines: list[str]) -> None:
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # 空行跳过
        if not stripped:
            i += 1
            continue

        # 标题
        m = _HEADING_RE.match(stripped)
        if m:
            level = len(m.group(1))
            text = m.group(2).strip()
            doc.add_heading(text, level=min(level, 4))
            i += 1
            continue

        # 分隔线
        if _HR_RE.match(stripped):
            # DOCX 没有原生 HR，加一个空段落
            doc.add_paragraph("")
            i += 1
            continue

        # 无序列表
        m = _LIST_RE.match(line)
        if m:
            indent = len(m.group(1)) // 2  # 每 2 空格一级
            text = m.group(3)
            style = "List Bullet"
            p = doc.add_paragraph(text, style=style)
            if indent > 0:
                p.paragraph_format.left_indent = Pt(20 * indent)
            i += 1
            continue

        # 有序列表
        m = _ORDERED_RE.match(line)
        if m:
            indent = len(m.group(1)) // 2
            text = m.group(2)
            p = doc.add_paragraph(text, style="List Number")
            if indent > 0:
                p.paragraph_format.left_indent = Pt(20 * indent)
            i += 1
            continue

        # 引用块
        if stripped.startswith("> "):
            text = stripped[2:].strip()
            doc.add_paragraph(text, style="Quote")
            i += 1
            continue

        # 普通段落（合并连续非空行）
        para_lines = [stripped]
        j = i + 1
        while j < len(lines):
            nxt = lines[j].strip()
            if not nxt:
                break
            # 遇到特殊行就停
            if (
                _HEADING_RE.match(nxt)
                or _HR_RE.match(nxt)
                or _LIST_RE.match(lines[j])
                or _ORDERED_RE.match(lines[j])
                or nxt.startswith("> ")
            ):
                break
            para_lines.append(nxt)
            j += 1
        doc.add_paragraph(" ".join(para_lines))
        i = j