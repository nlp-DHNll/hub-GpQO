"""Markdown 报告落盘 + 摘要提取。"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from app.settings import get_settings


def save_report(run_id: str, markdown: str) -> Path:
    """保存 Markdown 到 reports/{YYYY-MM-DD}/{run_id}.md。返回落盘路径。"""
    settings = get_settings()
    today = datetime.now().strftime("%Y-%m-%d")
    dir_path = Path(settings.reports_dir) / today
    dir_path.mkdir(parents=True, exist_ok=True)
    file_path = dir_path / f"{run_id}.md"
    file_path.write_text(markdown, encoding="utf-8")
    return file_path


def extract_summary(markdown: str, max_chars: int = 100) -> str:
    """提取 Markdown 中「## 摘要」章节的纯文本（最长 max_chars 字）。

    用于历史列表页的「摘要前 100 字」展示。
    """
    return _extract_section(markdown, "## 摘要", max_chars)


def _extract_section(markdown: str, header: str, max_chars: int) -> str:
    """提取指定 header 下的纯文本（直到下一个 ## 章节）。"""
    if not markdown:
        return ""
    lines = markdown.split("\n")
    in_section = False
    captured: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped == header:
            in_section = True
            continue
        if in_section:
            if stripped.startswith("## "):
                break
            if stripped:
                captured.append(stripped)
    text = " ".join(captured)
    return text[:max_chars]