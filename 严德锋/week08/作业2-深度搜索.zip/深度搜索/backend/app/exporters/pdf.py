"""Markdown → PDF 导出。

依赖 weasyprint（需要 libpango / libcairo 等系统库）。
- 在 Linux/Docker 环境下正常工作
- 在 Windows 裸环境通常加载失败，函数抛 RuntimeError 让上层路由返回 503

不要在本模块中捕获 OSError：让导入失败显式冒泡，便于启动期发现。
"""
from __future__ import annotations

from app.logging_config import get_logger


logger = get_logger()


_AVAILABLE: bool | None = None


def is_available() -> bool:
    """检查 weasyprint 是否可加载。"""
    global _AVAILABLE
    if _AVAILABLE is None:
        try:
            from weasyprint import HTML  # noqa: F401
            _AVAILABLE = True
        except (ImportError, OSError) as e:
            logger.warning(f"weasyprint_not_available | error={e!s}")
            _AVAILABLE = False
    return _AVAILABLE


def markdown_to_pdf(md_content: str) -> bytes:
    """Markdown 文本 → PDF bytes。

    Raises:
        RuntimeError: weasyprint 系统库未安装（Windows 常见）。
    """
    if not is_available():
        raise RuntimeError(
            "weasyprint 系统库未安装。Linux/Docker 环境下可用；Windows 上请按 "
            "https://doc.courtbouillon.org/weasyprint/stable/first_steps.html#installation 配置。"
        )

    import markdown
    from weasyprint import HTML

    html_body = markdown.markdown(
        md_content,
        extensions=["extra", "sane_lists", "tables"],
    )
    full_html = _wrap_html(html_body)
    return HTML(string=full_html, base_url=None).write_pdf()


_BASE_CSS = """
body {
  font-family: "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
  line-height: 1.65;
  max-width: 820px;
  margin: 2em auto;
  padding: 0 1.2em;
  color: #222;
}
h1, h2, h3, h4 { color: #1a1a1a; margin-top: 1.6em; }
h1 { font-size: 1.9em; border-bottom: 2px solid #1a1a1a; padding-bottom: 0.3em; }
h2 { font-size: 1.45em; border-bottom: 1px solid #ccc; padding-bottom: 0.2em; }
h3 { font-size: 1.2em; }
code { background: #f4f4f4; padding: 0.1em 0.35em; border-radius: 3px; font-family: Consolas, "Courier New", monospace; }
pre { background: #f4f4f4; padding: 1em; overflow-x: auto; border-radius: 4px; }
pre code { background: transparent; padding: 0; }
blockquote { border-left: 4px solid #ccc; margin: 0; padding: 0.3em 0 0.3em 1em; color: #555; }
table { border-collapse: collapse; margin: 1em 0; }
th, td { border: 1px solid #ccc; padding: 0.4em 0.8em; }
th { background: #f4f4f4; }
a { color: #0a66c2; text-decoration: none; }
hr { border: none; border-top: 1px solid #ddd; margin: 2em 0; }
"""


def _wrap_html(body: str) -> str:
    return (
        '<!DOCTYPE html>\n'
        '<html lang="zh-CN"><head><meta charset="utf-8">'
        f"<style>{_BASE_CSS}</style>"
        f"</head><body>{body}</body></html>"
    )