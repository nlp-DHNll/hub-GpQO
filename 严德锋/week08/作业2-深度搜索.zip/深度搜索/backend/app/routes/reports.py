"""报告相关路由：列表 / 详情 / 导出 / 重跑 / 重试。

PDF / DOCX 导出在本步先 stub（501），由 Step 7 实现。
"""
from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, Response

from app.exporters.markdown import extract_summary as extract_md_summary
from app.logging_config import get_logger
from app.models import ResearchState, ResearchStatus
from app.state_store import register, unregister
from app.storage import db, event_log


logger = get_logger()
router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.get("")
async def list_reports(limit: int = 50):
    """历史报告列表，按 created_at DESC。"""
    rows = await asyncio.to_thread(db.list_researches, limit)
    return rows


@router.get("/{report_id}")
async def get_report(report_id: str):
    """单条报告详情（含 event_log 用于前端研究日志折叠区）。"""
    row = await asyncio.to_thread(db.get_research, report_id)
    if row is None:
        raise HTTPException(status_code=404, detail="report not found")
    events = await asyncio.to_thread(event_log.get_events, report_id)
    return {**row, "events": events}


@router.get("/{report_id}/markdown")
async def download_markdown(report_id: str):
    """下载 Markdown 文件。"""
    row = await asyncio.to_thread(db.get_research, report_id)
    if row is None or not row["report_path"]:
        raise HTTPException(status_code=404, detail="report not found")
    path = Path(row["report_path"])
    if not path.exists():
        raise HTTPException(status_code=410, detail="markdown file missing on disk")
    return FileResponse(
        path=str(path),
        media_type="text/markdown",
        filename=f"{report_id}.md",
    )


@router.get("/{report_id}/pdf")
async def download_pdf(report_id: str):
    """下载 PDF（依赖 weasyprint，Windows 裸环境可能不可用）。"""
    row = await asyncio.to_thread(db.get_research, report_id)
    if row is None:
        raise HTTPException(status_code=404, detail="report not found")
    if not row["report_path"]:
        raise HTTPException(status_code=404, detail="report not generated yet")
    path = Path(row["report_path"])
    if not path.exists():
        raise HTTPException(status_code=410, detail="markdown file missing on disk")

    markdown_content = path.read_text(encoding="utf-8")
    try:
        from app.exporters.pdf import markdown_to_pdf
        pdf_bytes = markdown_to_pdf(markdown_content)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:  # noqa: BLE001
        from app.logging_config import get_logger
        get_logger().exception(f"pdf_export_failed | run_id={report_id} | error={e!s}")
        raise HTTPException(status_code=500, detail=f"PDF export failed: {e!s}")

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{report_id}.pdf"'},
    )


@router.get("/{report_id}/docx")
async def download_docx(report_id: str):
    """下载 DOCX。"""
    row = await asyncio.to_thread(db.get_research, report_id)
    if row is None:
        raise HTTPException(status_code=404, detail="report not found")
    if not row["report_path"]:
        raise HTTPException(status_code=404, detail="report not generated yet")
    path = Path(row["report_path"])
    if not path.exists():
        raise HTTPException(status_code=410, detail="markdown file missing on disk")

    markdown_content = path.read_text(encoding="utf-8")
    try:
        from app.exporters.docx import markdown_to_docx
        docx_bytes = markdown_to_docx(markdown_content)
    except Exception as e:  # noqa: BLE001
        from app.logging_config import get_logger
        get_logger().exception(f"docx_export_failed | run_id={report_id} | error={e!s}")
        raise HTTPException(status_code=500, detail=f"DOCX export failed: {e!s}")

    return Response(
        content=docx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{report_id}.docx"'},
    )


@router.post("/{report_id}/rerun")
async def rerun_report(report_id: str, mode: str = "new"):
    """重跑同一主题。mode: 'overwrite' / 'new'。"""
    if mode not in ("overwrite", "new"):
        raise HTTPException(status_code=400, detail="mode must be 'overwrite' or 'new'")

    original = await asyncio.to_thread(db.get_research, report_id)
    if original is None:
        raise HTTPException(status_code=404, detail="report not found")

    topic = original["topic"]
    new_run_id = report_id if mode == "overwrite" else f"{report_id[:8]}-{uuid.uuid4().hex[:6]}"

    # 重置状态
    from datetime import datetime, timezone
    state = ResearchState(
        run_id=new_run_id,
        topic=topic,
        status=ResearchStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
    )
    await asyncio.to_thread(db.insert_research, state)
    await asyncio.to_thread(event_log.insert_event, new_run_id, "started", {"topic": topic, "rerun_from": report_id, "mode": mode})

    # 复用后台启动逻辑（inline 因为避免循环依赖）
    from app.routes.research import _background_runner
    task = _background_runner(new_run_id, topic)
    register(new_run_id, task)

    return {"run_id": new_run_id, "mode": mode, "topic": topic}


@router.post("/{report_id}/retry")
async def retry_report(report_id: str):
    """重试失败 / 取消的任务。"""
    original = await asyncio.to_thread(db.get_research, report_id)
    if original is None:
        raise HTTPException(status_code=404, detail="report not found")
    if original["status"] not in ("failed", "cancelled"):
        raise HTTPException(
            status_code=400,
            detail=f"can only retry failed/cancelled runs (current status: {original['status']})",
        )

    # 重置状态
    from datetime import datetime, timezone
    state = ResearchState(
        run_id=report_id,
        topic=original["topic"],
        status=ResearchStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
    )
    await asyncio.to_thread(db.insert_research, state)  # INSERT OR REPLACE via PRIMARY KEY
    await asyncio.to_thread(event_log.insert_event, report_id, "started", {"topic": original["topic"], "retry": True})

    from app.routes.research import _background_runner
    task = _background_runner(report_id, original["topic"])
    register(report_id, task)

    return {"run_id": report_id, "topic": original["topic"]}