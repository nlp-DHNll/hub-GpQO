"""研究流程相关路由：启动 / SSE 事件流 / 取消。"""
from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.agent.orchestrator import run_research
from app.agent.state import mark_completed
from app.exporters.markdown import extract_summary as extract_md_summary
from app.exporters.markdown import save_report
from app.logging_config import get_logger
from app.models import ResearchState, ResearchStatus, StartResearchRequest, StartResearchResponse
from app.state_store import cancel as cancel_task, get as get_task, register, unregister
from app.storage import db, event_log
from app.tools.search import search_with_fallback


logger = get_logger()
router = APIRouter(prefix="/api/research", tags=["research"])


def _emit_to_log(run_id: str):
    """构造 on_event 回调：把事件写入 event_log 表（用 asyncio.to_thread 避免阻塞）。"""

    async def emit(event_type: str, payload: dict) -> None:
        try:
            await asyncio.to_thread(event_log.insert_event, run_id, event_type, payload)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"event_log_write_failed | event={event_type} | error={e!s}")

    return emit


async def _persist_completion(state: ResearchState) -> None:
    """研究完成后：落 Markdown + 更新 DB。"""
    if state.status != ResearchStatus.COMPLETED:
        return
    try:
        path = save_report(state.run_id, state.report_markdown)
        summary = extract_md_summary(state.report_markdown, max_chars=100)
        total_rounds = sum(sub.rounds_used for sub in state.sub_question_results)
        await asyncio.to_thread(
            db.update_research,
            state.run_id,
            status="completed",
            report_path=str(path),
            summary=summary,
            total_rounds=total_rounds,
        )
        # 完成事件
        await asyncio.to_thread(
            event_log.insert_event,
            state.run_id,
            "done",
            {"status": "completed"},
        )
    except Exception as e:  # noqa: BLE001
        logger.exception(f"persist_completion_failed | run_id={state.run_id} | error={e!s}")


async def _persist_failure(state: ResearchState) -> None:
    try:
        await asyncio.to_thread(
            db.update_research,
            state.run_id,
            status=state.status.value if isinstance(state.status, ResearchStatus) else state.status,
            error=state.error,
        )
    except Exception as e:  # noqa: BLE001
        logger.exception(f"persist_failure_failed | run_id={state.run_id} | error={e!s}")


def _background_runner(run_id: str, topic: str) -> asyncio.Task:
    """后台运行 orchestrator + 完成/失败后的持久化。"""

    async def runner() -> None:
        try:
            state = await run_research(
                topic=topic,
                run_id=run_id,
                search_fn=search_with_fallback,
                on_event=_emit_to_log(run_id),
            )
            await _persist_completion(state)
        except asyncio.CancelledError:
            # run_research 已经把状态标为 cancelled 并 emit error
            cancelled_state = ResearchState(
                run_id=run_id, topic=topic, status=ResearchStatus.CANCELLED
            )
            await _persist_failure(cancelled_state)
        except Exception as e:  # noqa: BLE001
            logger.exception(f"background_runner_failed | run_id={run_id} | error={e!s}")
            failed_state = ResearchState(
                run_id=run_id, topic=topic, status=ResearchStatus.FAILED, error=str(e)
            )
            await _persist_failure(failed_state)
        finally:
            unregister(run_id)

    return asyncio.create_task(runner())


@router.post("", response_model=StartResearchResponse)
async def start_research(req: StartResearchRequest):
    """启动一次研究，返回 run_id。研究在后台任务中执行。"""
    run_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc)

    # 初始入库（status=running）
    state = ResearchState(
        run_id=run_id,
        topic=req.topic,
        status=ResearchStatus.RUNNING,
        started_at=now,
    )
    await asyncio.to_thread(db.insert_research, state)
    await asyncio.to_thread(event_log.insert_event, run_id, "started", {"topic": req.topic})

    # 启动后台任务
    task = _background_runner(run_id, req.topic)
    register(run_id, task)

    return StartResearchResponse(run_id=run_id)


@router.get("/{run_id}/events")
async def stream_events(run_id: str):
    """SSE 事件流：从 event_log 增量拉取并推送。

    终止条件：
    1. 收到 done/error/report_done 事件后 yield 完关闭
    2. 客户端断开
    3. 兜底超时（默认 10 分钟）
    """
    if not await asyncio.to_thread(db.get_research, run_id):
        raise HTTPException(status_code=404, detail="research not found")

    # SSE 流终止条件：只有 background_runner 写入的「done」或「error」是真正的终止符
    # report_done 只是 orchestrator 内部的「报告已生成」信号，后续还要走持久化
    TERMINAL = {"done", "error"}

    async def event_generator():
        last_id = 0
        # 兜底超时：防止客户端连上后不读导致资源浪费
        deadline = asyncio.get_event_loop().time() + 600
        try:
            while asyncio.get_event_loop().time() < deadline:
                events = await asyncio.to_thread(event_log.get_events_since, run_id, last_id)
                if events:
                    for e in events:
                        last_id = max(last_id, e["id"])
                        # SSE 协议：event / data 两行 + 空行结尾
                        yield (
                            f"event: {e['event_type']}\n"
                            f"data: {json.dumps(e['payload'], ensure_ascii=False, default=str)}\n\n"
                        )
                        if e["event_type"] in TERMINAL:
                            return
                await asyncio.sleep(0.3)
        except asyncio.CancelledError:
            # 客户端断开连接
            return

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # 禁用 nginx 缓冲
        },
    )


@router.delete("/{run_id}")
async def cancel_research(run_id: str):
    """取消正在运行的研究。"""
    if not await asyncio.to_thread(db.get_research, run_id):
        raise HTTPException(status_code=404, detail="research not found")
    cancelled = cancel_task(run_id)
    return {"cancelled": cancelled, "run_id": run_id}