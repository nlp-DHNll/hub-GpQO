"""SQLite 存储：researches 表 CRUD + event_log 表（与 event_log.py 配合）。

设计要点：
- 同步 sqlite3 + asyncio.to_thread 包装（在调用方负责）
- 幂等 init_db() — 多次调用安全
- 所有时间戳用 UTC ISO 8601
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from app.logging_config import get_logger
from app.models import ResearchState, ResearchStatus
from app.settings import get_settings


logger = get_logger()


SCHEMA_RESEARCHES = """
CREATE TABLE IF NOT EXISTS researches (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    report_path TEXT,
    summary TEXT,
    total_rounds INTEGER DEFAULT 0,
    error TEXT
);
"""

SCHEMA_EVENT_LOG = """
CREATE TABLE IF NOT EXISTS event_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""

INDEX_EVENT_LOG = """
CREATE INDEX IF NOT EXISTS idx_event_log_run_id ON event_log(run_id);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    """获取 SQLite 连接（带 row_factory，路径自动 mkdir）。"""
    settings = get_settings()
    db_path = Path(settings.db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_db() -> None:
    """创建表（如不存在）。幂等。"""
    with connect() as conn:
        conn.executescript(SCHEMA_RESEARCHES)
        conn.executescript(SCHEMA_EVENT_LOG)
        conn.executescript(INDEX_EVENT_LOG)
        conn.commit()
    logger.info("db_init_ok")


def insert_research(state: ResearchState) -> None:
    """插入一条新研究记录（status 通常是 pending/running）。"""
    status = (
        state.status.value
        if isinstance(state.status, ResearchStatus)
        else state.status
    )
    created = state.started_at.isoformat() if state.started_at else now_iso()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO researches
                (id, topic, status, created_at, updated_at, report_path, summary, total_rounds, error)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                state.run_id,
                state.topic,
                status,
                created,
                now_iso(),
                None,
                _derive_summary(state),
                sum(sub.rounds_used for sub in state.sub_question_results),
                state.error,
            ),
        )
        conn.commit()


def update_research(
    run_id: str,
    *,
    status: str | None = None,
    report_path: str | None = None,
    summary: str | None = None,
    total_rounds: int | None = None,
    error: str | None = None,
) -> None:
    """部分更新研究记录。None 字段不动。"""
    sets: list[str] = ["updated_at = ?"]
    values: list = [now_iso()]
    if status is not None:
        sets.append("status = ?")
        values.append(status)
    if report_path is not None:
        sets.append("report_path = ?")
        values.append(report_path)
    if summary is not None:
        sets.append("summary = ?")
        values.append(summary)
    if total_rounds is not None:
        sets.append("total_rounds = ?")
        values.append(total_rounds)
    if error is not None:
        sets.append("error = ?")
        values.append(error)
    values.append(run_id)
    with connect() as conn:
        conn.execute(
            f"UPDATE researches SET {', '.join(sets)} WHERE id = ?",
            values,
        )
        conn.commit()


def get_research(run_id: str) -> dict | None:
    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM researches WHERE id = ?", (run_id,)
        ).fetchone()
        return dict(row) if row else None


def list_researches(limit: int = 50) -> list[dict]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM researches ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def _derive_summary(state: ResearchState) -> str:
    """从 report_markdown 的「## 摘要」章节提取前 100 字，作为列表页预览。"""
    if not state.report_markdown:
        return ""
    return _extract_markdown_section(state.report_markdown, "## 摘要", max_chars=100)


def _extract_markdown_section(markdown: str, header: str, max_chars: int) -> str:
    """提取指定 header 下的纯文本内容（直到下一个 ## 章节）。"""
    lines = markdown.split("\n")
    in_section = False
    captured: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped == header:
            in_section = True
            continue
        if in_section:
            if stripped.startswith("## "):
                break
            if stripped:
                captured.append(stripped)
    text = " ".join(captured)
    return text[:max_chars]