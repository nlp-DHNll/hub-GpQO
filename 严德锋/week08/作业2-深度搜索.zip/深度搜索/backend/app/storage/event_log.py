"""event_log 表的写入与查询。

每条 SSE 事件都写入 SQLite，便于：
1. 事后回溯「那次研究第 3 轮搜了什么」
2. 前端历史详情页的「研究日志」折叠区（重放）
3. 调试与监控
"""
from __future__ import annotations

import json

from app.storage.db import connect, now_iso


def insert_event(run_id: str, event_type: str, payload: dict) -> None:
    """写入一条事件。payload 序列化为 JSON。"""
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO event_log (run_id, event_type, payload, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (
                run_id,
                event_type,
                json.dumps(payload, ensure_ascii=False, default=str),
                now_iso(),
            ),
        )
        conn.commit()


def get_events(run_id: str) -> list[dict]:
    """按 id 升序获取某 run 的所有事件。"""
    with connect() as conn:
        rows = conn.execute(
            "SELECT event_type, payload, created_at FROM event_log WHERE run_id = ? ORDER BY id ASC",
            (run_id,),
        ).fetchall()
    return [
        {
            "event_type": r["event_type"],
            "payload": json.loads(r["payload"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]


def count_events(run_id: str) -> int:
    """统计事件数（用于状态展示）。"""
    with connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM event_log WHERE run_id = ?", (run_id,)
        ).fetchone()
    return int(row["n"])


def get_events_since(run_id: str, last_id: int = 0) -> list[dict]:
    """获取 id > last_id 的事件，按 id 升序。

    给 SSE 路由用：每次轮询拿到增量事件。包含 id 字段供前端跟踪。
    """
    with connect() as conn:
        rows = conn.execute(
            """SELECT id, event_type, payload, created_at
               FROM event_log
               WHERE run_id = ? AND id > ?
               ORDER BY id ASC""",
            (run_id, last_id),
        ).fetchall()
    return [
        {
            "id": r["id"],
            "event_type": r["event_type"],
            "payload": json.loads(r["payload"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]