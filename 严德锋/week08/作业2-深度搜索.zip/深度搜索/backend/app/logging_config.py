"""Structured JSON logging via loguru.

使用 loguru 内置 `serialize=True` 输出 JSON 行，避免自定义 formatter 与内置 format_map 冲突。
"""
from __future__ import annotations

import sys

from loguru import logger


def configure_logging() -> None:
    logger.remove()
    logger.add(
        sys.stderr,
        serialize=True,
        level="INFO",
        enqueue=False,
    )


def get_logger():
    return logger