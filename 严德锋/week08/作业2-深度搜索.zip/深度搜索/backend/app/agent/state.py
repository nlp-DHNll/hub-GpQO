"""Orchestrator 内部状态类型与 helper。

数据契约本身在 `app/models.py`（Pydantic），本文件提供：
- 序列化辅助（ResearchState ↔ JSON）
- sub-question 状态合并 helper
- 给前端 SSE 用的子集投影

为什么独立一个文件：让 orchestrator.py 关注主循环，状态操作集中在这里。
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.models import EvidenceItem, ResearchState, SubQuestionResult


def utcnow() -> datetime:
    """统一的 UTC now，便于测试与跨时区。"""
    return datetime.now(timezone.utc)


def init_state(run_id: str, topic: str) -> ResearchState:
    """创建初始状态。"""
    return ResearchState(
        run_id=run_id,
        topic=topic,
        status="running",
        started_at=utcnow(),
    )


def append_evidence(
    state: ResearchState,
    sub_index: int,
    new_evidence: list[EvidenceItem],
) -> None:
    """向指定子问题的 evidence 列表追加新证据，并确保 SubQuestionResult 存在。"""
    while len(state.sub_question_results) <= sub_index:
        idx = len(state.sub_question_results)
        state.sub_question_results.append(
            SubQuestionResult(question=state.sub_questions[idx] if idx < len(state.sub_questions) else "")
        )
    state.sub_question_results[sub_index].evidence.extend(new_evidence)


def format_evidence_block(state: ResearchState) -> str:
    """把整份 ResearchState 序列化成给 Writer 的纯文本块。"""
    lines: list[str] = []
    for i, sub in enumerate(state.sub_question_results):
        lines.append(f"### 子问题 {i + 1}：{sub.question}")
        if not sub.evidence:
            lines.append("（无证据）")
            continue
        for j, e in enumerate(sub.evidence, 1):
            lines.append(f"  {j}. [{e.title or '(无标题)'}]({e.url})")
            lines.append(f"     域名: {e.source_domain or '(未知)'}")
            if e.summary:
                lines.append(f"     摘要: {e.summary[:300]}")
            elif e.snippet:
                lines.append(f"     摘要: {e.snippet[:300]}")
        lines.append("")
    return "\n".join(lines)


def mark_completed(state: ResearchState) -> None:
    state.status = "completed"
    state.finished_at = utcnow()


def mark_failed(state: ResearchState, error: str) -> None:
    state.status = "failed"
    state.error = error
    state.finished_at = utcnow()


def mark_cancelled(state: ResearchState) -> None:
    state.status = "cancelled"
    state.error = "cancelled by user"
    state.finished_at = utcnow()