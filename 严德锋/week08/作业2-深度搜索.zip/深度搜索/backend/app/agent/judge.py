"""Judge Agent — 判定当前证据是否足以回答子问题。

每轮检索后调用。输入：子问题 + 已收集证据；输出：decision (sufficient/continue) + 可选的 refined_query。

为什么独立成 Agent（不与 Researcher 合并）：
- Researcher 的 system prompt 已被搜索结果噪声污染
- Judge 是干净 prompt 上的「够了没」二元判断，更准
- 模块化便于单独调优 prompt
"""
from __future__ import annotations

import json
import re

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.logging_config import get_logger
from app.models import EvidenceItem
from app.settings import get_settings


logger = get_logger()


JUDGE_SYSTEM_PROMPT = """你是研究质量判定员（research quality judge）。

判断当前已收集的证据是否足以回答一个子问题。

Topic: {topic}
Sub-question: {sub_question}
Round: {round}/{max_rounds}
Evidence count: {n_evidence}

判定准则：
- "sufficient"：证据覆盖了子问题的主要方面，且至少有 3 条不同来源
- "continue"：证据不够，需要继续搜；若当前 query 偏了，可给 refined_query

只输出 JSON 对象，不要任何解释或 markdown 围栏。

Output format:
{{
  "decision": "sufficient" | "continue",
  "refined_query": "string or null",
  "reason": "简短理由"
}}
"""


def make_judge(model: str | None = None, temperature: float = 0.0) -> ChatAnthropic:
    settings = get_settings()
    return ChatAnthropic(
        model=model or settings.llm_model,
        temperature=temperature,
        api_key=settings.anthropic_api_key or None,
    )


async def judge_sufficiency(
    topic: str,
    sub_question: str,
    evidence: list[EvidenceItem],
    round_num: int,
    llm: ChatAnthropic | None = None,
) -> dict:
    """判定证据是否足够。

    Returns:
        dict with keys: decision, refined_query (optional), reason
    """
    llm = llm or make_judge()
    max_rounds = get_settings().max_rounds_per_subquestion
    prompt = JUDGE_SYSTEM_PROMPT.format(
        topic=topic,
        sub_question=sub_question,
        round=round_num,
        max_rounds=max_rounds,
        n_evidence=len(evidence),
    )
    msg = await llm.ainvoke(
        [
            SystemMessage(content=prompt),
            HumanMessage(content="Judge."),
        ]
    )
    text = _extract_text(msg.content)
    parsed = _parse_decision(text)
    if not parsed:
        # 兜底：>=3 条就当 sufficient，否则 continue
        if len(evidence) >= 3:
            return {"decision": "sufficient", "reason": "fallback: 3+ sources"}
        return {"decision": "continue", "reason": "fallback: insufficient"}
    return parsed


def _extract_text(content) -> str:  # type: ignore[no-untyped-def]
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict):
            return first.get("text", "")
        return str(first)
    return str(content)


_JSON_OBJ_RE = re.compile(r"\{[^{}]*\}", re.DOTALL)


def _parse_decision(text: str) -> dict:
    """解析 LLM 输出。"""
    match = _JSON_OBJ_RE.search(text)
    if match:
        try:
            obj = json.loads(match.group(0))
            if isinstance(obj, dict):
                return {
                    "decision": obj.get("decision", "continue"),
                    "refined_query": obj.get("refined_query"),
                    "reason": obj.get("reason", ""),
                }
        except json.JSONDecodeError:
            pass
    return {}


async def researcher_decide_query(  # legacy helper kept for smoke test
    topic: str, sub_question: str, evidence: list[EvidenceItem], round_num: int
) -> str | None:
    """Step 3 stub：Researcher 决定下一轮 query（Step 4 会接入真实 bocha_search 工具）。"""
    if len(evidence) >= 3:
        return None
    return f"{sub_question} 第{round_num}轮搜索"