"""置信度算法（纯函数）。

关键约定：置信度计算**不**让 LLM 自己做，全部在 Python 层计算后打标到 Markdown。
这是为了避免 LLM 在「自卖自夸」时夸大自己答案的可靠性。

算法（per spec v1.1）：
- 高 = 来源数 ≥3 且不同域名 ≥3
- 中 = 来源数 1~2 或 ≥3 但全在同一域名
- 低 = 无来源（纯模型推断）
"""
from __future__ import annotations

from enum import Enum

from app.models import EvidenceItem


class Confidence(str, Enum):
    HIGH = "高"
    MEDIUM = "中"
    LOW = "低"


def confidence_from_sources(evidence: list[EvidenceItem]) -> Confidence:
    """根据来源数与域名多样性计算置信度。

    Args:
        evidence: 单条结论 / 一节 / 一段 关联的证据列表

    Returns:
        Confidence.HIGH / MEDIUM / LOW
    """
    if not evidence:
        return Confidence.LOW

    distinct_domains = {e.source_domain for e in evidence if e.source_domain}

    if len(evidence) >= 3 and len(distinct_domains) >= 3:
        return Confidence.HIGH
    return Confidence.MEDIUM


def confidence_label(evidence: list[EvidenceItem]) -> str:
    """置信度的人类可读标签（用于报告 Markdown 标注）。

    - 有来源时：来源数 + 置信等级
    - 无来源时：「模型推断」
    """
    if not evidence:
        return "[模型推断]"
    level = confidence_from_sources(evidence).value
    return f"[来源:{len(evidence)}, 置信:{level}]"