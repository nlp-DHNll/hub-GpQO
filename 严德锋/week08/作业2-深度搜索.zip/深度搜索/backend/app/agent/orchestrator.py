"""Orchestrator — 串行编排 4 个 Agent 的主循环。

主流程：
1. Planner(topic)                                    → sub_questions
2. for each sub_question:
       for round in 1..MAX_ROUNDS:
           Researcher.decide_next_query(...)         → next_query
           if stop or no query: break
           search_fn(next_query)                      → new evidence
           Judge.judge_sufficiency(...)               → decision
           if decision == "sufficient": break
3. Writer.synthesize(state)                          → report_markdown
4. apply_confidence_tags + 状态标记 completed

调用层：
- 所有 LLM 实例可通过参数注入（便于单测 mock）
- search_fn 通过参数注入（Step 3 stub / Step 4 接 bocha）
- on_event 回调用于推送 SSE 事件（Step 5）
"""
from __future__ import annotations

from typing import Awaitable, Callable

from langchain_anthropic import ChatAnthropic

from app.agent import judge, planner, researcher, writer
from app.agent.state import (
    append_evidence,
    init_state,
    mark_cancelled,
    mark_completed,
    mark_failed,
)
import asyncio
from app.logging_config import get_logger
from app.models import EvidenceItem, ResearchState, SubQuestionResult
from app.settings import get_settings


logger = get_logger()


SearchFn = Callable[[str], Awaitable[list[EvidenceItem]]]
EventFn = Callable[[str, dict], Awaitable[None]]


async def run_research(
    topic: str,
    run_id: str,
    *,
    search_fn: SearchFn | None = None,
    on_event: EventFn | None = None,
    planner_llm: ChatAnthropic | None = None,
    researcher_llm: ChatAnthropic | None = None,
    judge_llm: ChatAnthropic | None = None,
    writer_llm: ChatAnthropic | None = None,
) -> ResearchState:
    """执行一次完整的研究流程并返回最终状态。"""
    settings = get_settings()
    state = init_state(run_id=run_id, topic=topic)

    async def emit(event: str, data: dict) -> None:
        if on_event is not None:
            try:
                await on_event(event, data)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"event_emit_failed | event={event} | error={e!s}")

    try:
        # 1. Planner
        logger.info(f"orchestrator_planner_start | run_id={run_id}")
        sub_questions = await planner.plan(topic, llm=planner_llm)
        state.sub_questions = sub_questions
        await emit("sub_questions_generated", {"questions": sub_questions})

        # 2. 每个子问题独立循环
        for sub_index, sub_q in enumerate(sub_questions):
            accumulated: list[EvidenceItem] = []
            max_rounds = settings.max_rounds_per_subquestion
            rounds_used = 0

            for round_num in range(1, max_rounds + 1):
                rounds_used = round_num
                state.current_sub_index = sub_index
                state.current_round = round_num

                # Researcher 决定下一轮 query
                next_query, stop = await researcher.decide_next_query(
                    topic=topic,
                    sub_question=sub_q,
                    evidence=accumulated,
                    round_num=round_num,
                    llm=researcher_llm,
                )

                if stop or not next_query:
                    break

                # 搜索（Step 3 可能是 None；Step 4 接 bocha_search）
                if search_fn is None:
                    # Step 3 / 测试用：把 query 当成伪证据返回
                    accumulated.append(
                        EvidenceItem(
                            url=f"https://example.com/{round_num}",
                            title=f"placeholder for: {next_query}",
                            snippet="",
                            summary="(no real search in Step 3)",
                            source_domain="example.com",
                            round=round_num,
                            sub_question_index=sub_index,
                        )
                    )
                else:
                    await emit(
                        "search_started",
                        {"round": round_num, "query": next_query, "sub_index": sub_index},
                    )
                    new_evidence = await search_fn(next_query)
                    for e in new_evidence:
                        e.round = round_num
                        e.sub_question_index = sub_index
                    accumulated.extend(new_evidence)
                    for e in new_evidence:
                        await emit(
                            "page_read",
                            {
                                "round": round_num,
                                "url": e.url,
                                "title": e.title,
                                "summary_length": len(e.summary),
                                "fetched_full": e.fetched_full,
                            },
                        )

                # Judge 判定
                decision_obj = await judge.judge_sufficiency(
                    topic=topic,
                    sub_question=sub_q,
                    evidence=accumulated,
                    round_num=round_num,
                    llm=judge_llm,
                )
                await emit(
                    "round_done",
                    {
                        "round": round_num,
                        "decision": decision_obj.get("decision", "continue"),
                        "reason": decision_obj.get("reason", ""),
                    },
                )
                if decision_obj.get("decision") == "sufficient":
                    break

            # 子问题结束，保存 evidence 到 state
            while len(state.sub_question_results) <= sub_index:
                idx = len(state.sub_question_results)
                state.sub_question_results.append(
                    SubQuestionResult(question=state.sub_questions[idx] if idx < len(state.sub_questions) else "")
                )
            state.sub_question_results[sub_index].question = sub_q
            state.sub_question_results[sub_index].evidence = list(accumulated)
            state.sub_question_results[sub_index].rounds_used = rounds_used

        # 3. Writer 综合
        await emit("synthesis_started", {"total_sub_questions": len(state.sub_questions)})
        report = await writer.synthesize(state, llm=writer_llm)
        report_with_tags = writer.apply_confidence_tags(report, state)
        state.report_markdown = report_with_tags

        mark_completed(state)
        await emit("report_done", {"report_id": state.run_id, "report_markdown": report_with_tags})
        return state

    except asyncio.CancelledError:
        logger.info(f"orchestrator_cancelled | run_id={run_id}")
        mark_cancelled(state)
        await emit("error", {"code": "cancelled", "message": "cancelled by user"})
        raise

    except Exception as e:  # noqa: BLE001
        logger.exception(f"orchestrator_failed | run_id={run_id} | error={e!s}")
        mark_failed(state, str(e))
        await emit("error", {"code": "orchestrator_error", "message": str(e)})
        return state