"""Writer Agent — 把所有子问题的证据综合成最终 Markdown 报告。

职责单一：输入 topic + 全部证据 → 输出 4 章节的 Markdown。
不做置信度判断（由 confidence.py 纯函数完成），不做检索。
"""
from __future__ import annotations

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.agent.confidence import confidence_label
from app.agent.state import format_evidence_block
from app.logging_config import get_logger
from app.models import ResearchState
from app.settings import get_settings


logger = get_logger()


WRITER_SYSTEM_PROMPT = """你是研究报告撰写员（research report writer）。

把收集到的证据综合成结构化的 Markdown 报告。**严格**按以下 4 个章节顺序与命名：

1. ## 摘要
   200~300 字总览，覆盖主题与核心结论。

2. ## 分节正文
   按子问题组织，每个子问题一个 ### 子标题。
   每个子标题下用若干段总结证据，可以加 #### 次级小节。

3. ## 关键结论
   3~5 个 bullet 点。

4. ## 遗留问题
   当前证据无法回答的开放问题。

【置信度标注要求 — 严格】
每个关键论断句末必须挂一个标签：
- 若该论断由 ≥3 条不同来源支撑：句末加 [来源:N, 置信:高]
- 若由 1~2 条来源支撑：句末加 [来源:N, 置信:中]
- 若无来源支撑（你的推断）：句末加 [模型推断]

Topic: {topic}

Evidence（按子问题分组）：
{evidence_block}

只输出最终 Markdown 报告本身，不要任何前言或解释。
"""


def make_writer(model: str | None = None, temperature: float = 0.2) -> ChatAnthropic:
    """Writer 用略高的 temperature（0.2）以提升表达自然度；其他 Agent 用 0。"""
    settings = get_settings()
    return ChatAnthropic(
        model=model or settings.llm_model,
        temperature=temperature,
        api_key=settings.anthropic_api_key or None,
    )


async def synthesize(
    state: ResearchState,
    llm: ChatAnthropic | None = None,
) -> str:
    """生成最终 Markdown 报告。"""
    llm = llm or make_writer()
    evidence_block = format_evidence_block(state)
    prompt = WRITER_SYSTEM_PROMPT.format(
        topic=state.topic,
        evidence_block=evidence_block,
    )
    msg = await llm.ainvoke(
        [
            SystemMessage(content=prompt),
            HumanMessage(content="Write the report."),
        ]
    )
    text = _extract_text(msg.content)
    return text.strip()


def _extract_text(content) -> str:  # type: ignore[no-untyped-def]
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict):
            return first.get("text", "")
        return str(first)
    return str(content)


def apply_confidence_tags(markdown: str, state: ResearchState) -> str:
    """后处理：在 Markdown 末尾追加节级置信度汇总表。

    Writer 在 prompt 里已被要求逐句打标；这里再加一个节级总览（节标题 + 证据来源数）。
    """
    lines = ["", "---", "", "## 置信度说明", ""]
    for i, sub in enumerate(state.sub_question_results):
        level = confidence_label(sub.evidence)
        lines.append(f"- 子问题 {i + 1}（{sub.question}）：{level}")
    if not state.sub_question_results:
        lines.append("- （无证据）")
    return markdown + "\n" + "\n".join(lines) + "\n"