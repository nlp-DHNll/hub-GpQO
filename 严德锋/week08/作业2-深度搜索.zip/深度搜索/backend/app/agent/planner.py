"""Planner Agent — 拆解主题为 3-5 个子问题。

职责单一：输入主主题 → 输出 3-5 个聚焦且不重叠的子问题。
不做检索、不做判断。失败时回退为「直接用主主题作唯一一个子问题」。
"""
from __future__ import annotations

import json
import re

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.logging_config import get_logger
from app.settings import get_settings


logger = get_logger()


PLANNER_SYSTEM_PROMPT = """你是研究规划助手（research planning assistant）。

给定一个研究主题，把它拆成 3~5 个具体的、可被网络搜索回答的子问题。这些子问题合起来能产出一份完整的研究报告。

规则：
- 必须 3~5 个子问题（不多不少）
- 每个子问题必须可被网络搜索回答
- 子问题应该覆盖：定义/背景、现状/数据、关键事实/争议、开放问题
- 子问题之间不重叠

只输出 JSON 字符串数组，不要任何解释或 markdown 围栏。

Example:
Topic: 中国新能源汽车市场
Output: ["中国新能源汽车市场规模与增长率", "主要厂商竞争格局", "政策支持与补贴现状", "技术路线之争（纯电 vs 混动）", "未来 3 年趋势预测"]
"""


def make_planner(model: str | None = None, temperature: float = 0.0) -> ChatAnthropic:
    """构造 Planner LLM。模型默认从 settings.llm_model 读。"""
    settings = get_settings()
    return ChatAnthropic(
        model=model or settings.llm_model,
        temperature=temperature,
        api_key=settings.anthropic_api_key or None,
    )


async def plan(topic: str, llm: ChatAnthropic | None = None) -> list[str]:
    """给定主题，生成 3-5 个子问题。失败时回退为 [topic]。"""
    llm = llm or make_planner()
    msg = await llm.ainvoke(
        [
            SystemMessage(content=PLANNER_SYSTEM_PROMPT),
            HumanMessage(content=f"Topic: {topic}"),
        ]
    )
    text = _extract_text(msg.content)
    questions = _parse_questions(text)
    if not questions:
        logger.warning(f"planner_no_questions | topic={topic} | raw={text[:200]!r}")
        return [topic]
    return questions[:5]


def _extract_text(content) -> str:  # type: ignore[no-untyped-def]
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict):
            return first.get("text", "")
        return str(first)
    return str(content)


_JSON_ARRAY_RE = re.compile(r"\[[^\[\]]*\]", re.DOTALL)


def _parse_questions(text: str) -> list[str]:
    """从 LLM 输出中提取 JSON 数组。"""
    match = _JSON_ARRAY_RE.search(text)
    if not match:
        return []
    try:
        parsed = json.loads(match.group(0))
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(q).strip() for q in parsed if q]