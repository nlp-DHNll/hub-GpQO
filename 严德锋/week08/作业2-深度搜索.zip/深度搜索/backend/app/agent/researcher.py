"""Researcher Agent — 为单个子问题收集证据。

Step 3 版本：纯 LLM 驱动，决定下一轮搜索 query（不实际搜索）。
Step 4 会接入 bocha_search / fetch_full_page 两个 LangChain tool，由 orchestrator 在调用层包工具调用。

为什么 Researcher 不直接持有工具调用循环：
- LangChain 的 AgentExecutor tool-call 循环会把搜索噪声带入 Researcher 的 history
- 我们把「决定 query」与「执行搜索」解耦：
  - Researcher 只输出 next_query
  - orchestrator 调 bocha 拿结果、追加到 evidence
  - Judge 独立判定
- 同样的契约下，Step 4 只需要替换 search_fn 即可接入真实工具
"""
from __future__ import annotations

import json
import re

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.logging_config import get_logger
from app.models import EvidenceItem
from app.settings import get_settings


logger = get_logger()


RESEARCHER_SYSTEM_PROMPT = """你是研究调查员（research investigator）。

给定研究主题与一个具体的子问题，每轮你需要决定下一轮的搜索关键词。
工作循环：最多 5 轮；每轮你看到当前证据列表，决定下一步：
- 若证据已足够回答子问题，输出 stop=true
- 若还需要更多证据，输出下一轮搜索 query

Topic: {topic}
Sub-question: {sub_question}
Round: {round}/{max_rounds}
Evidence count: {n_evidence}
Evidence titles (最多 10 条):
{evidence_titles}

只输出 JSON 对象，不要任何解释或 markdown 围栏。

Output format:
{{
  "next_query": "string or null",
  "stop": true | false
}}
"""


def make_researcher(model: str | None = None, temperature: float = 0.0) -> ChatAnthropic:
    settings = get_settings()
    return ChatAnthropic(
        model=model or settings.llm_model,
        temperature=temperature,
        api_key=settings.anthropic_api_key or None,
    )


async def decide_next_query(
    topic: str,
    sub_question: str,
    evidence: list[EvidenceItem],
    round_num: int,
    llm: ChatAnthropic | None = None,
) -> tuple[str | None, bool]:
    """决定下一轮搜索关键词。

    Returns:
        (next_query, stop)：
        - stop=True 表示「够了」,next_query=None
        - stop=False 且 next_query 不为空表示继续
        - stop=False 且 next_query 为 None 时 orchestrator 也视为终止
    """
    llm = llm or make_researcher()
    max_rounds = get_settings().max_rounds_per_subquestion

    titles = "\n".join(
        f"- {e.title or '(无标题)'}" for e in evidence[:10]
    ) or "(无)"

    prompt = RESEARCHER_SYSTEM_PROMPT.format(
        topic=topic,
        sub_question=sub_question,
        round=round_num,
        max_rounds=max_rounds,
        n_evidence=len(evidence),
        evidence_titles=titles,
    )
    msg = await llm.ainvoke(
        [
            SystemMessage(content=prompt),
            HumanMessage(content="Decide."),
        ]
    )
    text = _extract_text(msg.content)
    return _parse_decision(text)


def _extract_text(content) -> str:  # type: ignore[no-untyped-def]
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict):
            return first.get("text", "")
        return str(first)
    return str(content)


_JSON_OBJ_RE = re.compile(r"\{[^{}]*\}", re.DOTALL)


def _parse_decision(text: str) -> tuple[str | None, bool]:
    match = _JSON_OBJ_RE.search(text)
    if match:
        try:
            obj = json.loads(match.group(0))
            stop = bool(obj.get("stop"))
            q = obj.get("next_query")
            return (str(q).strip() if q else None, stop)
        except json.JSONDecodeError:
            pass
    # 兜底：文本含 stop 字样当 stop；否则整段当 query
    lowered = text.lower()
    if "stop" in lowered and "next_query" not in lowered:
        return (None, True)
    cleaned = text.strip().strip('"').strip("'")
    return (cleaned[:200], False)