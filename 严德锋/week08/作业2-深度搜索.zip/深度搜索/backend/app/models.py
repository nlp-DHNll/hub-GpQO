"""Pydantic models — API request/response 与 agent 内部状态。

Agent 之间通过 ResearchState TypedDict 共享数据；与前端通信用 Pydantic BaseModel。
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


# ---- Status enum ----

class ResearchStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


# ---- API request/response ----

class StartResearchRequest(BaseModel):
    topic: str = Field(..., min_length=1, max_length=500)


class StartResearchResponse(BaseModel):
    run_id: str


# ---- Agent 内部状态 ----

class EvidenceItem(BaseModel):
    url: str
    title: str
    snippet: str = ""
    summary: str = ""
    source_domain: str = ""
    fetched_full: bool = False
    round: int = 0
    sub_question_index: int = 0


class SubQuestionResult(BaseModel):
    question: str
    rounds_used: int = 0
    evidence: list[EvidenceItem] = Field(default_factory=list)


class ResearchState(BaseModel):
    """贯穿 4 个 Agent 的中间状态。"""

    run_id: str
    topic: str
    sub_questions: list[str] = Field(default_factory=list)
    sub_question_results: list[SubQuestionResult] = Field(default_factory=list)
    current_sub_index: int = 0
    current_round: int = 0
    report_markdown: str = ""
    status: ResearchStatus = ResearchStatus.PENDING
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


# ---- API 详情响应 ----

class ResearchSummary(BaseModel):
    """历史列表页用的精简信息。"""

    id: str
    topic: str
    status: ResearchStatus
    created_at: datetime
    updated_at: datetime
    summary: str
    total_rounds: int


class ResearchDetail(BaseModel):
    """详情页用的完整信息（含报告 Markdown）。"""

    id: str
    topic: str
    status: ResearchStatus
    created_at: datetime
    updated_at: datetime
    summary: str
    total_rounds: int
    report_markdown: str
    sub_questions: list[str]
    error: str | None = None