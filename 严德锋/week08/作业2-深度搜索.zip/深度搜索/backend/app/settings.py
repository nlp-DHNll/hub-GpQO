"""Application settings loaded from .env with fallback to README dev key.

兜底策略：.env 缺失 → 用 README 里的开发 key。这样开发同学 clone 下来即可跑。
生产部署只需设置 BOCHA_API_KEY 与 ANTHROPIC_API_KEY 环境变量覆盖。
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


# README 里的开发 Bocha key（仅兜底用）。生产环境请通过 .env 设置 BOCHA_API_KEY 覆盖。
README_DEV_BOCHA_KEY = "sk-3d2293ad83aa4823a7c7ce8dd5ff8c72"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ---- Bocha search ----
    bocha_api_key: str = ""
    bocha_endpoint: str = "https://api.bocha.cn/v1/web-search"
    bocha_count: int = 10

    # ---- Anthropic ----
    anthropic_api_key: str = ""
    llm_model: str = "claude-sonnet-5"

    # ---- Storage ----
    reports_dir: Path = Path("reports")
    db_path: Path = Path("data/research.db")

    # ---- Server ----
    cors_origins: list[str] = ["http://localhost:3000"]

    # ---- Research limits ----
    max_rounds_per_subquestion: int = 5
    summary_min_length: int = 200

    def resolved_bocha_key(self) -> str:
        """Bocha key: .env 优先，缺失则用 README 开发 key。"""
        return self.bocha_api_key or README_DEV_BOCHA_KEY


@lru_cache
def get_settings() -> Settings:
    return Settings()