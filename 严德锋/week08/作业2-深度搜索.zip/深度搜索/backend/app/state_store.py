"""运行时状态注册表：run_id → asyncio.Task。

仅在内存，重启后丢失。DELETE /api/research/{id} 通过这里找到 task 并 cancel。

不依赖 SQLite — task 对象本身无法序列化。
"""
from __future__ import annotations

import asyncio
from typing import Optional


_tasks: dict[str, asyncio.Task] = {}


def register(run_id: str, task: asyncio.Task) -> None:
    _tasks[run_id] = task


def get(run_id: str) -> Optional[asyncio.Task]:
    return _tasks.get(run_id)


def unregister(run_id: str) -> None:
    _tasks.pop(run_id, None)


def cancel(run_id: str) -> bool:
    """取消指定 run 的任务。返回 True 如果成功发起了取消。

    已经完成的任务返回 False。
    """
    task = _tasks.get(run_id)
    if task is None or task.done():
        return False
    task.cancel()
    return True


def active_count() -> int:
    return sum(1 for t in _tasks.values() if not t.done())