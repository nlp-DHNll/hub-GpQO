"""全页面内容抓取：httpx 拉 HTML，readability 提取正文。

用于 Bocha summary 太短或缺失时的兜底（spec v1.1：summary < 200 字或缺失 → 全页面抓取）。
失败一律返回空字符串，不抛异常。
"""
from __future__ import annotations

import re

import httpx
from readability import Document

from app.logging_config import get_logger


logger = get_logger()


DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

DEFAULT_MAX_CHARS = 5000  # 抓回内容上限（防止巨型页面把 token 撑爆）


async def fetch_full_page(
    url: str,
    timeout: float = 15.0,
    max_chars: int = DEFAULT_MAX_CHARS,
) -> str:
    """抓取 URL 主内容文本。失败返回空字符串。"""
    try:
        async with httpx.AsyncClient(
            timeout=timeout,
            headers={"User-Agent": DEFAULT_USER_AGENT},
            follow_redirects=True,
        ) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            html = resp.text
    except httpx.TimeoutException:
        logger.warning(f"fetch_timeout | url={url}")
        return ""
    except httpx.HTTPStatusError as e:
        logger.warning(f"fetch_http_error | url={url} | status={e.response.status_code}")
        return ""
    except Exception as e:
        logger.warning(f"fetch_failed | url={url} | error={e!s}")
        return ""

    return _extract_text(html, max_chars=max_chars)


def _extract_text(html: str, max_chars: int) -> str:
    """用 readability 提取主内容，剥标签，归一空白。"""
    try:
        doc = Document(html)
        cleaned_html = doc.summary(html_partial=True)
    except Exception as e:
        logger.warning(f"readability_failed | error={e!s}")
        return ""
    text = re.sub(r"<[^>]+>", " ", cleaned_html)
    text = re.sub(r"\s+", " ", text).strip()
    # 解码常见 HTML 实体（readability 偶尔残留）
    text = (
        text.replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&#39;", "'")
    )
    return text[:max_chars]