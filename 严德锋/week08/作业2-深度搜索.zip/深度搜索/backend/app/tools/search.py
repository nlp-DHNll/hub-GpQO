"""研究流程用的 search 函数：包装 Bocha 搜索 + 必要时全页面抓取兜底。

策略（spec v1.1）：
1. 调 Bocha web-search 拿结果（含 AI 摘要）
2. 对每条结果，若 summary < SUMMARY_MIN_LENGTH，调 fetcher 抓全页面
3. 拼成 EvidenceItem 列表返回给 orchestrator

为什么单独放在 tools/search.py 而不是 tools/bocha.py：
- bocha.py 是 Bocha API 客户端本身（与协议对齐）
- search.py 是研究语义的「search_fn」（与 orchestrator 对齐）
- 分层清晰，单测分别覆盖
"""
from __future__ import annotations

from app.logging_config import get_logger
from app.models import EvidenceItem
from app.settings import get_settings
from app.tools import bocha, fetcher


logger = get_logger()


async def search_with_fallback(query: str) -> list[EvidenceItem]:
    """Bocha 搜索 + summary 太短时全页面抓取兜底。

    这是给 orchestrator 注入的 search_fn 实现。
    """
    settings = get_settings()
    bocha_results = await bocha.search(query, with_summary=True)

    evidence: list[EvidenceItem] = []
    for r in bocha_results:
        summary = r.summary or r.snippet or ""
        fetched_full = False

        if len(summary) < settings.summary_min_length:
            full_text = await fetcher.fetch_full_page(r.url)
            if full_text:
                summary = full_text
                fetched_full = True

        if not summary:
            # 没有 summary 也没有 snippet，跳过这条
            continue

        evidence.append(
            EvidenceItem(
                url=r.url,
                title=r.title,
                snippet=r.snippet,
                summary=summary,
                source_domain=r.source_domain,
                fetched_full=fetched_full,
            )
        )

    if not evidence:
        logger.warning(f"search_no_evidence | query={query}")

    return evidence