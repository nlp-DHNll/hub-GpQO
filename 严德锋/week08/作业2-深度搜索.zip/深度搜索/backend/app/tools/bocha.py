"""Bocha AI web-search API 异步客户端。

唯一外部依赖的搜索源。响应结构兼容多种可能（Bocha 未公开完整 schema）：
- 优先按 `data.webPages.value[]` 取
- 回退 `data.results[]` / 顶层 `results[]`
- 单条 record 兼容 `url/link`、`name/title`、`snippet/description`、`summary` 字段

失败策略：超时 / 非 2xx / JSON 解析失败一律返回空列表 + 记录 warning 日志，
不抛异常冒泡（让上层 agent 自己判断「没搜到」并进入下一轮或终止）。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx

from app.logging_config import get_logger
from app.settings import get_settings


logger = get_logger()


@dataclass
class BochaResult:
    """单条 Bocha 搜索结果。"""

    url: str
    title: str
    snippet: str
    summary: str
    source_domain: str


async def search(
    query: str,
    count: int | None = None,
    with_summary: bool = True,
    timeout: float = 30.0,
) -> list[BochaResult]:
    """调用 Bocha web-search 端点。

    Args:
        query: 搜索关键词
        count: 返回结果数，默认从 settings 读
        with_summary: 是否要求返回 AI 摘要
        timeout: HTTP 超时（秒）

    Returns:
        list[BochaResult]；失败时返回空列表（不抛异常）
    """
    settings = get_settings()
    if count is None:
        count = settings.bocha_count

    payload = {
        "query": query,
        "summary": with_summary,
        "count": count,
    }
    headers = {
        "Authorization": f"Bearer {settings.resolved_bocha_key()}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                settings.bocha_endpoint,
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
    except httpx.TimeoutException:
        logger.warning(f"bocha_timeout | query={query}")
        return []
    except httpx.HTTPStatusError as e:
        logger.warning(
            f"bocha_http_error | query={query} | status={e.response.status_code}"
        )
        return []
    except Exception as e:
        logger.warning(f"bocha_request_failed | query={query} | error={e!s}")
        return []

    return _parse_results(data)


def _parse_results(data: dict[str, Any]) -> list[BochaResult]:
    """解析 Bocha 响应，兼容多种 JSON 结构。"""
    pages = (
        data.get("data", {}).get("webPages", {}).get("value", [])
        or data.get("data", {}).get("results", [])
        or data.get("results", [])
    )
    if not isinstance(pages, list):
        return []

    results: list[BochaResult] = []
    for item in pages:
        if not isinstance(item, dict):
            continue
        url = item.get("url") or item.get("link") or ""
        if not url:
            continue
        title = item.get("name") or item.get("title") or ""
        snippet = item.get("snippet") or item.get("description") or ""
        summary = item.get("summary") or ""
        try:
            domain = urlparse(url).netloc
        except Exception:
            domain = ""
        results.append(
            BochaResult(
                url=url,
                title=title,
                snippet=snippet,
                summary=summary,
                source_domain=domain,
            )
        )
    return results