"""FastAPI application entry — hello world + CORS + lifespan + 路由注册。

路由：
- /api/research/* —— 启动研究 / SSE 事件流 / 取消
- /api/reports/* —— 报告列表 / 详情 / 导出 / 重跑 / 重试
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.logging_config import configure_logging
from app.routes import reports as reports_routes
from app.routes import research as research_routes
from app.settings import get_settings
from app.storage import db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """启动时建表（幂等）。"""
    configure_logging()
    db.init_db()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging()

    app = FastAPI(
        title="深度研究助手",
        version="0.1.0",
        description="输入研究主题，自动产出带来源引用的结构化研究报告",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(research_routes.router)
    app.include_router(reports_routes.router)

    @app.get("/")
    async def root() -> dict[str, str]:
        return {"status": "ok", "service": "deep-research-backend"}

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "healthy", "version": app.version}

    return app


app = create_app()