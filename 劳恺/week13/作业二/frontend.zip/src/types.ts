/** 与后端 `sql_agent/models.py` 的契约一一对应。 */

export type WorkflowStatus =
  | 'completed'
  | 'needs_clarification'
  | 'cannot_fix'
  | 'repair_exhausted'
  | 'failed'

export interface WorkflowOutput {
  question: string
  answer: string
  sql: string | null
  tables: string[]
  row_count: number
  truncated: boolean
  repair_attempts: number
  evidence: string[]
  caveats: string[]
  error: string | null
  status: WorkflowStatus
  columns: string[]
  rows: string[][]
}

export interface Turn {
  question: string
  answer?: string
  sql?: string | null
  tables?: string[]
}

export interface HealthInfo {
  status: string
  has_api_key: boolean
  model: string
  summary_model: string
  db: string
  db_exists: boolean
  tables: number
}

export interface CatalogInfo {
  tables: string[]
  catalog: string
}

export type StreamEvent =
  | { type: 'stage'; node: string; stage: string }
  | { type: 'result'; output: WorkflowOutput }
  | { type: 'error'; message: string; output?: WorkflowOutput }

export type MessageRole = 'user' | 'agent'

export interface ChatMessage {
  id: number
  role: MessageRole
  text: string
  /** agent 消息才有 */
  output?: WorkflowOutput
  /** 流式过程中已完成的节点 */
  stages: string[]
  /** 还在等待结果 */
  pending: boolean
  /** 请求本身失败（网络、后端没起来等） */
  transportError?: string
}
