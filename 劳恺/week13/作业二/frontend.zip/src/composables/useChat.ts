import { ref } from 'vue'

import { fetchHealth, postQuery, streamQuery } from '../api'
import type { ChatMessage, HealthInfo, Turn, WorkflowOutput } from '../types'

let nextId = 1

export function useChat() {
  const messages = ref<ChatMessage[]>([])
  const busy = ref(false)
  const health = ref<HealthInfo | null>(null)
  /** 已经完成的对话轮次，发给后端当上下文 */
  const history = ref<Turn[]>([])

  async function loadHealth(): Promise<void> {
    try {
      health.value = await fetchHealth()
    } catch {
      health.value = null
    }
  }

  function applyOutput(message: ChatMessage, output: WorkflowOutput): void {
    message.output = output
    message.text = output.answer
    if (output.status !== 'failed') {
      history.value.push({
        question: output.question,
        answer: output.answer,
        sql: output.sql,
        tables: output.tables,
      })
    }
  }

  async function send(raw: string): Promise<void> {
    const question = raw.trim()
    if (!question || busy.value) return

    messages.value.push({
      id: nextId++,
      role: 'user',
      text: question,
      stages: [],
      pending: false,
    })
    messages.value.push({
      id: nextId++,
      role: 'agent',
      text: '',
      stages: [],
      pending: true,
    })
    // 必须从数组里取回**响应式代理**再改：push 进 ref 数组的是代理，
    // 本地变量仍指向原始对象，直接改它不会触发重新渲染。
    const reply = messages.value[messages.value.length - 1]
    busy.value = true

    const snapshot = history.value.slice()
    let sawEvent = false

    try {
      for await (const event of streamQuery(question, snapshot)) {
        sawEvent = true
        if (event.type === 'stage') {
          reply.stages.push(event.stage)
        } else if (event.type === 'result') {
          applyOutput(reply, event.output)
        } else if (event.type === 'error') {
          reply.transportError = event.message
        }
      }
      if (!sawEvent) {
        throw new Error('后端没有返回任何数据')
      }
    } catch (error) {
      if (!sawEvent) {
        // 流式没跑起来（后端没起、SSE 不通）时，退回一次性请求
        try {
          const output = await postQuery(question, snapshot)
          applyOutput(reply, output)
        } catch (fallbackError) {
          const detail =
            fallbackError instanceof Error
              ? fallbackError.message
              : String(fallbackError)
          reply.transportError = `请求失败：${detail}`
        }
      } else {
        const detail = error instanceof Error ? error.message : String(error)
        reply.transportError = `连接中断：${detail}`
      }
    } finally {
      reply.pending = false
      busy.value = false
    }
  }

  function reset(): void {
    messages.value = []
    history.value = []
  }

  return { messages, busy, health, history, loadHealth, send, reset }
}
