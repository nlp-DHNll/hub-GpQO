import type {
  CatalogInfo,
  HealthInfo,
  StreamEvent,
  Turn,
  WorkflowOutput,
} from './types'

/**
 * 开发时走 Vite 的 proxy（见 vite.config.ts），生产构建后由后端同源托管，
 * 所以这里统一用相对路径。
 */
const BASE = ''

async function getJSON<T>(path: string): Promise<T> {
  const response = await fetch(BASE + path)
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`)
  }
  return (await response.json()) as T
}

export function fetchHealth(): Promise<HealthInfo> {
  return getJSON<HealthInfo>('/api/health')
}

export function fetchCatalog(): Promise<CatalogInfo> {
  return getJSON<CatalogInfo>('/api/catalog')
}

export async function postQuery(
  question: string,
  history: Turn[],
): Promise<WorkflowOutput> {
  const response = await fetch(BASE + '/api/query', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, history }),
  })
  if (!response.ok) {
    const text = await response.text()
    throw new Error(`HTTP ${response.status}：${text.slice(0, 200)}`)
  }
  return (await response.json()) as WorkflowOutput
}

/** 解析一段 SSE 帧，返回事件名和 data。 */
function parseFrame(frame: string): { event: string; data: string } | null {
  let event = 'message'
  const dataLines: string[] = []
  for (const line of frame.split('\n')) {
    if (line.startsWith('event:')) {
      event = line.slice(6).trim()
    } else if (line.startsWith('data:')) {
      dataLines.push(line.slice(5).trimStart())
    }
  }
  if (!dataLines.length) return null
  return { event, data: dataLines.join('\n') }
}

/**
 * 读 POST + text/event-stream 的响应。
 *
 * EventSource 只支持 GET，所以这里手写解析：按空行切帧，跨块缓冲。
 */
export async function* streamQuery(
  question: string,
  history: Turn[],
): AsyncGenerator<StreamEvent> {
  const response = await fetch(BASE + '/api/query/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, history }),
  })
  if (!response.ok || !response.body) {
    const text = await response.text().catch(() => '')
    throw new Error(`HTTP ${response.status}：${text.slice(0, 200)}`)
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder('utf-8')
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    // 后端用 \n 分隔；顺手兼容 \r\n
    buffer = buffer.replace(/\r\n/g, '\n')

    let index = buffer.indexOf('\n\n')
    while (index !== -1) {
      const frame = buffer.slice(0, index)
      buffer = buffer.slice(index + 2)
      const parsed = parseFrame(frame)
      if (parsed) {
        const payload = JSON.parse(parsed.data) as StreamEvent
        yield payload
      }
      index = buffer.indexOf('\n\n')
    }
  }
}
