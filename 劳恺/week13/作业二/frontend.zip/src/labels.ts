import type { WorkflowStatus } from './types'

/** 工作流节点的中文名，用于展示进度。 */
export const STAGE_LABELS: Record<string, string> = {
  init: '开始',
  select_tables: '选择数据表',
  prepare_schema: '读取表结构',
  generate_sql: '生成 SQL',
  validate_sql: '校验 SQL',
  execute_sql: '执行查询',
  rewrite_sql: '修复 SQL',
  summarize: '汇总结果',
  finalize: '组装输出',
}

export function stageLabel(stage: string): string {
  return STAGE_LABELS[stage] ?? stage
}

export interface StatusMeta {
  label: string
  tone: 'ok' | 'warn' | 'error' | 'info'
  hint?: string
}

export const STATUS_META: Record<WorkflowStatus, StatusMeta> = {
  completed: { label: '完成', tone: 'ok' },
  needs_clarification: {
    label: '需要澄清',
    tone: 'warn',
    hint: '补充下面的问题后重新提问即可',
  },
  cannot_fix: {
    label: '无法回答',
    tone: 'warn',
    hint: '当前数据库里没有能回答这个问题的数据',
  },
  repair_exhausted: {
    label: '修复失败',
    tone: 'error',
    hint: '生成的 SQL 一直跑不通，已达到最大修复次数',
  },
  failed: { label: '出错', tone: 'error' },
}

export interface ParsedAnswer {
  /** 表格前面的正文 */
  before: string
  headers: string[] | null
  rows: string[][]
}

function splitCells(line: string): string[] {
  return line
    .slice(1, line.length - (line.endsWith('|') ? 1 : 0))
    .split('|')
    .map((cell) => cell.trim().replace(/\\\|/g, '|'))
}

/**
 * 从答案里拆出 Markdown 表格。
 *
 * 汇总 Agent 挂掉时后端会降级成 Markdown 表格塞进 answer，这时前端
 * 把它渲染成真表格，而不是显示一堆竖线。
 */
export function splitMarkdownTable(text: string): ParsedAnswer {
  const lines = text.split('\n')
  let start = -1
  for (let i = 0; i < lines.length; i += 1) {
    if (lines[i].trim().startsWith('|')) {
      start = i
      break
    }
  }
  if (start === -1) {
    return { before: text, headers: null, rows: [] }
  }

  let end = start
  while (end + 1 < lines.length && lines[end + 1].trim().startsWith('|')) {
    end += 1
  }

  const block = lines.slice(start, end + 1).map((line) => line.trim())
  const headers = splitCells(block[0])
  const rows: string[][] = []
  for (let i = 1; i < block.length; i += 1) {
    const cells = splitCells(block[i])
    // 跳过 | --- | --- | 分隔行
    if (cells.every((cell) => /^:?-{2,}:?$/.test(cell))) continue
    rows.push(cells)
  }

  return {
    before: lines.slice(0, start).join('\n').trim(),
    headers,
    rows,
  }
}
