import { describe, expect, it, vi } from 'vitest'

import { streamQuery } from '../api'

function sseResponse(chunks: string[]): Response {
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    start(controller) {
      for (const chunk of chunks) controller.enqueue(encoder.encode(chunk))
      controller.close()
    },
  })
  return new Response(stream, {
    headers: { 'content-type': 'text/event-stream' },
  })
}

const RESULT = {
  type: 'result',
  output: {
    question: '有多少艺术家',
    answer: '共有 275 位艺术家。',
    sql: 'SELECT COUNT(*) AS n FROM artists',
    tables: ['artists'],
    row_count: 1,
    truncated: false,
    repair_attempts: 0,
    evidence: ['n=275'],
    caveats: [],
    error: null,
    status: 'completed',
    columns: ['n'],
    rows: [['275']],
  },
}

describe('streamQuery', () => {
  it('解析出 stage 和 result 事件', async () => {
    const raw =
      'event: stage\ndata: {"type":"stage","node":"select_tables","stage":"select_tables"}\n\n' +
      `event: result\ndata: ${JSON.stringify(RESULT)}\n\n`
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(sseResponse([raw])),
    )

    const events = []
    for await (const event of streamQuery('有多少艺术家', [])) {
      events.push(event)
    }

    expect(events).toHaveLength(2)
    expect(events[0]).toEqual({
      type: 'stage',
      node: 'select_tables',
      stage: 'select_tables',
    })
    expect(events[1].type).toBe('result')
  })

  it('帧跨 chunk 边界时也能正确拼接', async () => {
    const raw =
      'event: stage\ndata: {"type":"stage","node":"select_tables","stage":"select_tables"}\n\n' +
      `event: result\ndata: ${JSON.stringify(RESULT)}\n\n`
    // 故意在帧的中间切开，模拟网络分块
    const chunks = [raw.slice(0, 30), raw.slice(30, 90), raw.slice(90)]

    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(sseResponse(chunks)),
    )

    const events = []
    for await (const event of streamQuery('有多少艺术家', [])) {
      events.push(event)
    }

    expect(events).toHaveLength(2)
    expect(events[0].type).toBe('stage')
    expect(events[1].type).toBe('result')
  })

  it('兼容 \\r\\n 分隔符', async () => {
    const raw =
      'event: stage\r\ndata: {"type":"stage","node":"generate_sql","stage":"generate_sql"}\r\n\r\n'
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(sseResponse([raw])))

    const events = []
    for await (const event of streamQuery('q', [])) {
      events.push(event)
    }

    expect(events).toHaveLength(1)
    expect(events[0]).toEqual({
      type: 'stage',
      node: 'generate_sql',
      stage: 'generate_sql',
    })
  })

  it('把 history 一起发给后端', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(sseResponse(['event: result\ndata: {}\n\n']))
    vi.stubGlobal('fetch', fetchMock)

    const history = [
      { question: '第一问', answer: '答案', sql: 'SELECT 1', tables: ['artists'] },
    ]
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    for await (const _ of streamQuery('第二问', history)) {
      // 消费掉即可
    }

    const body = JSON.parse(fetchMock.mock.calls[0][1].body)
    expect(body.question).toBe('第二问')
    expect(body.history).toEqual(history)
  })

  it('HTTP 出错时抛出异常', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(new Response('boom', { status: 500 })),
    )

    await expect(async () => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      for await (const _ of streamQuery('q', [])) {
        // 不应到这里
      }
    }).rejects.toThrow(/HTTP 500/)
  })
})
