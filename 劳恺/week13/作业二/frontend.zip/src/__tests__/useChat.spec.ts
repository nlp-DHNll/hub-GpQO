import { describe, expect, it, vi } from 'vitest'
import { nextTick, watch } from 'vue'

import { useChat } from '../composables/useChat'

const RESULT = {
  question: '有多少艺术家',
  answer: '共有 275 位艺术家。',
  sql: 'SELECT COUNT(*) AS n FROM artists',
  tables: ['artists'],
  row_count: 1,
  truncated: false,
  repair_attempts: 0,
  evidence: ['n=275'],
  caveats: [],
  error: null,
  status: 'completed',
  columns: ['n'],
  rows: [['275']],
}

function sseResponse(frames: string[]): Response {
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    start(controller) {
      for (const frame of frames) controller.enqueue(encoder.encode(frame))
      controller.close()
    },
  })
  return new Response(stream, {
    headers: { 'content-type': 'text/event-stream' },
  })
}

const STAGE_FRAME =
  'event: stage\ndata: {"type":"stage","node":"select_tables","stage":"select_tables"}\n\n'
const RESULT_FRAME = `event: result\ndata: ${JSON.stringify({ type: 'result', output: RESULT })}\n\n`

describe('useChat', () => {
  it('流式过程里 stage 和结果都要写进响应式状态', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(sseResponse([STAGE_FRAME, RESULT_FRAME])),
    )

    const { messages, busy, send } = useChat()
    await send('有多少艺术家')
    await nextTick()

    expect(messages.value).toHaveLength(2)
    expect(messages.value[0].role).toBe('user')
    expect(messages.value[0].text).toBe('有多少艺术家')

    const reply = messages.value[1]
    expect(reply.pending).toBe(false)
    expect(reply.stages).toEqual(['select_tables'])
    expect(reply.output?.answer).toBe('共有 275 位艺术家。')
    expect(reply.output?.rows).toEqual([['275']])
    expect(busy.value).toBe(false)
  })

  it('流式过程中 stages 的变化要能触发响应式更新', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(sseResponse([STAGE_FRAME, RESULT_FRAME])),
    )

    const { messages, send } = useChat()

    // 必须在 send 之前就监听：如果代码改的是数组里的原始对象而不是
    // 响应式代理，数据虽然写进去了，但不会触发任何更新，界面会一直卡在
    // 「正在思考」。
    const seen: number[] = []
    const unwatch = watch(
      () => messages.value[1]?.stages.length ?? -1,
      (count) => seen.push(count),
      { flush: 'sync' },
    )

    await send('有多少艺术家')
    unwatch()

    expect(seen.length).toBeGreaterThan(0)
    expect(seen[seen.length - 1]).toBe(1)
  })

  it('完成的轮次会进历史，供下一轮当上下文', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(sseResponse([RESULT_FRAME])),
    )

    const { history, send } = useChat()
    await send('有多少艺术家')

    expect(history.value).toHaveLength(1)
    expect(history.value[0].question).toBe('有多少艺术家')
    expect(history.value[0].tables).toEqual(['artists'])
  })

  it('后端不可用时给出传输层错误，而不是卡住', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('连接被拒绝')))

    const { messages, busy, send } = useChat()
    await send('有多少艺术家')
    await nextTick()

    const reply = messages.value[1]
    expect(reply.pending).toBe(false)
    expect(reply.transportError).toContain('连接被拒绝')
    expect(busy.value).toBe(false)
  })

  it('空问题不发请求', async () => {
    const fetchMock = vi.fn()
    vi.stubGlobal('fetch', fetchMock)

    const { messages, send } = useChat()
    await send('   ')

    expect(fetchMock).not.toHaveBeenCalled()
    expect(messages.value).toHaveLength(0)
  })
})
