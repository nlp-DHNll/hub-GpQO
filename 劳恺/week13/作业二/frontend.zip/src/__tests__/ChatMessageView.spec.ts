import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'

import ChatMessageView from '../components/ChatMessageView.vue'
import type { ChatMessage, WorkflowOutput } from '../types'

const completed: WorkflowOutput = {
  question: '有多少艺术家',
  answer: '共有 275 位艺术家。',
  sql: 'SELECT COUNT(*) AS n FROM artists',
  tables: ['artists'],
  row_count: 1,
  truncated: false,
  repair_attempts: 0,
  evidence: ['n=275'],
  caveats: [],
  error: null,
  status: 'completed',
  columns: ['n'],
  rows: [['275']],
}

function agentMessage(overrides: Partial<ChatMessage> = {}): ChatMessage {
  return {
    id: 1,
    role: 'agent',
    text: '',
    stages: [],
    pending: false,
    ...overrides,
  }
}

describe('ChatMessageView', () => {
  it('渲染答案、SQL、结果表格和依据', () => {
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({ output: completed, text: completed.answer }),
      },
    })

    expect(wrapper.text()).toContain('共有 275 位艺术家。')
    expect(wrapper.text()).toContain('完成')
    expect(wrapper.text()).toContain('SELECT COUNT(*) AS n FROM artists')
    expect(wrapper.text()).toContain('n=275')

    const headers = wrapper.findAll('th').map((cell) => cell.text())
    expect(headers).toEqual(['n'])

    const cells = wrapper.findAll('tbody td').map((cell) => cell.text())
    expect(cells).toEqual(['275'])
  })

  it('渲染用到的表和修复次数', () => {
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({
          output: { ...completed, repair_attempts: 2 },
          text: completed.answer,
        }),
      },
    })

    expect(wrapper.text()).toContain('表：artists')
    expect(wrapper.text()).toContain('修复 2 次')
  })

  it('需要澄清时给出提示', () => {
    const output: WorkflowOutput = {
      ...completed,
      status: 'needs_clarification',
      answer: '你想查的是艺术家还是专辑？',
      sql: null,
      rows: [],
      columns: [],
      error: null,
    }
    const wrapper = mount(ChatMessageView, {
      props: { message: agentMessage({ output, text: output.answer }) },
    })

    expect(wrapper.text()).toContain('需要澄清')
    expect(wrapper.text()).toContain('你想查的是艺术家还是专辑？')
    expect(wrapper.text()).toContain('补充下面的问题后重新提问即可')
    // 澄清时不该渲染表格
    expect(wrapper.find('table').exists()).toBe(false)
  })

  it('修复失败时显示错误', () => {
    const output: WorkflowOutput = {
      ...completed,
      status: 'repair_exhausted',
      answer: '无法生成可执行的 SQL，已达到最大修复次数。',
      error: 'no such table: foo',
    }
    const wrapper = mount(ChatMessageView, {
      props: { message: agentMessage({ output, text: output.answer }) },
    })

    expect(wrapper.text()).toContain('修复失败')
    expect(wrapper.text()).toContain('no such table: foo')
  })

  it('汇总降级时把 answer 里的 Markdown 表格渲染成真表格', () => {
    const answer = [
      '查询返回 2 行。',
      '| Name | ArtistId |',
      '| --- | --- |',
      '| AC/DC | 1 |',
      '| Accept | 2 |',
    ].join('\n')
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({
          text: answer,
          output: { ...completed, rows: [], columns: [], answer },
        }),
      },
    })

    const headers = wrapper.findAll('th').map((cell) => cell.text())
    expect(headers).toEqual(['Name', 'ArtistId'])
    const cells = wrapper.findAll('tbody td').map((cell) => cell.text())
    expect(cells).toEqual(['AC/DC', '1', 'Accept', '2'])
    expect(wrapper.text()).toContain('查询返回 2 行。')
  })

  it('有结果行时不重复渲染 answer 里的表格', () => {
    const answer = '| x |\n| --- |\n| 1 |'
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({
          text: answer,
          output: { ...completed, answer },
        }),
      },
    })

    expect(wrapper.findAll('table')).toHaveLength(1)
    expect(wrapper.findAll('th').map((cell) => cell.text())).toEqual(['n'])
  })

  it('显示流式进度', () => {
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({
          pending: true,
          stages: ['select_tables', 'generate_sql'],
        }),
      },
    })

    expect(wrapper.text()).toContain('选择数据表')
    expect(wrapper.text()).toContain('生成 SQL')
    expect(wrapper.text()).toContain('进行中')
  })

  it('用户消息渲染成气泡', () => {
    const wrapper = mount(ChatMessageView, {
      props: {
        message: agentMessage({ role: 'user', text: '有多少艺术家' }),
      },
    })

    expect(wrapper.find('.bubble').text()).toBe('有多少艺术家')
  })
})
