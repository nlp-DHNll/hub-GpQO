<script setup lang="ts">
import { ref } from 'vue'

/** SQL 代码块，带复制按钮。 */
const props = defineProps<{ sql: string }>()

const copied = ref(false)

async function copy(): Promise<void> {
  try {
    await navigator.clipboard.writeText(props.sql)
    copied.value = true
    setTimeout(() => (copied.value = false), 1500)
  } catch {
    copied.value = false
  }
}
</script>

<template>
  <div class="sql">
    <div class="sql-head">
      <span class="sql-title">SQL</span>
      <button class="sql-copy" type="button" @click="copy">
        {{ copied ? '已复制' : '复制' }}
      </button>
    </div>
    <pre><code>{{ sql }}</code></pre>
  </div>
</template>

<style scoped>
.sql {
  margin-top: 12px;
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}

.sql-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  background: var(--surface-2);
  border-bottom: 1px solid var(--border);
}

.sql-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-2);
  letter-spacing: 0.04em;
}

.sql-copy {
  font: inherit;
  font-size: 12px;
  padding: 2px 10px;
  border-radius: 6px;
  border: 1px solid var(--border);
  background: var(--surface-1);
  color: var(--text-2);
  cursor: pointer;
}

.sql-copy:hover {
  color: var(--text-1);
  border-color: var(--accent);
}

pre {
  margin: 0;
  padding: 12px;
  overflow-x: auto;
  background: var(--code-bg);
}

code {
  font-family: var(--mono);
  font-size: 12.5px;
  line-height: 1.6;
  color: var(--code-text);
}
</style>
