<script setup lang="ts">
/** 结果表格：直接渲染后端返回的 columns / rows。 */
defineProps<{
  columns: string[]
  rows: string[][]
  truncated?: boolean
  rowCount?: number
}>()
</script>

<template>
  <div v-if="rows.length" class="result">
    <div class="result-head">
      <span class="result-title">查询结果</span>
      <span class="result-count">{{ rows.length }} 行</span>
      <span v-if="truncated" class="result-truncated">
        已截断，仅展示前 {{ rows.length }} 行
      </span>
    </div>
    <div class="result-scroll">
      <table>
        <thead>
          <tr>
            <th v-for="(column, index) in columns" :key="index">{{ column }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, rowIndex) in rows" :key="rowIndex">
            <td v-for="(cell, cellIndex) in row" :key="cellIndex">{{ cell }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <p v-if="truncated" class="result-note">
      结果被截断，数据库里还有更多行。
    </p>
  </div>
</template>

<style scoped>
.result {
  margin-top: 12px;
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}

.result-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: var(--surface-2);
  border-bottom: 1px solid var(--border);
  font-size: 12px;
}

.result-title {
  font-weight: 600;
  color: var(--text-1);
}

.result-count {
  color: var(--text-3);
}

.result-truncated {
  color: var(--warn);
}

.result-scroll {
  overflow: auto;
  max-height: 320px;
}

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

th {
  position: sticky;
  top: 0;
  background: var(--surface-2);
  text-align: left;
  font-weight: 600;
  color: var(--text-2);
  padding: 7px 12px;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}

td {
  padding: 7px 12px;
  border-bottom: 1px solid var(--border-soft);
  color: var(--text-1);
  white-space: nowrap;
}

tbody tr:last-child td {
  border-bottom: none;
}

tbody tr:hover {
  background: var(--surface-2);
}

.result-note {
  margin: 0;
  padding: 8px 12px;
  font-size: 12px;
  color: var(--warn);
  background: var(--warn-soft);
  border-top: 1px solid var(--border);
}
</style>
