<script setup lang="ts">
import { computed } from 'vue'

import ResultTable from './ResultTable.vue'
import SqlBlock from './SqlBlock.vue'
import { STATUS_META, splitMarkdownTable, stageLabel } from '../labels'
import type { ChatMessage } from '../types'

const props = defineProps<{ message: ChatMessage }>()

const output = computed(() => props.message.output)
const status = computed(() =>
  output.value ? STATUS_META[output.value.status] : null,
)

/**
 * 汇总 Agent 挂掉时，后端会把 Markdown 表格塞进 answer。
 * 这种情况下把它还原成真表格；正常情况下不碰 answer 的原文。
 */
const markdownTable = computed(() => {
  if (!props.message.text) return null
  if (output.value && output.value.rows.length) return null
  const parsed = splitMarkdownTable(props.message.text)
  return parsed.headers ? parsed : null
})

const plainText = computed(() => {
  if (!props.message.text) return ''
  if (markdownTable.value) return markdownTable.value.before
  return props.message.text
})
</script>

<template>
  <div class="msg" :class="{ 'msg-user': message.role === 'user' }">
    <!-- 用户消息 -->
    <template v-if="message.role === 'user'">
      <div class="bubble">{{ message.text }}</div>
    </template>

    <!-- Agent 消息 -->
    <template v-else>
      <div class="card">
        <div class="card-head">
          <span v-if="status" class="badge" :class="`badge-${status.tone}`">
            {{ status.label }}
          </span>
          <span v-if="message.pending" class="badge badge-info">进行中</span>
          <span v-if="output && output.tables.length" class="tables">
            表：{{ output.tables.join('、') }}
          </span>
          <span v-if="output && output.repair_attempts > 0" class="tables">
            修复 {{ output.repair_attempts }} 次
          </span>
        </div>

        <!-- 进度 -->
        <ol v-if="message.stages.length" class="stages">
          <li v-for="(stage, index) in message.stages" :key="index">
            <span class="dot" :class="{ 'dot-active': message.pending && index === message.stages.length - 1 }" />
            {{ stageLabel(stage) }}
          </li>
        </ol>

        <!-- 答案 -->
        <p v-if="plainText" class="answer">{{ plainText }}</p>

        <!-- 汇总降级时 answer 里的 Markdown 表格 -->
        <ResultTable
          v-if="markdownTable && markdownTable.headers"
          :columns="markdownTable.headers"
          :rows="markdownTable.rows"
        />

        <!-- 正式结果行 -->
        <ResultTable
          v-if="output && output.columns.length && output.rows.length"
          :columns="output.columns"
          :rows="output.rows"
          :truncated="output.truncated"
          :row-count="output.row_count"
        />

        <!-- SQL -->
        <SqlBlock v-if="output && output.sql" :sql="output.sql" />

        <!-- 证据 -->
        <div v-if="output && output.evidence.length" class="extra">
          <span class="extra-label">依据</span>
          <ul>
            <li v-for="(item, index) in output.evidence" :key="index">{{ item }}</li>
          </ul>
        </div>

        <!-- 注意事项 -->
        <div v-if="output && output.caveats.length" class="extra">
          <span class="extra-label">注意</span>
          <ul>
            <li v-for="(item, index) in output.caveats" :key="index">{{ item }}</li>
          </ul>
        </div>

        <!-- 澄清提示 -->
        <p v-if="status && status.hint" class="hint">{{ status.hint }}</p>

        <!-- 错误 -->
        <p v-if="output && output.error" class="error">{{ output.error }}</p>
        <p v-if="message.transportError" class="error">{{ message.transportError }}</p>

        <p v-if="message.pending" class="waiting">正在思考…</p>
      </div>
    </template>
  </div>
</template>

<style scoped>
.msg {
  display: flex;
  margin-bottom: 18px;
}

.msg-user {
  justify-content: flex-end;
}

.bubble {
  max-width: 78%;
  padding: 10px 14px;
  border-radius: 14px 14px 4px 14px;
  background: var(--accent);
  color: #fff;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
}

.card {
  width: 100%;
  max-width: 100%;
  padding: 14px 16px;
  border: 1px solid var(--border);
  border-radius: 14px 4px 14px 14px;
  background: var(--surface-1);
}

.card-head {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}

.badge {
  font-size: 12px;
  font-weight: 600;
  padding: 2px 9px;
  border-radius: 999px;
}

.badge-ok {
  background: var(--ok-soft);
  color: var(--ok);
}

.badge-warn {
  background: var(--warn-soft);
  color: var(--warn);
}

.badge-error {
  background: var(--error-soft);
  color: var(--error);
}

.badge-info {
  background: var(--accent-soft);
  color: var(--accent);
}

.tables {
  font-size: 12px;
  color: var(--text-3);
}

.stages {
  list-style: none;
  margin: 0 0 10px;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  gap: 6px 14px;
  font-size: 12px;
  color: var(--text-3);
}

.stages li {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ok);
}

.dot-active {
  background: var(--accent);
  animation: pulse 1s ease-in-out infinite;
}

@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.25;
  }
}

.answer {
  margin: 0;
  line-height: 1.7;
  color: var(--text-1);
  white-space: pre-wrap;
  word-break: break-word;
}

.extra {
  margin-top: 12px;
  font-size: 13px;
}

.extra-label {
  display: inline-block;
  font-size: 12px;
  font-weight: 600;
  color: var(--text-2);
  margin-bottom: 4px;
}

.extra ul {
  margin: 0;
  padding-left: 18px;
  color: var(--text-2);
  line-height: 1.7;
}

.hint {
  margin: 12px 0 0;
  font-size: 13px;
  color: var(--warn);
}

.error {
  margin: 12px 0 0;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--error-soft);
  color: var(--error);
  font-size: 13px;
  word-break: break-word;
}

.waiting {
  margin: 10px 0 0;
  font-size: 13px;
  color: var(--text-3);
}
</style>
