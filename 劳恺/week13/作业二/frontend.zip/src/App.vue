<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue'

import ChatMessageView from './components/ChatMessageView.vue'
import { useChat } from './composables/useChat'

const { messages, busy, health, loadHealth, send, reset } = useChat()

const draft = ref('')
const listRef = ref<HTMLElement | null>(null)

const EXAMPLES = [
  '有多少艺术家',
  '列出播放次数最多的 10 首歌',
  '各流派分别有多少首歌',
  '消费金额最高的 5 位客户是谁',
]

const connection = computed(() => {
  if (!health.value) return { tone: 'error', text: '后端未连接' }
  if (!health.value.has_api_key) return { tone: 'warn', text: '缺少 API key' }
  if (!health.value.db_exists) return { tone: 'warn', text: '数据库文件缺失' }
  return {
    tone: 'ok',
    text: `${health.value.model} · ${health.value.tables} 张表`,
  }
})

async function submit(): Promise<void> {
  const text = draft.value
  if (!text.trim() || busy.value) return
  draft.value = ''
  await send(text)
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault()
    void submit()
  }
}

function scrollToBottom(): void {
  const element = listRef.value
  if (element) element.scrollTop = element.scrollHeight
}

watch(
  messages,
  async () => {
    await nextTick()
    scrollToBottom()
  },
  { deep: true },
)

onMounted(async () => {
  await loadHealth()
})
</script>

<template>
  <div class="app">
    <header class="topbar">
      <div class="brand">
        <span class="logo">SQL</span>
        <div>
          <h1>Chinook 数据助手</h1>
          <p>用自然语言查询 Chinook 数据库</p>
        </div>
      </div>
      <div class="topbar-right">
        <span class="conn" :class="`conn-${connection.tone}`">{{ connection.text }}</span>
        <button v-if="messages.length" class="ghost" type="button" @click="reset">
          清空对话
        </button>
      </div>
    </header>

    <main ref="listRef" class="chat">
      <!-- 空状态 -->
      <div v-if="!messages.length" class="welcome">
        <h2>问点什么</h2>
        <p>
          提问后 Agent 会自己选表、写 SQL、校验并执行，最后给出结论和原始数据。
          可以接着追问，Agent 会记得上一轮问的是什么。
        </p>
        <div class="examples">
          <button
            v-for="example in EXAMPLES"
            :key="example"
            type="button"
            @click="draft = example"
          >
            {{ example }}
          </button>
        </div>
      </div>

      <ChatMessageView
        v-for="message in messages"
        :key="message.id"
        :message="message"
      />
    </main>

    <footer class="composer">
      <div class="composer-inner">
        <textarea
          v-model="draft"
          rows="1"
          placeholder="问一个问题，回车发送，Shift+回车换行"
          @keydown="onKeydown"
        />
        <button type="button" :disabled="busy || !draft.trim()" @click="submit">
          {{ busy ? '查询中…' : '发送' }}
        </button>
      </div>
      <p class="tip">查询会真实访问模型和数据库，通常需要十几秒</p>
    </footer>
  </div>
</template>

<style scoped>
.app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 900px;
  margin: 0 auto;
  background: var(--bg);
  border-left: 1px solid var(--border-soft);
  border-right: 1px solid var(--border-soft);
}

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px;
  border-bottom: 1px solid var(--border);
  background: var(--surface-1);
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo {
  display: grid;
  place-items: center;
  width: 38px;
  height: 38px;
  border-radius: 10px;
  background: var(--accent);
  color: #fff;
  font-weight: 700;
  font-size: 13px;
  letter-spacing: 0.02em;
}

.brand h1 {
  margin: 0;
  font-size: 15px;
  color: var(--text-1);
}

.brand p {
  margin: 2px 0 0;
  font-size: 12px;
  color: var(--text-3);
}

.topbar-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.conn {
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid var(--border);
}

.conn-ok {
  color: var(--ok);
  background: var(--ok-soft);
  border-color: transparent;
}

.conn-warn {
  color: var(--warn);
  background: var(--warn-soft);
  border-color: transparent;
}

.conn-error {
  color: var(--error);
  background: var(--error-soft);
  border-color: transparent;
}

.ghost {
  font: inherit;
  font-size: 12px;
  padding: 5px 12px;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-2);
  cursor: pointer;
}

.ghost:hover {
  color: var(--text-1);
  border-color: var(--accent);
}

.chat {
  flex: 1;
  overflow-y: auto;
  padding: 24px 20px 8px;
}

.welcome {
  padding: 48px 8px;
  text-align: center;
}

.welcome h2 {
  margin: 0 0 10px;
  font-size: 22px;
  color: var(--text-1);
}

.welcome p {
  margin: 0 auto 24px;
  max-width: 460px;
  line-height: 1.7;
  color: var(--text-3);
  font-size: 14px;
}

.examples {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}

.examples button {
  font: inherit;
  font-size: 13px;
  padding: 7px 14px;
  border-radius: 999px;
  border: 1px solid var(--border);
  background: var(--surface-1);
  color: var(--text-2);
  cursor: pointer;
}

.examples button:hover {
  border-color: var(--accent);
  color: var(--accent);
}

.composer {
  padding: 12px 20px 16px;
  border-top: 1px solid var(--border);
  background: var(--surface-1);
}

.composer-inner {
  display: flex;
  gap: 10px;
  align-items: flex-end;
}

textarea {
  flex: 1;
  resize: none;
  font: inherit;
  font-size: 14px;
  line-height: 1.6;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text-1);
  min-height: 44px;
  max-height: 160px;
}

textarea:focus {
  outline: none;
  border-color: var(--accent);
}

.composer button {
  font: inherit;
  font-size: 14px;
  padding: 11px 22px;
  border-radius: 10px;
  border: none;
  background: var(--accent);
  color: #fff;
  cursor: pointer;
}

.composer button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.tip {
  margin: 8px 0 0;
  font-size: 12px;
  color: var(--text-3);
  text-align: center;
}
</style>
