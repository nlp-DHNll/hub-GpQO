```vue
<script setup>
import { ref, computed, onBeforeUnmount } from 'vue'
import axios from 'axios'
import {
  showToast,
  showFailToast,
} from 'vant'

// 当前选择的图片
const selectedFile = ref(null)

// 图片预览地址
const previewUrl = ref('')

// 是否正在识别
const loading = ref(false)

// 后端返回的识别结果
const result = ref(null)

// 错误信息
const errorMessage = ref('')

// 风险类别对应的显示样式
const riskClass = computed(() => {
  const category = result.value?.data?.category

  const classMap = {
    '高风险': 'risk-high',
    '中风险': 'risk-medium',
    '低风险': 'risk-low',
    '无风险': 'risk-safe',
    '非楼道': 'risk-other',
    '需人工复核': 'risk-review',
  }

  return classMap[category] || 'risk-review'
})

// 选择图片后调用
function handleFileChange(event) {
  const file = event.target.files?.[0]

  // 允许用户再次选择同一张图片
  event.target.value = ''

  if (!file) {
    return
  }

  // 只接受常见图片格式
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
  ]

  if (!allowedTypes.includes(file.type)) {
    showFailToast('请选择 JPG、PNG 或 WebP 图片')
    return
  }

  // 前端限制文件大小为 10 MB
  if (file.size > 10 * 1024 * 1024) {
    showFailToast('图片不能超过 10 MB')
    return
  }

  // 清理上一次的预览地址
  if (previewUrl.value) {
    URL.revokeObjectURL(previewUrl.value)
  }

  selectedFile.value = file
  previewUrl.value = URL.createObjectURL(file)

  // 更换图片后清除旧结果
  result.value = null
  errorMessage.value = ''
}

// 调用 FastAPI 进行风险识别
async function recognizeImage() {
  if (!selectedFile.value) {
    showToast('请先拍摄或选择一张图片')
    return
  }

  loading.value = true
  result.value = null
  errorMessage.value = ''

  try {
    const formData = new FormData()

    // 必须与 FastAPI 接口的参数名称一致
    formData.append('file', selectedFile.value)

    const response = await axios.post(
      '/api/v1/fire-risk',
      formData,
      {
        timeout: 180000,
      },
    )

    result.value = response.data

    if (response.data?.success) {
      showToast('识别完成')
    } else {
      errorMessage.value = '识别未成功，请重试'
    }
  } catch (error) {
    console.error('消防风险识别失败：', error)

    if (error.response) {
      const detail = error.response.data?.detail

      errorMessage.value =
        typeof detail === 'string'
          ? detail
          : `服务器返回错误：${error.response.status}`
    } else if (error.code === 'ECONNABORTED') {
      errorMessage.value = '识别超时，请稍后重试'
    } else {
      errorMessage.value =
        '无法连接后端，请检查 FastAPI 服务是否运行'
    }

    showFailToast('识别失败')
  } finally {
    loading.value = false
  }
}

// 清除图片，重新拍摄或选择
function resetImage() {
  selectedFile.value = null
  result.value = null
  errorMessage.value = ''

  if (previewUrl.value) {
    URL.revokeObjectURL(previewUrl.value)
    previewUrl.value = ''
  }
}

// 离开页面时释放预览资源
onBeforeUnmount(() => {
  if (previewUrl.value) {
    URL.revokeObjectURL(previewUrl.value)
  }
})
</script>

<template>
  <main class="page">
    <header class="header">
      <div class="header-icon">🛡️</div>
      <h1>楼道消防安全识别</h1>
      <p>拍摄或上传楼道照片，AI 自动识别消防风险</p>
    </header>

    <section class="card">
      <h2>01 · 图片采集</h2>

      <div class="image-box">
        <img
          v-if="previewUrl"
          :src="previewUrl"
          alt="待识别的楼道照片"
          class="preview-image"
        />

        <div v-else class="empty-state">
          <div class="empty-icon">📷</div>
          <p>请拍摄楼道照片</p>
          <span>支持 JPG、PNG、WebP，最大 10 MB</span>
        </div>
      </div>

      <div class="button-row">
        <!--
          capture="environment" 提示手机优先使用后置摄像头。
          部分浏览器会提供拍照或相册选择选项。
        -->
        <label class="action-button primary-button">
          📷 拍照
          <input
            type="file"
            accept="image/*"
            capture="environment"
            class="hidden-input"
            @change="handleFileChange"
          />
        </label>

        <label class="action-button secondary-button">
          🖼️ 选择图片
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            class="hidden-input"
            @change="handleFileChange"
          />
        </label>
      </div>

      <div v-if="selectedFile" class="file-info">
        <span class="file-name">{{ selectedFile.name }}</span>
        <button class="text-button" @click="resetImage">
          重新选择
        </button>
      </div>
    </section>

    <section class="card">
      <h2>02 · AI 风险识别</h2>

      <p class="section-description">
        使用 Qwen3-VL 模型分析楼道环境和消防隐患。
      </p>

      <button
        class="recognize-button"
        :disabled="loading || !selectedFile"
        @click="recognizeImage"
      >
        <span v-if="loading">正在识别，请稍候...</span>
        <span v-else>开始识别</span>
      </button>

      <p v-if="loading" class="loading-tip">
        模型正在分析图片，请不要重复提交。
      </p>

      <div v-if="errorMessage" class="error-box">
        {{ errorMessage }}
      </div>
    </section>

    <section v-if="result?.success && result?.data" class="card result-card">
      <h2>03 · 识别结果</h2>

      <div class="result-content">
        <span class="result-label">风险类别</span>

        <div class="risk-badge" :class="riskClass">
          {{ result.data.category }}
        </div>
      </div>

      <div class="raw-output">
        <h3>模型识别内容</h3>
        <p>{{ result.data.raw_output || '暂无原始识别内容' }}</p>
      </div>

      <button
        class="action-button secondary-button full-width"
        @click="resetImage"
      >
        识别下一张图片
      </button>
    </section>

    <footer class="footer">
      <p>楼道消防安全辅助识别系统</p>
      <p>AI 识别结果仅供辅助参考，发现疑似隐患时请人工核实。</p>
    </footer>
  </main>
</template>

<style>
:root {
  font-family:
    -apple-system, BlinkMacSystemFont, "Segoe UI",
    "PingFang SC", "Microsoft YaHei", sans-serif;
  color: #243044;
  background: #f3f6fb;
  font-synthesis: none;
  text-rendering: optimizeLegibility;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  min-width: 320px;
}

button,
input {
  font: inherit;
}

button {
  cursor: pointer;
}

.page {
  width: 100%;
  max-width: 600px;
  min-height: 100vh;
  margin: 0 auto;
  padding: 20px 16px 36px;
}

.header {
  padding: 22px 12px 26px;
  text-align: center;
}

.header-icon {
  font-size: 38px;
}

.header h1 {
  margin: 12px 0 8px;
  font-size: 24px;
  font-weight: 750;
}

.header p {
  margin: 0;
  color: #738096;
  font-size: 14px;
  line-height: 1.7;
}

.card {
  margin-bottom: 18px;
  padding: 20px;
  border: 1px solid #e9edf4;
  border-radius: 18px;
  background: #fff;
  box-shadow: 0 5px 22px rgb(25 45 80 / 4%);
}

.card h2 {
  margin: 0 0 18px;
  font-size: 18px;
}

.image-box {
  display: flex;
  min-height: 220px;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  border: 1px dashed #cdd6e3;
  border-radius: 14px;
  background: #f8faff;
}

.preview-image {
  display: block;
  width: 100%;
  max-height: 400px;
  object-fit: contain;
}

.empty-state {
  padding: 30px 12px;
  text-align: center;
}

.empty-icon {
  font-size: 46px;
}

.empty-state p {
  margin: 12px 0 8px;
  font-size: 16px;
  font-weight: 600;
}

.empty-state span {
  color: #8a96a8;
  font-size: 12px;
}

.button-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-top: 16px;
}

.action-button {
  display: flex;
  min-height: 46px;
  align-items: center;
  justify-content: center;
  padding: 12px 10px;
  border: none;
  border-radius: 11px;
  font-size: 14px;
  font-weight: 600;
  text-align: center;
  cursor: pointer;
}

.primary-button {
  color: #fff;
  background: #246bfd;
}

.secondary-button {
  border: 1px solid #d8e2f2;
  color: #315782;
  background: #f3f7ff;
}

.hidden-input {
  display: none;
}

.file-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 14px;
  font-size: 12px;
}

.file-name {
  overflow: hidden;
  color: #6c7a90;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.text-button {
  flex-shrink: 0;
  padding: 5px;
  border: none;
  color: #246bfd;
  background: transparent;
}

.section-description {
  margin: -5px 0 18px;
  color: #7b8798;
  font-size: 13px;
  line-height: 1.7;
}

.recognize-button {
  width: 100%;
  min-height: 50px;
  border: none;
  border-radius: 12px;
  color: #fff;
  background: #246bfd;
  font-size: 16px;
  font-weight: 700;
}

.recognize-button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.loading-tip {
  margin: 12px 0 0;
  color: #7b8798;
  font-size: 12px;
  text-align: center;
}

.error-box {
  margin-top: 14px;
  padding: 12px;
  border-radius: 10px;
  color: #b42318;
  background: #fff0ee;
  font-size: 13px;
  line-height: 1.6;
  overflow-wrap: anywhere;
}

.result-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 16px;
  border-radius: 12px;
  background: #f8faff;
}

.result-label {
  color: #68758a;
  font-size: 14px;
}

.risk-badge {
  padding: 8px 15px;
  border-radius: 8px;
  font-size: 15px;
  font-weight: 750;
}

.risk-high {
  color: #b42318;
  background: #fee4e2;
}

.risk-medium {
  color: #b54708;
  background: #fef0c7;
}

.risk-low {
  color: #175cd3;
  background: #dbeafe;
}

.risk-safe {
  color: #067647;
  background: #d1fadf;
}

.risk-other {
  color: #475467;
  background: #eaecf0;
}

.risk-review {
  color: #6941c6;
  background: #ebe9fe;
}

.raw-output {
  margin: 18px 0;
  padding: 15px;
  border-radius: 12px;
  background: #f8faff;
}

.raw-output h3 {
  margin: 0 0 10px;
  font-size: 14px;
}

.raw-output p {
  margin: 0;
  color: #475467;
  font-size: 14px;
  line-height: 1.8;
  overflow-wrap: anywhere;
  white-space: pre-wrap;
}

.full-width {
  width: 100%;
}

.footer {
  padding: 12px 8px;
  color: #98a2b3;
  font-size: 11px;
  line-height: 1.8;
  text-align: center;
}

.footer p {
  margin: 4px 0;
}

@media (max-width: 380px) {
  .page {
    padding-right: 12px;
    padding-left: 12px;
  }

  .card {
    padding: 15px;
  }

  .header h1 {
    font-size: 21px;
  }
}
</style>
```