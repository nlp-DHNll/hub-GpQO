/** 正文按【图N】切成片段，便于把引用角标渲染成可点击元素。 */
export interface TextSegment {
  text: string
  /** 有值表示这一段是【图N】引用标记 */
  figure?: number
}

export function splitByCitation(text: string): TextSegment[] {
  const parts: TextSegment[] = []
  const pattern = /【图(\d+)】/g
  let last = 0
  let match: RegExpExecArray | null

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > last) parts.push({ text: text.slice(last, match.index) })
    parts.push({ text: match[0], figure: Number(match[1]) })
    last = match.index + match[0].length
  }
  if (last < text.length) parts.push({ text: text.slice(last) })
  return parts
}
