/**
 * 问答状态管理。
 *
 * 流式渲染的要点（docs/04 §4）：
 * - `delta` **追加**到当前气泡；
 * - `citation` 是**插入**引用卡片（与正文的【图N】联动）；
 * - `done` 用**完整答案覆盖**（以它为准，避免流式过程中拼接出偏差）；
 * - `error` 展示可读提示，已生成的部分保留。
 */

import { computed, ref } from 'vue'
import { streamChat } from '@/api/client'
import { splitByCitation as splitText } from '@/utils/text'
import type { ChatMessage } from '@/api/types'

let messageSeq = 0
const nextId = () => `m_${Date.now()}_${messageSeq++}`

export function useChat() {
  const messages = ref<ChatMessage[]>([])
  const question = ref('')
  const pendingImages = ref<{ data: string; filename: string }[]>([])
  const sessionId = ref<string | null>(null)
  const streaming = ref(false)
  const error = ref<string | null>(null)

  let controller: AbortController | null = null

  const canSend = computed(
    () => question.value.trim().length > 0 && !streaming.value,
  )

  function readFileAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(String(reader.result))
      reader.onerror = () => reject(new Error('读取图片失败'))
      reader.readAsDataURL(file)
    })
  }

  async function attachImages(files: File[]): Promise<void> {
    for (const file of files) {
      if (pendingImages.value.length >= 4) break
      if (!file.type.startsWith('image/')) continue
      const data = await readFileAsDataUrl(file)
      pendingImages.value.push({ data, filename: file.name })
    }
  }

  function removeImage(index: number): void {
    pendingImages.value.splice(index, 1)
  }

  async function send(docIds?: string[]): Promise<void> {
    const text = question.value.trim()
    if (!text || streaming.value) return

    error.value = null
    const images = [...pendingImages.value]

    messages.value.push({
      id: nextId(),
      role: 'user',
      content: text,
      citations: [],
      previewImages: images.map((image) => image.data),
    })

    messages.value.push({
      id: nextId(),
      role: 'assistant',
      content: '',
      citations: [],
      streaming: true,
    })

    // ⚠️ 必须从数组里**取回代理对象**再修改。
    // push 进去的是原始对象；Vue 3 的响应式是「读取时才包成 Proxy」，
    // 若持有 push 前的原始引用直接改属性，不会触发 set 拦截器 → 界面不更新，
    // 表现就是"提问后助手气泡一直是空的"。
    const assistant = messages.value[messages.value.length - 1]

    question.value = ''
    pendingImages.value = []
    streaming.value = true
    controller = new AbortController()

    try {
      await streamChat(
        {
          question: text,
          session_id: sessionId.value,
          images,
          doc_ids: docIds && docIds.length ? docIds : null,
        },
        {
          onDelta: (delta) => {
            assistant.content += delta
          },
          onCitation: (citation) => {
            if (!assistant.citations.some((c) => c.image_id === citation.image_id)) {
              assistant.citations.push(citation)
            }
          },
          onDone: (payload) => {
            // 以 done 的完整答案为准：流式拼接可能有极小的差异
            assistant.content = payload.answer
            assistant.citations = payload.citations
            sessionId.value = payload.session_id
            assistant.streaming = false
          },
          onError: (message) => {
            assistant.error = message
            assistant.streaming = false
            error.value = message
          },
        },
        controller.signal,
      )
    } catch (err) {
      assistant.error = (err as Error).message
      error.value = (err as Error).message
    } finally {
      assistant.streaming = false
      streaming.value = false
      controller = null
      scrollToBottom()
    }
  }

  function stop(): void {
    controller?.abort()
    controller = null
    streaming.value = false
    const last = messages.value[messages.value.length - 1]
    if (last?.streaming) last.streaming = false
  }

  function clear(): void {
    messages.value = []
    sessionId.value = null
    error.value = null
  }

  function scrollToBottom(): void {
    requestAnimationFrame(() => {
      const container = document.querySelector('[data-chat-scroll]')
      if (container) container.scrollTop = container.scrollHeight
    })
  }

  return {
    messages,
    question,
    pendingImages,
    sessionId,
    streaming,
    error,
    canSend,
    attachImages,
    removeImage,
    send,
    stop,
    clear,
    splitByCitation: splitText,
  }
}
