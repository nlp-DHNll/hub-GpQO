/**
 * 文档列表状态（**模块级单例**）。
 *
 * 为什么是单例：UploadArea 和 DocumentList 都要用它。若每次调用都新建一份，
 * 就会开出两条 SSE 连接、两份状态，进度条只更新一份。所以状态放在模块作用域，
 * `useDocuments()` 只是取用；真正的连接/断开由 `initDocuments()` / `disposeDocuments()`
 * 在应用根组件里显式管理。
 *
 * 遵循 docs/04 §3 的前端要点：
 * 1. **首屏先 GET 全量，再开 SSE** —— SSE 只负责后续增量；
 * 2. 状态事件是**覆盖式**的完整对象，按 doc_id 合并即可；
 * 3. SSE 断线后**重新拉一次全量**（事件不编号，补不回漏掉的几条）；
 * 4. SSE 不可用时退化为轮询（仅在有活跃文档时）。
 */

import { computed, ref } from 'vue'
import {
  deleteDocument,
  listDocuments,
  openStatusStream,
  retryDocument,
  uploadDocuments,
} from '@/api/client'
import type { DocumentItem, StatusEvent } from '@/api/types'

const POLL_INTERVAL_MS = 2000

const documents = ref<DocumentItem[]>([])
const loading = ref(false)
const error = ref<string | null>(null)
const connected = ref(false)

/** 勾选的文档 —— 作为问答的检索范围（空 = 全库）。见 docs/04 §4 的 doc_ids */
const selectedIds = ref<string[]>([])

function toggleSelected(docId: string): void {
  const index = selectedIds.value.indexOf(docId)
  if (index >= 0) selectedIds.value.splice(index, 1)
  else selectedIds.value.push(docId)
}

function clearSelection(): void {
  selectedIds.value = []
}

let source: EventSource | null = null
let pollTimer: number | null = null
let initialized = false

const hasActive = computed(() =>
  documents.value.some(
    (item) => item.status === 'processing' || item.status === 'pending',
  ),
)

const stats = computed(() => ({
  total: documents.value.length,
  done: documents.value.filter((d) => d.status === 'done').length,
  processing: documents.value.filter((d) => d.status === 'processing').length,
  failed: documents.value.filter((d) => d.status === 'failed').length,
}))

async function refresh(): Promise<void> {
  try {
    documents.value = await listDocuments()
    error.value = null
  } catch (err) {
    error.value = (err as Error).message
  }
}

/** 覆盖式合并：SSE 事件就是完整状态，直接替换对应项 */
function applyStatus(event: StatusEvent): void {
  const index = documents.value.findIndex((item) => item.doc_id === event.doc_id)
  if (index < 0) {
    void refresh() // 未知文档（例如别的标签页上传的）→ 拉全量
    return
  }
  const current = documents.value[index]
  documents.value[index] = {
    ...current,
    status: event.status,
    progress: event.progress,
    stage: event.stage,
    error: event.error,
    chunk_count: event.chunk_count ?? current.chunk_count,
    image_count: event.image_count ?? current.image_count,
    updated_at: event.updated_at,
  }
}

function connect(): void {
  disconnect()
  source = openStatusStream({
    onStatus: (event) => {
      connected.value = true
      applyStatus(event)
    },
    // 断线期间可能漏事件 → 以 ES 全量为准
    onReconnect: () => {
      void refresh()
    },
    onError: () => {
      connected.value = false
    },
  })
  source.onopen = () => {
    connected.value = true
  }
  connected.value = true
}

function disconnect(): void {
  if (source) {
    source.close()
    source = null
  }
  connected.value = false
}

function startPollingIfNeeded(): void {
  if (!hasActive.value || pollTimer !== null || connected.value) return
  pollTimer = window.setInterval(() => {
    if (!hasActive.value) {
      stopPolling()
      return
    }
    void refresh()
  }, POLL_INTERVAL_MS)
}

function stopPolling(): void {
  if (pollTimer !== null) {
    window.clearInterval(pollTimer)
    pollTimer = null
  }
}

/** 应用启动时调用一次：先拉全量，再开 SSE */
async function initDocuments(): Promise<void> {
  if (initialized) return
  initialized = true
  await refresh()
  connect()
  startPollingIfNeeded()
}

/** 应用卸载时调用 */
function disposeDocuments(): void {
  initialized = false
  disconnect()
  stopPolling()
}

// ---------- 操作 ----------

async function upload(
  files: File[],
): Promise<{ accepted: number; rejected: { filename: string; reason: string }[] }> {
  loading.value = true
  try {
    const result = await uploadDocuments(files)
    // 立刻插入 accepted（不等 SSE），前端秒级反馈
    for (const item of result.accepted) {
      if (!documents.value.some((doc) => doc.doc_id === item.doc_id)) {
        const now = new Date().toISOString()
        documents.value.unshift({
          doc_id: item.doc_id,
          filename: item.filename,
          size_bytes: 0,
          page_count: null,
          status: 'pending',
          progress: 0,
          stage: 'queued',
          error: null,
          chunk_count: 0,
          image_count: 0,
          created_at: now,
          updated_at: now,
          finished_at: null,
        })
      }
    }
    return { accepted: result.accepted.length, rejected: result.rejected }
  } finally {
    loading.value = false
  }
}

async function remove(docId: string): Promise<void> {
  await deleteDocument(docId)
  documents.value = documents.value.filter((item) => item.doc_id !== docId)
}

async function retry(docId: string): Promise<void> {
  await retryDocument(docId)
  const index = documents.value.findIndex((item) => item.doc_id === docId)
  if (index >= 0) {
    documents.value[index] = {
      ...documents.value[index],
      status: 'pending',
      progress: 0,
      stage: 'queued',
      error: null,
    }
  }
}

export function useDocuments() {
  return {
    documents,
    loading,
    error,
    connected,
    stats,
    hasActive,
    selectedIds,
    toggleSelected,
    clearSelection,
    refresh,
    upload,
    remove,
    retry,
    initDocuments,
    disposeDocuments,
  }
}
