<script setup lang="ts">
import { computed, ref } from 'vue'
import ImageLightbox from './ImageLightbox.vue'
import { assetUrl } from '@/api/client'
import { splitByCitation } from '@/utils/text'
import type { ChatMessage, Citation } from '@/api/types'

const props = defineProps<{ message: ChatMessage }>()

const active = ref<Citation | null>(null)

/** 正文按【图N】切成片段 */
const segments = computed(() => splitByCitation(props.message.content))

const hasCitation = (text: string) =>
  props.message.citations.some((item) => item.text === text)

/** 点击正文里的【图N】→ 打开对应图片 */
function openFigure(figure: number): void {
  const citation = props.message.citations.find((item) => item.text === `【图${figure}】`)
  if (citation) active.value = citation
}
</script>

<template>
  <div class="msg" :class="`msg--${message.role}`">
    <!-- 用户消息附带的图片回显 -->
    <div v-if="message.previewImages?.length" class="msg__previews">
      <img
        v-for="(src, index) in message.previewImages"
        :key="index"
        :src="src"
        alt="用户上传的图片"
      />
    </div>

    <div class="msg__bubble">
      <template v-for="(segment, index) in segments" :key="index">
        <button
          v-if="segment.figure"
          class="cite-chip"
          :class="{ 'cite-chip--missing': !hasCitation(segment.text) }"
          :title="hasCitation(segment.text) ? '查看引用图片' : '该引用没有对应图片'"
          @click="openFigure(segment.figure)"
        >
          {{ segment.text }}
        </button>
        <span v-else>{{ segment.text }}</span>
      </template>

      <span v-if="message.streaming" class="cursor" />

      <p v-if="message.error" class="msg__error">{{ message.error }}</p>
    </div>

    <!-- 引用卡片 -->
    <div v-if="message.citations.length" class="citations">
      <figure
        v-for="citation in message.citations"
        :key="citation.image_id"
        class="citation"
        @click="active = citation"
      >
        <img
          :src="assetUrl(citation.url)"
          :alt="citation.caption || '引用图片'"
          loading="lazy"
        />
        <figcaption>
          <span class="citation__tag">{{ citation.text || '相关图片' }}</span>
          <span class="citation__src">
            {{ citation.doc_filename }} · 第 {{ citation.page_no }} 页
          </span>
        </figcaption>
      </figure>
    </div>

    <ImageLightbox
      v-if="active"
      :src="assetUrl(active.url)"
      :caption="active.caption"
      :page="active.page_no"
      :filename="active.doc_filename"
      @close="active = null"
    />
  </div>
</template>
