<script setup lang="ts">
import { computed } from 'vue'
import type { DocumentStatus } from '@/api/types'

const props = defineProps<{ status: DocumentStatus }>()

/** 中文文案 + 颜色（docs/共享理解文档 §3.4 的四个状态） */
const MAP: Record<DocumentStatus, { label: string; cls: string }> = {
  pending: { label: '待解析', cls: 'badge--pending' },
  processing: { label: '解析中', cls: 'badge--processing' },
  done: { label: '已完成', cls: 'badge--done' },
  failed: { label: '失败', cls: 'badge--failed' },
}

const badge = computed(() => MAP[props.status] ?? MAP.pending)
</script>

<template>
  <span class="badge" :class="badge.cls">
    <span v-if="status === 'processing'" class="badge__dot" />
    {{ badge.label }}
  </span>
</template>
