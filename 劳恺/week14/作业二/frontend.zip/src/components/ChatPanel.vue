<script setup lang="ts">
import { nextTick, ref, watch } from 'vue'
import MessageBubble from './MessageBubble.vue'
import { useChat } from '@/composables/useChat'
import { useDocuments } from '@/composables/useDocuments'

const {
  messages,
  question,
  pendingImages,
  streaming,
  error,
  canSend,
  attachImages,
  removeImage,
  send,
  stop,
  clear,
} = useChat()

const { documents, selectedIds } = useDocuments()

const scrollRef = ref<HTMLElement | null>(null)
const fileRef = ref<HTMLInputElement | null>(null)

/** 新内容到达时滚到底部 */
watch(
  () => messages.value.map((m) => m.content.length).join(','),
  async () => {
    await nextTick()
    if (scrollRef.value) scrollRef.value.scrollTop = scrollRef.value.scrollHeight
  },
)

function onSubmit(): void {
  if (!canSend.value) return
  // 勾选了文档就限定检索范围，否则全库
  void send(selectedIds.value)
}

function onKeydown(event: KeyboardEvent): void {
  // Enter 发送，Shift+Enter 换行
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault()
    onSubmit()
  }
}

async function onPickImages(event: Event): Promise<void> {
  const input = event.target as HTMLInputElement
  if (input.files?.length) await attachImages(Array.from(input.files))
  input.value = ''
}

const doneCount = () => documents.value.filter((d) => d.status === 'done').length
</script>

<template>
  <section class="chat">
    <header class="chat__header">
      <h2>智能问答</h2>
      <div class="chat__tools">
        <span class="chat__scope">
          {{ selectedIds.length ? `检索范围：${selectedIds.length} 份文档` : `检索范围：全库（${doneCount()} 份）` }}
        </span>
        <button class="link" @click="clear">清空对话</button>
      </div>
    </header>

    <div ref="scrollRef" class="chat__scroll" data-chat-scroll>
      <div v-if="!messages.length" class="chat__welcome">
        <h3>上传 PDF 后就可以提问了</h3>
        <p>答案会以图文混排的形式给出，点击【图N】可以查看原图。</p>
        <ul>
          <li>「这份财报的营收峰值出现在哪个季度？」</li>
          <li>「这个流程图里第三步做了什么？」</li>
          <li>也可以直接上传一张截图作为问题的一部分</li>
        </ul>
      </div>

      <MessageBubble v-for="message in messages" :key="message.id" :message="message" />
    </div>

    <p v-if="error" class="chat__error">{{ error }}</p>

    <!-- 待发送的图片 -->
    <div v-if="pendingImages.length" class="chat__pending">
      <div v-for="(image, index) in pendingImages" :key="index" class="chat__thumb">
        <img :src="image.data" :alt="image.filename" />
        <button title="移除" @click="removeImage(index)">×</button>
      </div>
    </div>

    <footer class="chat__composer">
      <input
        ref="fileRef"
        type="file"
        accept="image/*"
        multiple
        hidden
        @change="onPickImages"
      />
      <button
        class="btn btn--icon"
        title="附加图片（最多 4 张）"
        :disabled="streaming || pendingImages.length >= 4"
        @click="fileRef?.click()"
      >
        +
      </button>

      <textarea
        v-model="question"
        class="chat__input"
        rows="1"
        placeholder="输入问题，Enter 发送，Shift+Enter 换行"
        :disabled="streaming"
        @keydown="onKeydown"
      />

      <button v-if="streaming" class="btn btn--danger" @click="stop">停止</button>
      <button v-else class="btn btn--primary" :disabled="!canSend" @click="onSubmit">
        发送
      </button>
    </footer>
  </section>
</template>
