<script setup lang="ts">
import { computed } from 'vue'
import StatusBadge from './StatusBadge.vue'
import { useDocuments } from '@/composables/useDocuments'
import type { DocumentItem } from '@/api/types'

const { documents, remove, retry, selectedIds, toggleSelected, clearSelection } =
  useDocuments()

/** 阶段名 → 中文（docs/03 §3.2 的 stage 取值） */
const STAGE_LABEL: Record<string, string> = {
  queued: '排队中',
  mineru_parse: '解析 PDF',
  chunking: '切分文本',
  caption: '生成图片描述',
  embedding: '向量化',
  indexing: '写入索引',
  finished: '完成',
}

const stageLabel = (stage: string) => STAGE_LABEL[stage] ?? stage

function formatSize(bytes: number): string {
  if (!bytes) return '—'
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

const isSelected = (docId: string) => selectedIds.value.includes(docId)

async function onDelete(doc: DocumentItem): Promise<void> {
  if (!window.confirm(`确定删除《${doc.filename}》？其块与图片都会被删除。`)) return
  try {
    await remove(doc.doc_id)
    clearSelection()
  } catch (err) {
    window.alert((err as Error).message)
  }
}

async function onRetry(doc: DocumentItem): Promise<void> {
  try {
    await retry(doc.doc_id)
  } catch (err) {
    window.alert((err as Error).message)
  }
}

const selectedCount = computed(() => selectedIds.value.length)
</script>

<template>
  <section class="docs">
    <header class="docs__header">
      <h2>文档库</h2>
      <span class="docs__count">{{ documents.length }} 份</span>
    </header>

    <p v-if="selectedCount" class="docs__selection">
      已选 {{ selectedCount }} 份作为检索范围
      <button class="link" @click="clearSelection">清除</button>
    </p>

    <p v-if="!documents.length" class="docs__empty">
      还没有文档，先在上方上传 PDF。
    </p>

    <ul class="docs__list">
      <li
        v-for="doc in documents"
        :key="doc.doc_id"
        class="doc"
        :class="[`doc--${doc.status}`, { 'doc--selected': isSelected(doc.doc_id) }]"
      >
        <div class="doc__top">
          <label class="doc__check" :title="'勾选以限定检索范围'">
            <input
              type="checkbox"
              :checked="isSelected(doc.doc_id)"
              :disabled="doc.status !== 'done'"
              @change="toggleSelected(doc.doc_id)"
            />
          </label>
          <span class="doc__name" :title="doc.filename">{{ doc.filename }}</span>
          <StatusBadge :status="doc.status" />
        </div>

        <div class="doc__meta">
          <span>{{ formatSize(doc.size_bytes) }}</span>
          <span v-if="doc.status === 'done'">
            {{ doc.chunk_count }} 块 · {{ doc.image_count }} 图
          </span>
          <span v-else-if="doc.status === 'processing'">
            {{ stageLabel(doc.stage) }} {{ Math.round(doc.progress * 100) }}%
          </span>
          <span v-else-if="doc.status === 'pending'">排队中…</span>
        </div>

        <div v-if="doc.status === 'processing'" class="doc__progress">
          <div class="doc__progress-bar" :style="{ width: `${doc.progress * 100}%` }" />
        </div>

        <p v-if="doc.status === 'failed' && doc.error" class="doc__error">
          {{ doc.error }}
        </p>

        <div class="doc__actions">
          <button
            v-if="doc.status === 'failed'"
            class="btn btn--sm"
            @click="onRetry(doc)"
          >
            重试
          </button>
          <button class="btn btn--sm btn--ghost" @click="onDelete(doc)">删除</button>
        </div>
      </li>
    </ul>
  </section>
</template>
