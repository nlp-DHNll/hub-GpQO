<script setup lang="ts">
import { onBeforeUnmount, onMounted } from 'vue'

defineProps<{
  src: string
  caption?: string
  page?: number
  filename?: string
}>()

const emit = defineEmits<{ close: [] }>()

/** Esc 关闭 */
function onKey(event: KeyboardEvent): void {
  if (event.key === 'Escape') emit('close')
}

onMounted(() => window.addEventListener('keydown', onKey))
onBeforeUnmount(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <Teleport to="body">
    <div class="lightbox" @click.self="emit('close')">
      <button class="lightbox__close" title="关闭（Esc）" @click="emit('close')">
        ×
      </button>
      <figure class="lightbox__figure">
        <img :src="src" :alt="caption || '引用图片'" />
        <figcaption v-if="caption || page || filename" class="lightbox__caption">
          <span v-if="filename">《{{ filename }}》</span>
          <span v-if="page">第 {{ page }} 页</span>
          <span v-if="caption" class="lightbox__desc">{{ caption }}</span>
        </figcaption>
      </figure>
    </div>
  </Teleport>
</template>
