<script setup lang="ts">
import { ref } from 'vue'
import { useDocuments } from '@/composables/useDocuments'

const { upload, loading } = useDocuments()

const emit = defineEmits<{
  uploaded: [result: { accepted: number; rejected: { filename: string; reason: string }[] }]
}>()

const dragging = ref(false)
const inputRef = ref<HTMLInputElement | null>(null)
const notice = ref<string | null>(null)

async function handleFiles(files: FileList | File[]): Promise<void> {
  const list = Array.from(files).filter((file) =>
    file.name.toLowerCase().endsWith('.pdf'),
  )
  if (!list.length) {
    notice.value = '请选择 PDF 文件'
    return
  }
  notice.value = null
  try {
    const result = await upload(list)
    emit('uploaded', result)
  } catch (err) {
    notice.value = (err as Error).message
  }
}

function onDrop(event: DragEvent): void {
  dragging.value = false
  if (event.dataTransfer?.files?.length) void handleFiles(event.dataTransfer.files)
}

function onPick(event: Event): void {
  const input = event.target as HTMLInputElement
  if (input.files?.length) void handleFiles(input.files)
  input.value = '' // 允许重复上传同一个文件
}
</script>

<template>
  <div
    class="upload"
    :class="{ 'upload--dragging': dragging }"
    @dragover.prevent="dragging = true"
    @dragleave.prevent="dragging = false"
    @drop.prevent="onDrop"
    @click="inputRef?.click()"
  >
    <input
      ref="inputRef"
      type="file"
      accept="application/pdf,.pdf"
      multiple
      hidden
      @change="onPick"
    />
    <div class="upload__icon">PDF</div>
    <p class="upload__title">
      {{ loading ? '上传中…' : '点击或拖入 PDF 文件' }}
    </p>
    <p class="upload__hint">支持批量上传，解析进度实时显示</p>
    <p v-if="notice" class="upload__notice">{{ notice }}</p>
  </div>
</template>
