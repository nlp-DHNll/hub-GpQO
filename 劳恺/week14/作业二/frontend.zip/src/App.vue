<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import ChatPanel from './components/ChatPanel.vue'
import DocumentList from './components/DocumentList.vue'
import UploadArea from './components/UploadArea.vue'
import { useDocuments } from '@/composables/useDocuments'

const { documents, connected, stats, initDocuments, disposeDocuments } = useDocuments()

const toast = ref<string | null>(null)
let toastTimer: number | null = null

function showToast(message: string): void {
  toast.value = message
  if (toastTimer) window.clearTimeout(toastTimer)
  toastTimer = window.setTimeout(() => (toast.value = null), 4000)
}

function onUploaded(result: {
  accepted: number
  rejected: { filename: string; reason: string }[]
}): void {
  const parts: string[] = []
  if (result.accepted) parts.push(`${result.accepted} 份已加入解析队列`)
  for (const item of result.rejected) parts.push(`${item.filename}：${item.reason}`)
  if (parts.length) showToast(parts.join('；'))
}

onMounted(() => {
  void initDocuments()
})

onBeforeUnmount(() => {
  disposeDocuments()
  if (toastTimer) window.clearTimeout(toastTimer)
})
</script>

<template>
  <div class="app">
    <header class="app__header">
      <div class="app__brand">
        <span class="app__logo">RAG</span>
        <div>
          <h1>多模态文档问答</h1>
          <p class="app__sub">上传 PDF → 自动解析 → 图文混排回答</p>
        </div>
      </div>

      <div class="app__stats">
        <span class="stat">
          <b>{{ stats.done }}</b> 已完成
        </span>
        <span class="stat">
          <b>{{ stats.processing }}</b> 解析中
        </span>
        <span class="stat" :class="{ 'stat--bad': stats.failed }">
          <b>{{ stats.failed }}</b> 失败
        </span>
        <span class="conn" :class="{ 'conn--on': connected }">
          {{ connected ? '状态流已连接' : '状态流未连接' }}
        </span>
      </div>
    </header>

    <main class="app__main">
      <aside class="app__side">
        <UploadArea @uploaded="onUploaded" />
        <DocumentList />
      </aside>

      <ChatPanel class="app__chat" />
    </main>

    <Transition name="toast">
      <div v-if="toast" class="toast">{{ toast }}</div>
    </Transition>

    <!-- 首屏占位：避免"未加载"被误认为"没有文档" -->
    <p v-if="!documents.length && !connected" class="sr-only">
      正在连接后端…
    </p>
  </div>
</template>
