/**
 * 与后端契约一一对应的类型。
 * 来源：docs/04-API契约.md —— **后端已按此实现，字段名不要改**。
 */

export type DocumentStatus = 'pending' | 'processing' | 'done' | 'failed'

export interface DocumentItem {
  doc_id: string
  filename: string
  size_bytes: number
  page_count: number | null
  status: DocumentStatus
  progress: number
  stage: string
  error: string | null
  chunk_count: number
  image_count: number
  created_at: string | null
  updated_at: string | null
  finished_at: string | null
}

export interface AcceptedFile {
  doc_id: string
  filename: string
  status: DocumentStatus
  message: string
}

export interface RejectedFile {
  filename: string
  reason: string
}

export interface UploadResponse {
  accepted: AcceptedFile[]
  rejected: RejectedFile[]
}

/** SSE `status` 事件的载荷：**覆盖式**的完整状态对象。 */
export interface StatusEvent {
  event: 'status'
  doc_id: string
  status: DocumentStatus
  progress: number
  stage: string
  error: string | null
  chunk_count?: number | null
  image_count?: number | null
  updated_at: string
}

export interface UserImagePayload {
  data: string
  filename?: string
}

export interface ChatRequestPayload {
  question: string
  session_id?: string | null
  images?: UserImagePayload[]
  doc_ids?: string[] | null
}

export interface Citation {
  image_id: string
  doc_id: string
  doc_filename: string
  page_no: number
  url: string
  caption: string
  text: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  citations: Citation[]
  /** 流式生成中（用于显示光标 / 禁用发送） */
  streaming?: boolean
  /** 出错时的提示 */
  error?: string
  /** 用户消息附带的图片（仅用于本地回显） */
  previewImages?: string[]
}
