/**
 * 后端 API 客户端。
 *
 * 两个关键点（docs/04 §7）：
 * 1. 状态流用原生 `EventSource`（GET 即可）；
 * 2. **问答是 POST，EventSource 不支持** → 用 `fetch` + `ReadableStream` 手动解析 SSE 帧。
 */

import type {
  ChatRequestPayload,
  DocumentItem,
  StatusEvent,
  UploadResponse,
} from './types'

/** 开发期由 vite 代理转发；生产由 nginx 同域反代，所以默认为空 */
const BASE: string = import.meta.env.VITE_API_BASE ?? ''

/** 把后端返回的相对路径（/static/images/...）补全成可直接 <img src> 的地址 */
export function assetUrl(path: string): string {
  if (!path) return ''
  if (/^https?:\/\//.test(path)) return path
  return `${BASE}${path}`
}

async function handleError(response: Response): Promise<never> {
  let message = `请求失败（HTTP ${response.status}）`
  try {
    const body = await response.json()
    // 后端统一返回 {"detail": "...", "code": "..."}
    if (body?.detail) message = body.detail
  } catch {
    /* 非 JSON 响应，保留默认文案 */
  }
  throw new Error(message)
}

// ---------------------------------------------------------------------------
// 文档
// ---------------------------------------------------------------------------

export async function listDocuments(): Promise<DocumentItem[]> {
  const response = await fetch(`${BASE}/api/documents`)
  if (!response.ok) await handleError(response)
  return response.json()
}

export async function uploadDocuments(files: File[]): Promise<UploadResponse> {
  const form = new FormData()
  for (const file of files) form.append('files', file)

  const response = await fetch(`${BASE}/api/documents`, {
    method: 'POST',
    body: form,
  })
  if (!response.ok) await handleError(response)
  return response.json()
}

export async function deleteDocument(docId: string): Promise<void> {
  const response = await fetch(`${BASE}/api/documents/${docId}`, { method: 'DELETE' })
  if (!response.ok) await handleError(response)
}

export async function retryDocument(docId: string): Promise<void> {
  const response = await fetch(`${BASE}/api/documents/${docId}/retry`, { method: 'POST' })
  if (!response.ok) await handleError(response)
}

// ---------------------------------------------------------------------------
// 状态 SSE（GET）
// ---------------------------------------------------------------------------

/**
 * 订阅解析状态流。
 *
 * 契约（docs/04 §3）：
 * - `status` 事件是**覆盖式**的完整对象 → 前端按 doc_id 合并；
 * - `ping` 是心跳注释行，EventSource 不会触发任何事件；
 * - 断线后**应重新拉一次全量列表**（事件不编号，没有 Last-Event-ID 可补）。
 */
export function openStatusStream(handlers: {
  onStatus: (event: StatusEvent) => void
  onReconnect?: () => void
  onError?: (message: string) => void
}): EventSource {
  const source = new EventSource(`${BASE}/api/documents/events`)

  source.addEventListener('status', (raw) => {
    try {
      handlers.onStatus(JSON.parse((raw as MessageEvent).data) as StatusEvent)
    } catch {
      /* 单条坏帧不应中断整个流 */
    }
  })

  source.addEventListener('error', (raw) => {
    try {
      const payload = JSON.parse((raw as MessageEvent).data)
      handlers.onError?.(payload?.message ?? '状态流异常')
    } catch {
      /* 连接层错误没有 data，交给 onReconnect 处理 */
    }
    // EventSource 会自动重连；重连成功后必须补齐断线期间漏掉的状态
    handlers.onReconnect?.()
  })

  return source
}

// ---------------------------------------------------------------------------
// 问答 SSE（POST）
// ---------------------------------------------------------------------------

type ChatHandlers = {
  onDelta: (text: string) => void
  onCitation: (citation: import('./types').Citation) => void
  onDone: (payload: {
    session_id: string
    answer: string
    citations: import('./types').Citation[]
    retrieved_chunk_ids: string[]
  }) => void
  onError: (message: string) => void
}

/**
 * 发起问答并流式消费 SSE。
 *
 * `EventSource` 只支持 GET，而问答是 POST —— 所以必须用 fetch 手动解析帧。
 * 帧格式：`event: <name>\ndata: <json>\n\n`，可能跨越多次 read() 被切开。
 */
export async function streamChat(
  payload: ChatRequestPayload,
  handlers: ChatHandlers,
  signal?: AbortSignal,
): Promise<void> {
  const response = await fetch(`${BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
    body: JSON.stringify(payload),
    signal,
  })

  if (!response.ok) {
    // 参数校验失败等错误是普通 JSON，不是 SSE
    let message = `请求失败（HTTP ${response.status}）`
    try {
      const body = await response.json()
      if (body?.detail) message = body.detail
    } catch {
      /* ignore */
    }
    handlers.onError(message)
    return
  }

  const reader = response.body?.getReader()
  if (!reader) {
    handlers.onError('浏览器不支持流式响应')
    return
  }

  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })

      // 按空行切帧，最后一段可能是半个帧，留在 buffer 里
      const frames = buffer.split('\n\n')
      buffer = frames.pop() ?? ''

      for (const frame of frames) {
        dispatchFrame(frame, handlers)
      }
    }
    // 处理没有以空行结尾的最后一帧
    if (buffer.trim()) dispatchFrame(buffer, handlers)
  } catch (error) {
    if ((error as Error).name !== 'AbortError') {
      handlers.onError((error as Error).message || '网络中断')
    }
  }
}

function dispatchFrame(frame: string, handlers: ChatHandlers): void {
  const eventMatch = /^event:\s*(.+)$/m.exec(frame)
  const dataMatch = /^data:\s*(.+)$/m.exec(frame)
  if (!dataMatch) return

  const event = eventMatch?.[1]?.trim() ?? 'message'
  let payload: any
  try {
    payload = JSON.parse(dataMatch[1])
  } catch {
    return
  }

  switch (event) {
    case 'delta':
      handlers.onDelta(payload.text ?? '')
      break
    case 'citation':
      handlers.onCitation(payload)
      break
    case 'done':
      handlers.onDone(payload)
      break
    case 'error':
      handlers.onError(payload.message ?? '生成失败')
      break
    default:
      break
  }
}
