"""ESG 招投标标准化记录模型。

业务约束（见 CLAUDE.md 第五节）：

- 金额字段一律 ``Decimal``，禁止 float；未披露时为 ``None``，绝不默认填 0。
- 预算金额 / 最高限价 / 中标金额 / 合同金额是四个**互相独立**的字段，
  不允许互相填充。
- 细分行业只能取 CLAUDE.md 定义的 11 个分类，不新增分类。
- 公告日期为 ``date``；置信度为 0～1 的浮点数。
- ``source_url`` 必须是有效的 http/https URL。

模型本身不做任何金额换算或推断，只负责类型与取值约束。
"""

from __future__ import annotations

import logging
import math
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from enum import StrEnum

from pydantic import (
    AnyHttpUrl,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
)

logger = logging.getLogger(__name__)

CURRENCY_PATTERN = re.compile(r"^[A-Z]{3}$")


class AnnouncementType(StrEnum):
    """公告类型（固定 5 类，不新增）。"""

    TENDER = "招标公告"
    AWARD = "中标公告"
    PROCUREMENT = "采购公告"
    CORRECTION = "更正公告"
    OTHER = "其他"


# 常见同义写法 -> 标准值。仅做字符串归一，不做语义推断。
_ANNOUNCEMENT_ALIASES: dict[str, AnnouncementType] = {
    "招标公告": AnnouncementType.TENDER,
    "招标": AnnouncementType.TENDER,
    "中标公告": AnnouncementType.AWARD,
    "中标结果公告": AnnouncementType.AWARD,
    "中标结果": AnnouncementType.AWARD,
    "采购公告": AnnouncementType.PROCUREMENT,
    "采购": AnnouncementType.PROCUREMENT,
    "更正公告": AnnouncementType.CORRECTION,
    "变更公告": AnnouncementType.CORRECTION,
    "其他": AnnouncementType.OTHER,
}


class Industry(StrEnum):
    """ESG 细分行业（严格对应 CLAUDE.md 第五节，不得增删改）。"""

    NEW_ENERGY_STORAGE = "新能源与储能"
    ENERGY_ENVIRONMENT = "节能环保与污染治理"
    CARBON_MANAGEMENT = "碳管理"
    GREEN_BUILDING = "绿色建筑与市政"
    GREEN_TRANSPORT = "绿色交通与物流"
    CIRCULAR_RESOURCE = "资源循环与固废"
    WATER_ENVIRONMENT = "水务与水环境"
    FORESTRY_CARBON = "林业碳汇与生态"
    DIGITAL_CARBON_PLATFORM = "数字化碳管理平台"
    ESG_CONSULTING = "ESG 咨询 / 评级 / 报告编制"
    OTHER = "其他"


def _industry_key(text: str) -> str:
    """行业名归一化：去掉空白，统一斜杠写法。"""
    return re.sub(r"\s+", "", text).replace("／", "/")


_INDUSTRY_BY_KEY: dict[str, Industry] = {
    _industry_key(member.value): member for member in Industry
}


def _blank_to_none(value: object) -> object:
    """空字符串 / 纯空白 / 明确的"未披露"占位符一律视为未提供。"""
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped or stripped in {"未披露", "null", "NULL", "None", "-", "无"}:
            return None
        return stripped
    return value


def _parse_date(value: object) -> object:
    """接受 ISO 及常见中文/斜杠日期写法，统一转为 ``date``。

    仅做格式归一，不做"推算今天"之类的猜测；无法识别时交给 Pydantic 报错。
    """
    if value is None or isinstance(value, date):
        return value
    if not isinstance(value, str):
        return value

    text = value.strip()
    if not text:
        return None

    iso_candidate = text.replace("/", "-").replace(".", "-")
    iso_candidate = re.sub(r"[年月]", "-", iso_candidate).replace("日", "")
    iso_candidate = re.sub(r"\s+", "", iso_candidate)
    match = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", iso_candidate)
    if not match:
        return text  # 交给 Pydantic 给出格式错误
    year, month, day = (int(part) for part in match.groups())
    try:
        return date(year, month, day)
    except ValueError as exc:
        raise ValueError(f"publish_date 不是合法日期：{text!r}") from exc


def _parse_amount(value: object) -> object:
    """把金额归一为 Decimal；不做任何单位换算或推断。"""
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("金额不能是布尔值")

    if isinstance(value, str):
        text = value.strip().replace(",", "").replace("，", "")
        if not text or text in {"未披露", "null", "NULL", "None", "-", "无"}:
            return None
        try:
            value = Decimal(text)
        except InvalidOperation as exc:
            raise ValueError(f"金额必须是数字或 null，收到：{value!r}") from exc
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("金额必须是有限数值")
        # 经字符串转换，避免二进制浮点误差
        value = Decimal(str(value))
    elif isinstance(value, int):
        value = Decimal(value)

    if not isinstance(value, Decimal):
        raise ValueError(f"金额类型非法：{type(value).__name__}")
    if not value.is_finite():
        raise ValueError("金额必须是有限数值")
    if value < 0:
        raise ValueError("金额不能为负数")
    return value


class TenderRecord(BaseModel):
    """一条标准化的招投标记录。"""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        extra="ignore",
        validate_assignment=False,
    )

    # --- 文本字段 ------------------------------------------------------
    project_name: str = Field(min_length=1, description="项目名称")
    announcement_type: AnnouncementType = Field(description="公告类型")
    publish_date: date | None = Field(default=None, description="公告发布日期")
    region: str | None = Field(default=None, description="项目所在地区")
    industry: Industry = Field(description="ESG 细分行业")
    buyer: str | None = Field(default=None, description="招标/采购单位")
    winning_supplier: str | None = Field(default=None, description="中标单位")
    project_code: str | None = Field(default=None, description="项目编号")

    # --- 金额：四个独立口径 --------------------------------------------
    budget_amount: Decimal | None = Field(default=None, description="预算金额（元）")
    ceiling_price: Decimal | None = Field(default=None, description="最高限价（元）")
    bid_amount: Decimal | None = Field(default=None, description="中标金额（元）")
    contract_amount: Decimal | None = Field(default=None, description="合同金额（元）")
    amount_currency: str = Field(default="CNY", description="金额币种（ISO 4217）")

    # --- 来源与元信息 --------------------------------------------------
    source_url: AnyHttpUrl = Field(description="原始公告 URL")
    source_title: str | None = Field(default=None, description="网页标题")
    summary: str | None = Field(default=None, description="项目简要说明")
    confidence: float = Field(ge=0.0, le=1.0, description="提取置信度 0～1")
    remarks: str | None = Field(default=None, description="备注")

    # --- 校验器 --------------------------------------------------------
    @field_validator(
        "region",
        "buyer",
        "winning_supplier",
        "project_code",
        "source_title",
        "summary",
        "remarks",
        mode="before",
    )
    @classmethod
    def _empty_text_is_none(cls, value: object) -> object:
        return _blank_to_none(value)

    @field_validator("announcement_type", mode="before")
    @classmethod
    def _normalize_announcement_type(cls, value: object) -> object:
        if isinstance(value, AnnouncementType):
            return value
        if isinstance(value, str):
            text = re.sub(r"\s+", "", value)
            if text in _ANNOUNCEMENT_ALIASES:
                return _ANNOUNCEMENT_ALIASES[text]
            raise ValueError(
                f"announcement_type 必须是以下之一："
                f"{[item.value for item in AnnouncementType]}"
            )
        return value

    @field_validator("industry", mode="before")
    @classmethod
    def _normalize_industry(cls, value: object) -> object:
        if isinstance(value, Industry):
            return value
        if isinstance(value, str):
            key = _industry_key(value)
            if key in _INDUSTRY_BY_KEY:
                return _INDUSTRY_BY_KEY[key]
            raise ValueError(
                "industry 必须取自 CLAUDE.md 定义的细分行业，收到："
                f"{value!r}。可用取值：{[item.value for item in Industry]}"
            )
        return value

    @field_validator("publish_date", mode="before")
    @classmethod
    def _normalize_date(cls, value: object) -> object:
        return _parse_date(value)

    @field_validator(
        "budget_amount",
        "ceiling_price",
        "bid_amount",
        "contract_amount",
        mode="before",
    )
    @classmethod
    def _normalize_amount(cls, value: object) -> object:
        return _parse_amount(value)

    @field_validator("amount_currency", mode="before")
    @classmethod
    def _normalize_currency(cls, value: object) -> str:
        if value is None:
            return "CNY"
        text = str(value).strip().upper()
        if not CURRENCY_PATTERN.match(text):
            raise ValueError(f"amount_currency 必须是 3 位 ISO 4217 代码，收到：{value!r}")
        return text

    @field_validator("confidence", mode="before")
    @classmethod
    def _normalize_confidence(cls, value: object) -> object:
        if isinstance(value, bool):
            raise ValueError("confidence 不能是布尔值")
        return value

    # --- 便捷属性 ------------------------------------------------------
    @property
    def has_any_amount(self) -> bool:
        """是否存在任何已披露金额（不区分口径）。"""
        return any(
            amount is not None
            for amount in (
                self.budget_amount,
                self.ceiling_price,
                self.bid_amount,
                self.contract_amount,
            )
        )

    @property
    def counts_toward_award_statistics(self) -> bool:
        """只有明确披露的中标金额才参与中标金额统计（CLAUDE.md 第五节第 6 条）。"""
        return self.bid_amount is not None


__all__ = [
    "AnnouncementType",
    "Industry",
    "TenderRecord",
]
