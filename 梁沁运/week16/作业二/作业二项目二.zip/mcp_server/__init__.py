"""MCP Server 包（直接复用 services / db，不复制业务逻辑）。

不在包级别导入 ``mcp_server.server``，避免 ``python -m mcp_server.server``
触发 "module found in sys.modules" 的 runpy 警告。
"""

__all__: list[str] = []
