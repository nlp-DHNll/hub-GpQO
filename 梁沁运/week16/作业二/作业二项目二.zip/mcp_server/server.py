"""MCP Server：把已有业务能力暴露为 MCP Tools（stdio 传输，可独立启动）。

启动::

    python -m mcp_server.server
    # 或在 MCP 客户端配置中：
    #   command: python, args: ["-m", "mcp_server.server"], cwd: <项目根目录>

说明：

- Tools 直接调用 ``services/*`` 与 ``db.repository``，**不复制业务逻辑**。
- 不启动 APScheduler，不执行每日调度。
- 不建立额外数据库。
- 采集类 Tool 会真实调用外部 API，耗时较长（数十秒到数分钟）。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from config.settings import OUTPUT_DIR
from db.repository import TenderRepository
from services.analytics_service import generate_historical_analysis_report
from services.collection_service import run_historical_collection
from services.monitor_service import run_daily_monitor

logger = logging.getLogger(__name__)

HISTORY_REPORT_NAME = "historical_analysis_report.md"
DAILY_REPORT_NAME = "daily_monitor_report.md"

mcp = FastMCP(
    "esg-tender-intelligence",
    instructions=(
        "ESG 招投标情报工具集：可采集历史公告、生成历史分析报告、"
        "执行每日公告监控，并查询数据库记录与已生成的 Markdown 报告。"
        "所有金额口径严格区分预算金额、最高限价、中标金额与合同金额。"
    ),
)


# ---------------------------------------------------------------------------
# Tools：任务类
# ---------------------------------------------------------------------------


@mcp.tool(
    name="run_historical_collection",
    description="执行一次历史招投标公告采集（过去两年，真实调用 DeepSeek Search/Fetch 与硅基流动模型）。",
)
async def run_historical_collection_tool(max_urls: int | None = None) -> dict[str, Any]:
    report = await run_historical_collection(max_urls=max_urls)
    data = report.as_dict()
    # 失败列表可能很长，只返回前 20 条
    data["failures"] = data["failures"][:20]
    return data


@mcp.tool(
    name="generate_historical_analysis",
    description="基于数据库中的历史记录生成 Markdown 分析报告，返回统计结果与报告路径。",
)
async def generate_historical_analysis_tool(use_ai: bool = True) -> dict[str, Any]:
    outcome = await generate_historical_analysis_report(use_ai=use_ai)
    return outcome.as_dict()


@mcp.tool(
    name="run_daily_monitor",
    description="执行一次每日监控：搜索过去 24 小时 ESG 招标公告、时间过滤、去重入库并生成日报。",
)
async def run_daily_monitor_tool(use_ai: bool = True) -> dict[str, Any]:
    report = await run_daily_monitor(use_ai=use_ai)
    return report.as_dict()


# ---------------------------------------------------------------------------
# Tools：查询类
# ---------------------------------------------------------------------------


@mcp.tool(
    name="query_tender_records",
    description="分页查询招投标记录，可按公告类型、行业、关键词筛选，返回标准化记录列表。",
)
async def query_tender_records_tool(
    limit: int = 20,
    offset: int = 0,
    announcement_type: str | None = None,
    industry: str | None = None,
    keyword: str | None = None,
) -> dict[str, Any]:
    return query_records(
        TenderRepository(),
        limit=limit,
        offset=offset,
        announcement_type=announcement_type,
        industry=industry,
        keyword=keyword,
    )


def query_records(
    repository: TenderRepository,
    *,
    limit: int = 20,
    offset: int = 0,
    announcement_type: str | None = None,
    industry: str | None = None,
    keyword: str | None = None,
) -> dict[str, Any]:
    """查询实现（与 Tool 解耦，便于测试时注入临时数据库）。"""
    if not 1 <= limit <= 200:
        raise ValueError("limit 必须在 1～200 之间")
    if offset < 0:
        raise ValueError("offset 不能为负数")

    records = repository.list_records(limit=1_000_000, offset=0)
    if announcement_type:
        records = [item for item in records if item.announcement_type.value == announcement_type]
    if industry:
        records = [item for item in records if item.industry.value == industry]
    if keyword:
        needle = keyword.strip().lower()
        records = [
            item
            for item in records
            if needle in item.project_name.lower()
            or (item.buyer and needle in item.buyer.lower())
            or (item.winning_supplier and needle in item.winning_supplier.lower())
        ]
    page = records[offset : offset + limit]
    return {
        "total": len(records),
        "limit": limit,
        "offset": offset,
        "items": [item.model_dump(mode="json") for item in page],
    }


def _read_report(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"exists": False, "path": str(path), "markdown": None}
    return {
        "exists": True,
        "path": str(path),
        "markdown": path.read_text(encoding="utf-8"),
    }


@mcp.tool(
    name="get_analysis_report",
    description="获取最近一次生成的历史分析报告（Markdown 全文）。",
)
async def get_analysis_report_tool() -> dict[str, Any]:
    return _read_report(OUTPUT_DIR / HISTORY_REPORT_NAME)


@mcp.tool(
    name="get_daily_report",
    description="获取最近一次生成的每日监控日报（Markdown 全文）。",
)
async def get_daily_report_tool() -> dict[str, Any]:
    return _read_report(OUTPUT_DIR / DAILY_REPORT_NAME)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    mcp.run(transport="stdio")


__all__ = [
    "generate_historical_analysis_tool",
    "get_analysis_report_tool",
    "get_daily_report_tool",
    "main",
    "mcp",
    "query_records",
    "query_tender_records_tool",
    "run_daily_monitor_tool",
    "run_historical_collection_tool",
]


if __name__ == "__main__":
    main()
