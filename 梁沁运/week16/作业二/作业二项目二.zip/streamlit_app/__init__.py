"""Streamlit 前端包（页面入口：``streamlit run streamlit_app/app.py``）。"""
