"""Streamlit 前端（只通过 FastAPI 取数，不重复实现业务逻辑）。

启动::

    streamlit run streamlit_app/app.py

API 地址：环境变量 ``API_BASE_URL``，默认 ``http://127.0.0.1:8000``。
"""

from __future__ import annotations

import os
import time
from typing import Any

import httpx
import pandas as pd
import streamlit as st

API_BASE_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
REQUEST_TIMEOUT = 30.0
TASK_POLL_SECONDS = 120
TASK_POLL_INTERVAL = 2.0


# ---------------------------------------------------------------------------
# API 访问
# ---------------------------------------------------------------------------


def api_get(path: str, params: dict[str, Any] | None = None) -> Any:
    try:
        response = httpx.get(f"{API_BASE_URL}{path}", params=params, timeout=REQUEST_TIMEOUT)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"无法连接后端 API（{API_BASE_URL}）：{exc}") from exc
    if response.status_code >= 400:
        raise RuntimeError(_error_detail(response))
    return response.json()


def api_post(path: str) -> Any:
    try:
        response = httpx.post(f"{API_BASE_URL}{path}", timeout=REQUEST_TIMEOUT)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"无法连接后端 API（{API_BASE_URL}）：{exc}") from exc
    if response.status_code >= 400:
        raise RuntimeError(_error_detail(response))
    return response.json()


def _error_detail(response: httpx.Response) -> str:
    try:
        detail = response.json().get("detail")
    except ValueError:
        detail = response.text[:200]
    return f"API 返回 {response.status_code}：{detail}"


def submit_and_wait(path: str) -> dict[str, Any] | None:
    """提交任务并轮询到结束（最多 TASK_POLL_SECONDS 秒）。"""
    try:
        task = api_post(path)
    except RuntimeError as exc:
        st.error(str(exc))
        return None

    task_id = task["task_id"]
    placeholder = st.empty()
    deadline = time.time() + TASK_POLL_SECONDS
    while time.time() < deadline:
        state = api_get(f"/tasks/{task_id}")
        placeholder.info(f"任务 {task_id}：{state['status']} …")
        if state["status"] != "running":
            placeholder.empty()
            return state
        time.sleep(TASK_POLL_INTERVAL)
    placeholder.warning("任务仍在后台运行，可稍后刷新页面查看结果")
    return api_get(f"/tasks/{task_id}")


def show_task_state(state: dict[str, Any]) -> None:
    if state["status"] == "success":
        st.success(f"任务完成：{state['task_id']}")
        if state.get("result"):
            st.json(state["result"])
    elif state["status"] == "failed":
        st.error(f"任务失败：{state.get('error')}")
    else:
        st.info(f"任务状态：{state['status']}")


# ---------------------------------------------------------------------------
# 页面
# ---------------------------------------------------------------------------


def render_dashboard() -> None:
    st.header("仪表盘")
    try:
        stats = api_get("/stats")
    except RuntimeError as exc:
        st.error(str(exc))
        return

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("数据库记录总数", stats["total"])
    col2.metric("招标公告", stats["tender_count"])
    col3.metric("中标公告", stats["award_count"])
    col4.metric("已披露中标金额", stats["bid_disclosed_count"])

    st.subheader("最近一次监控")
    last = stats.get("last_monitor")
    if not last:
        st.info("本次运行期间尚无监控任务记录。")
        return
    status_text = {"running": "运行中", "success": "成功", "failed": "失败"}.get(
        last["status"], last["status"]
    )
    st.write(f"- 状态：**{status_text}**")
    st.write(f"- 开始：{last['created_at']}")
    st.write(f"- 结束：{last['finished_at'] or '—'}")
    if last.get("stats"):
        st.json(last["stats"])
    if last.get("error"):
        st.error(last["error"])


def render_records() -> None:
    st.header("历史数据")
    col1, col2, col3 = st.columns(3)
    announcement_type = col1.selectbox(
        "公告类型",
        ["全部", "招标公告", "中标公告", "采购公告", "更正公告", "其他"],
    )
    industry = col2.text_input("细分行业（精确匹配）")
    keyword = col3.text_input("关键词（项目名称/单位）")

    params: dict[str, Any] = {"limit": 100, "offset": 0}
    if announcement_type != "全部":
        params["announcement_type"] = announcement_type
    if industry.strip():
        params["industry"] = industry.strip()
    if keyword.strip():
        params["keyword"] = keyword.strip()

    try:
        payload = api_get("/records", params=params)
    except RuntimeError as exc:
        st.error(str(exc))
        return

    st.caption(f"共 {payload['total']} 条（当前展示 {len(payload['items'])} 条）")
    if not payload["items"]:
        st.info("暂无符合条件的记录。")
    else:
        df = pd.DataFrame(
            [
                {
                    "项目名称": item["project_name"],
                    "公告类型": item["announcement_type"],
                    "发布日期": item.get("publish_date") or "—",
                    "地区": item.get("region") or "—",
                    "行业": item["industry"],
                    "预算金额(元)": item.get("budget_amount"),
                    "中标金额(元)": item.get("bid_amount"),
                    "置信度": item.get("confidence"),
                    "来源": item.get("source_url"),
                }
                for item in payload["items"]
            ]
        )
        st.dataframe(df, use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("历史分析报告")
    try:
        report = api_get("/reports/history")
        st.markdown(report["markdown"])
    except RuntimeError as exc:
        st.info(f"暂无历史分析报告：{exc}")


def render_monitor() -> None:
    st.header("每日监控")
    if st.button("立即执行监控", type="primary"):
        state = submit_and_wait("/tasks/monitor")
        if state:
            show_task_state(state)

    st.divider()
    st.subheader("每日监控日报")
    try:
        report = api_get("/reports/daily")
        st.caption(f"最后更新：{report['modified_at']}")
        st.markdown(report["markdown"])
    except RuntimeError as exc:
        st.info(f"暂无每日监控日报：{exc}")

    st.divider()
    st.subheader("最近任务")
    try:
        tasks = api_get("/tasks", params={"limit": 10})["items"]
    except RuntimeError as exc:
        st.error(str(exc))
        return
    if not tasks:
        st.info("暂无任务记录。")
        return
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "任务 ID": item["task_id"],
                    "类型": item["task_type"],
                    "状态": item["status"],
                    "创建时间": item["created_at"],
                    "结束时间": item["finished_at"] or "—",
                    "错误": item["error"] or "",
                }
                for item in tasks
            ]
        ),
        use_container_width=True,
        hide_index=True,
    )


def render_tasks() -> None:
    st.header("手动任务")
    st.caption("任务由后端后台执行；同一类型任务运行中无法重复提交。")

    col1, col2, col3 = st.columns(3)
    if col1.button("历史数据采集"):
        state = submit_and_wait("/tasks/history")
        if state:
            show_task_state(state)
    if col2.button("生成历史分析报告"):
        state = submit_and_wait("/tasks/analyze")
        if state:
            show_task_state(state)
    if col3.button("执行每日监控"):
        state = submit_and_wait("/tasks/monitor")
        if state:
            show_task_state(state)


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


PAGES = {
    "仪表盘": render_dashboard,
    "历史数据": render_records,
    "每日监控": render_monitor,
    "手动任务": render_tasks,
}


def main() -> None:
    st.set_page_config(page_title="ESG 招投标情报系统", page_icon="📊", layout="wide")
    st.sidebar.title("ESG 招投标情报")
    st.sidebar.caption(f"API：{API_BASE_URL}")
    page = st.sidebar.radio("导航", list(PAGES), index=0)
    PAGES[page]()


if __name__ == "__main__":
    main()
