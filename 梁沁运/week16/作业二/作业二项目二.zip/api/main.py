"""FastAPI 后端：把已有业务服务暴露为 HTTP 接口。

设计原则：

- 只调用 ``services/*`` 与 ``db.repository``，**不复制任何业务逻辑**。
- 任务用 ``asyncio.create_task`` 执行，状态保存在进程内字典（单实例部署足够）。
- 同一类型任务运行中再次提交返回 409，避免重复采集/重复调用模型。
- 应用生命周期负责启动/关闭 APScheduler；调度器本身是进程内单例，
  因此**只需以单 worker 运行**，多 worker 会导致多个调度器（见 README/部署阶段）。

启动::

    uvicorn api.main:app --host 0.0.0.0 --port 8000 --workers 1
"""

from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Literal

from fastapi import Depends, FastAPI, HTTPException, Query

from config.settings import OUTPUT_DIR, Settings, get_settings
from db.repository import TenderRepository
from models.tender import AnnouncementType, Industry, TenderRecord
from services.analytics_service import generate_historical_analysis_report
from services.collection_service import run_historical_collection
from services.monitor_service import run_daily_monitor
from services.scheduler_service import start_scheduler, shutdown_scheduler

logger = logging.getLogger(__name__)

TaskType = Literal["history", "analyze", "monitor"]
TaskStatus = Literal["running", "success", "failed"]

TASK_RUNNERS: dict[TaskType, Callable[[], Awaitable[Any]]] = {
    "history": run_historical_collection,
    "analyze": generate_historical_analysis_report,
    "monitor": run_daily_monitor,
}

HISTORY_REPORT_NAME = "historical_analysis_report.md"
DAILY_REPORT_NAME = "daily_monitor_report.md"


# ---------------------------------------------------------------------------
# 依赖注入（测试可覆盖）
# ---------------------------------------------------------------------------


def get_repository() -> TenderRepository:
    return TenderRepository()


def get_output_dir() -> Path:
    return OUTPUT_DIR


def get_app_settings() -> Settings:
    return get_settings()


# ---------------------------------------------------------------------------
# 任务状态
# ---------------------------------------------------------------------------


@dataclass
class TaskState:
    task_id: str
    task_type: TaskType
    status: TaskStatus = "running"
    created_at: datetime = field(default_factory=lambda: datetime.now(get_settings().timezone))
    finished_at: datetime | None = None
    result: dict[str, Any] | None = None
    error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "result": self.result,
            "error": self.error,
        }


_tasks: dict[str, TaskState] = {}
_running: dict[TaskType, str] = {}


def _summarize(outcome: Any) -> dict[str, Any]:
    """把业务结果压缩成可 JSON 序列化的摘要（不返回整份 Markdown）。"""
    if hasattr(outcome, "as_dict"):
        data = outcome.as_dict()
        if isinstance(data, dict):
            return data
    return {"repr": repr(outcome)}


async def _run_task(task_id: str) -> None:
    state = _tasks[task_id]
    try:
        outcome = await TASK_RUNNERS[state.task_type]()
        state.result = _summarize(outcome)
        state.status = "success"
        logger.info("任务 %s（%s）执行成功", task_id, state.task_type)
    except Exception as exc:
        state.status = "failed"
        state.error = f"{type(exc).__name__}: {exc}"
        logger.exception("任务 %s（%s）执行失败", task_id, state.task_type)
    finally:
        state.finished_at = datetime.now(get_settings().timezone)
        _running.pop(state.task_type, None)


def _submit_task(task_type: TaskType) -> TaskState:
    if task_type in _running:
        existing = _running[task_type]
        raise HTTPException(
            status_code=409,
            detail=f"{task_type} 任务正在执行（task_id={existing}），请稍后再试",
        )
    task_id = uuid.uuid4().hex[:12]
    state = TaskState(task_id=task_id, task_type=task_type)
    _tasks[task_id] = state
    _running[task_type] = task_id
    import asyncio

    asyncio.create_task(_run_task(task_id))
    logger.info("任务已提交：%s（%s）", task_id, task_type)
    return state


# ---------------------------------------------------------------------------
# 应用
# ---------------------------------------------------------------------------


def _configure_logging(settings: Settings) -> None:
    """为应用进程配置一次标准 logging（已配置则跳过）。"""
    if logging.getLogger().handlers:
        return
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )


def create_app() -> FastAPI:
    _configure_logging(get_settings())

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        scheduler = start_scheduler()
        logger.info("FastAPI 启动：调度器 %s", "已启动" if scheduler.is_running else "未运行")
        try:
            yield
        finally:
            shutdown_scheduler()
            logger.info("FastAPI 关闭：调度器已关闭")

    application = FastAPI(
        title="ESG Tender Intelligence Agent API",
        version="1.0.0",
        lifespan=lifespan,
    )

    # --- 健康检查 ------------------------------------------------------

    @application.get("/health")
    async def health(settings: Settings = Depends(get_app_settings)) -> dict[str, Any]:
        return {
            "status": "ok",
            "app_env": settings.app_env,
            "timezone": settings.app_timezone,
            "time": datetime.now(settings.timezone).isoformat(),
        }

    # --- 记录查询 ------------------------------------------------------

    @application.get("/records")
    async def list_records(
        limit: int = Query(default=20, ge=1, le=200),
        offset: int = Query(default=0, ge=0),
        announcement_type: str | None = None,
        industry: str | None = None,
        keyword: str | None = None,
        repository: TenderRepository = Depends(get_repository),
    ) -> dict[str, Any]:
        records = repository.list_records(limit=1_000_000, offset=0)
        filtered = _filter_records(records, announcement_type, industry, keyword)
        page = filtered[offset : offset + limit]
        return {
            "total": len(filtered),
            "limit": limit,
            "offset": offset,
            "items": [_record_to_dict(item) for item in page],
        }

    @application.get("/stats")
    async def stats(
        repository: TenderRepository = Depends(get_repository),
    ) -> dict[str, Any]:
        records = repository.list_records(limit=1_000_000, offset=0)
        by_type = {member.value: 0 for member in AnnouncementType}
        by_industry = {member.value: 0 for member in Industry}
        for record in records:
            by_type[record.announcement_type.value] += 1
            by_industry[record.industry.value] += 1
        return {
            "total": len(records),
            "tender_count": by_type[AnnouncementType.TENDER.value],
            "award_count": by_type[AnnouncementType.AWARD.value],
            "procurement_count": by_type[AnnouncementType.PROCUREMENT.value],
            "correction_count": by_type[AnnouncementType.CORRECTION.value],
            "bid_disclosed_count": sum(1 for r in records if r.bid_amount is not None),
            "region_covered_count": sum(1 for r in records if r.region),
            "announcement_types": by_type,
            "industries": by_industry,
            "last_monitor": _last_monitor_summary(),
        }

    # --- 任务 ----------------------------------------------------------

    @application.post("/tasks/history", status_code=202)
    async def submit_history() -> dict[str, Any]:
        return _submit_task("history").as_dict()

    @application.post("/tasks/analyze", status_code=202)
    async def submit_analyze() -> dict[str, Any]:
        return _submit_task("analyze").as_dict()

    @application.post("/tasks/monitor", status_code=202)
    async def submit_monitor() -> dict[str, Any]:
        return _submit_task("monitor").as_dict()

    @application.get("/tasks")
    async def list_tasks(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
        items = sorted(_tasks.values(), key=lambda item: item.created_at, reverse=True)
        return {"items": [item.as_dict() for item in items[:limit]]}

    @application.get("/tasks/{task_id}")
    async def get_task(task_id: str) -> dict[str, Any]:
        state = _tasks.get(task_id)
        if state is None:
            raise HTTPException(status_code=404, detail=f"任务不存在：{task_id}")
        return state.as_dict()

    # --- 报告 ----------------------------------------------------------

    @application.get("/reports/history")
    async def history_report(output_dir: Path = Depends(get_output_dir)) -> dict[str, Any]:
        return _read_report(output_dir / HISTORY_REPORT_NAME)

    @application.get("/reports/daily")
    async def daily_report(output_dir: Path = Depends(get_output_dir)) -> dict[str, Any]:
        return _read_report(output_dir / DAILY_REPORT_NAME)

    return application


# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------


def _filter_records(
    records: list[TenderRecord],
    announcement_type: str | None,
    industry: str | None,
    keyword: str | None,
) -> list[TenderRecord]:
    result = records
    if announcement_type:
        result = [item for item in result if item.announcement_type.value == announcement_type]
    if industry:
        result = [item for item in result if item.industry.value == industry]
    if keyword:
        needle = keyword.strip().lower()
        result = [
            item
            for item in result
            if needle in item.project_name.lower()
            or (item.buyer and needle in item.buyer.lower())
            or (item.winning_supplier and needle in item.winning_supplier.lower())
        ]
    return result


def _record_to_dict(record: TenderRecord) -> dict[str, Any]:
    return record.model_dump(mode="json")


def _read_report(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"报告尚未生成：{path.name}")
    stat = path.stat()
    return {
        "path": str(path),
        "filename": path.name,
        "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "markdown": path.read_text(encoding="utf-8"),
    }


def _last_monitor_summary() -> dict[str, Any] | None:
    monitors = [item for item in _tasks.values() if item.task_type == "monitor"]
    if not monitors:
        return None
    latest = max(monitors, key=lambda item: item.created_at)
    return {
        "task_id": latest.task_id,
        "status": latest.status,
        "created_at": latest.created_at.isoformat(),
        "finished_at": latest.finished_at.isoformat() if latest.finished_at else None,
        "stats": (latest.result or {}).get("stats"),
        "error": latest.error,
    }


app = create_app()


__all__ = [
    "app",
    "create_app",
    "get_app_settings",
    "get_output_dir",
    "get_repository",
]
