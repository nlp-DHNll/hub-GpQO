"""FastAPI 应用层（只做接口编排，不实现业务逻辑）。"""

from api.main import app, create_app

__all__ = ["app", "create_app"]
