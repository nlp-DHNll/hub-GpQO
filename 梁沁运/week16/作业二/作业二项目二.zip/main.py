"""应用入口：启动 APScheduler 调度器并保持进程运行。

（本文件原先为 PyCharm 生成的示例模板，已按任务 08 要求替换为应用入口。）

用法::

    python app.py                 # 启动调度（每天 09:00 执行每日监控）
    python app.py --run monitor   # 立即执行一次每日监控后退出（不启动调度）
    python app.py --run history   # 立即执行历史采集后退出
    python app.py --run analyze   # 生成历史分析报告后退出

说明：

- 启动时**只**启动调度器，不自动执行历史采集或历史分析。
- ``--run history`` / ``--run analyze`` 是显式手动命令，会真实调用外部 API。
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import signal
import sys
from typing import Sequence

from config.settings import Settings, get_settings
from services.scheduler_service import start_scheduler, shutdown_scheduler

logger = logging.getLogger("esg_tender.app")

MANUAL_CHOICES = ("monitor", "history", "analyze")


def configure_logging(settings: Settings) -> None:
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        stream=sys.stdout,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="esg-tender-intelligence",
        description="ESG 招投标情报系统：定时监控 + 手动执行入口",
    )
    parser.add_argument(
        "--run",
        choices=MANUAL_CHOICES,
        help="立即执行一次指定任务后退出；不指定则启动定时调度并常驻运行",
    )
    return parser


async def run_manual(command: str) -> None:
    """手动执行单个业务入口（保持原函数语义，不做二次封装）。"""
    if command == "monitor":
        from services.monitor_service import run_daily_monitor

        logger.info("手动执行：每日监控")
        report = await run_daily_monitor()
        logger.info("每日监控完成：%s", report.report_path)
        return

    if command == "history":
        from services.collection_service import run_historical_collection

        logger.info("手动执行：历史采集")
        report = await run_historical_collection()
        logger.info("历史采集完成：新增 %d 条", report.stats.inserted_count)
        return

    if command == "analyze":
        from services.analytics_service import generate_historical_analysis_report

        logger.info("手动执行：历史分析报告")
        outcome = await generate_historical_analysis_report()
        logger.info("历史分析报告完成：%s（AI 分析：%s）", outcome.report_path, outcome.ai_used)
        return

    raise ValueError(f"未知命令：{command}")


async def serve_until_stopped() -> None:
    """启动调度器并常驻，收到退出信号时正常关闭。"""
    stop_event = asyncio.Event()

    def _request_stop(signame: str) -> None:
        logger.info("收到退出信号 %s，准备关闭调度器", signame)
        stop_event.set()

    loop = asyncio.get_running_loop()
    for signame in ("SIGINT", "SIGTERM"):
        try:
            loop.add_signal_handler(getattr(signal, signame), _request_stop, signame)
        except (NotImplementedError, AttributeError):  # Windows 下部分信号不可用
            pass

    scheduler = start_scheduler()  # 只启动调度，不自动执行历史采集/分析
    try:
        await stop_event.wait()
    finally:
        shutdown_scheduler()
        logger.info("应用已退出（调度器：%s）", "已关闭" if scheduler is None else "已关闭")


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = get_settings()
    configure_logging(settings)

    try:
        if args.run:
            asyncio.run(run_manual(args.run))
        else:
            logger.info("应用启动：APP_ENV=%s，调度时间 %02d:%02d（%s）",
                        settings.app_env, settings.monitor_hour, settings.monitor_minute,
                        settings.app_timezone)
            asyncio.run(serve_until_stopped())
    except KeyboardInterrupt:
        logger.info("应用被用户中断")
    except Exception:
        logger.exception("应用异常退出")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
