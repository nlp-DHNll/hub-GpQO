"""项目集中配置模块。

设计要点（对应 CLAUDE.md 第三节、第九节）：

1. 统一从项目根目录的 `.env` 读取配置；环境变量优先级高于 `.env`。
2. 使用 ``pydantic-settings`` 做类型校验，配置错误在导入时立即暴露。
3. 业务代码只能通过 ``get_settings()`` 访问配置，禁止直接 ``os.environ``。
4. **导入阶段不校验 API Key**：Key 字段为 ``AnyHttpUrl`` / ``SecretStr`` 且
   ``api_key_*`` 允许为空，保证单元测试、无 API 环境下的模块导入不受影响。
5. 只在显式调用 ``Settings.require_ready()`` / ``validate_required_settings()``
   时检查 Key，并给出清晰的**中文**缺失提示。
6. ``SecretStr`` 的 repr / str 均为 ``**********``，日志中不会出现明文 Key；
   ``ConfigurationError`` 消息只列出变量名，不包含值。

用法::

    from config.settings import get_settings

    settings = get_settings()          # 导入/单元测试阶段：不要求 Key
    settings.require_ready()           # 正式调用外部 API 前：校验 Key
"""

from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path
from typing import Final, Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import (
    AnyHttpUrl,
    Field,
    SecretStr,
    field_validator,
    model_validator,
)
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 路径常量
# ---------------------------------------------------------------------------

PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parent.parent
ENV_FILE: Final[Path] = PROJECT_ROOT / ".env"
DATA_DIR: Final[Path] = PROJECT_ROOT / "data"
OUTPUT_DIR: Final[Path] = PROJECT_ROOT / "output"

DEFAULT_DATABASE_URL: Final[str] = "sqlite:///data/esg_tender.db"

# 项目一已验证的 DeepSeek Fetch Endpoint（固定地址）。
DEFAULT_DEEPSEEK_FETCH_ENDPOINT: Final[str] = "https://api.deepseek.com/v1/tools/fetch"

# 必填 API 配置项 -> 中文说明。仅在 require_ready() 时使用。
REQUIRED_API_FIELDS: Final[dict[str, str]] = {
    "siliconflow_api_key": "SILICONFLOW_API_KEY（硅基流动推理 Key）",
    "siliconflow_base_url": "SILICONFLOW_BASE_URL（硅基流动 OpenAI 兼容地址）",
    "deepseek_model": "DEEPSEEK_MODEL（硅基流动上的模型 ID）",
    "deepseek_search_api_key": "DEEPSEEK_SEARCH_API_KEY（DeepSeek 官方 Key，Search/Fetch 共用）",
    "deepseek_search_base_url": "DEEPSEEK_SEARCH_BASE_URL（DeepSeek Search base URL）",
}


class ConfigurationError(RuntimeError):
    """缺少必要配置时抛出的异常。消息只包含变量名，不包含任何密钥值。"""


# ---------------------------------------------------------------------------
# 配置模型
# ---------------------------------------------------------------------------


class Settings(BaseSettings):
    """集中管理的运行配置。

    所有字段都有默认值或允许为空，因此 ``Settings()`` / ``get_settings()``
    在没有 ``.env``、没有设置任何环境变量的环境中也能成功构造。
    """

    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- 系统 ------------------------------------------------------------
    app_env: Literal["development", "production"] = "development"
    app_timezone: str = "Asia/Shanghai"
    database_url: str = DEFAULT_DATABASE_URL
    search_concurrency: int = Field(default=3, ge=1, le=20)
    monitor_hour: int = Field(default=9, ge=0, le=23)
    monitor_minute: int = Field(default=0, ge=0, le=59)
    request_timeout_seconds: float = Field(default=30.0, gt=0, le=600)
    log_level: str = "INFO"

    # --- SiliconFlow -----------------------------------------------------
    siliconflow_api_key: SecretStr | None = None
    siliconflow_base_url: AnyHttpUrl | None = None
    deepseek_model: str | None = None

    # --- DeepSeek Search / Fetch ----------------------------------------
    deepseek_search_api_key: SecretStr | None = None
    deepseek_search_base_url: AnyHttpUrl | None = None
    deepseek_search_endpoint: AnyHttpUrl | None = None
    deepseek_fetch_endpoint: AnyHttpUrl = Field(
        default=DEFAULT_DEEPSEEK_FETCH_ENDPOINT  # type: ignore[arg-type]
    )

    # ------------------------------------------------------------------
    # 校验器
    # ------------------------------------------------------------------

    @field_validator(
        "siliconflow_api_key",
        "siliconflow_base_url",
        "deepseek_model",
        "deepseek_search_api_key",
        "deepseek_search_base_url",
        "deepseek_search_endpoint",
        mode="before",
    )
    @classmethod
    def _empty_string_means_unset(cls, value: object) -> object:
        """`.env` 中留空的配置项视为"未配置"，而不是空字符串/非法 URL。"""
        if isinstance(value, str) and not value.strip():
            return None
        if isinstance(value, str):
            return value.strip()
        return value

    @field_validator("deepseek_model", mode="before")
    @classmethod
    def _strip_model_id(cls, value: object) -> object:
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return value

    @field_validator("app_timezone")
    @classmethod
    def _validate_timezone(cls, value: str) -> str:
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError) as exc:
            raise ValueError(
                f"APP_TIMEZONE 不是有效的 IANA 时区名称：{value!r}"
            ) from exc
        return value

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, value: str) -> str:
        level = value.upper()
        if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ValueError(f"LOG_LEVEL 取值非法：{value!r}")
        return level

    @model_validator(mode="after")
    def _validate_database_url(self) -> "Settings":
        if not self.database_url.startswith("sqlite:///"):
            raise ValueError(
                f"DATABASE_URL 必须以 sqlite:/// 开头：{self.database_url!r}"
            )
        return self

    # ------------------------------------------------------------------
    # 派生路径
    # ------------------------------------------------------------------

    @property
    def timezone(self) -> ZoneInfo:
        """业务时区对象。"""
        return ZoneInfo(self.app_timezone)

    @property
    def database_path(self) -> Path:
        """把 ``sqlite:///...`` URL 解析为绝对文件路径。

        相对路径一律相对**项目根目录**解析，不受当前工作目录影响；
        Docker 中通过 ``sqlite:////app/data/esg_tender.db`` 绝对路径指向挂载卷。
        """
        prefix = "sqlite:///"
        raw = self.database_url[len(prefix):]
        path = Path(raw)
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        return path

    @property
    def search_endpoint(self) -> str:
        """完整的 DeepSeek Search Endpoint。

        优先使用显式配置的 ``DEEPSEEK_SEARCH_ENDPOINT``；
        否则按项目一已验证规则从 ``DEEPSEEK_SEARCH_BASE_URL`` 推导。
        """
        if self.deepseek_search_endpoint is not None:
            return str(self.deepseek_search_endpoint).rstrip("/")

        if self.deepseek_search_base_url is None:
            raise ConfigurationError(
                "无法推导 Search Endpoint：DEEPSEEK_SEARCH_BASE_URL 与 "
                "DEEPSEEK_SEARCH_ENDPOINT 均未配置。"
            )
        base = str(self.deepseek_search_base_url).rstrip("/")
        # 与项目一 agents/researcher.build_search_endpoint 的兼容规则一致
        if base.endswith("/v1/tools/search"):
            return base
        if base.endswith("/v1/tools"):
            return f"{base}/search"
        if base.endswith("/v1"):
            return f"{base}/tools/search"
        return f"{base}/v1/tools/search"

    @property
    def fetch_endpoint(self) -> str:
        """完整的 DeepSeek Fetch Endpoint。"""
        return str(self.deepseek_fetch_endpoint).rstrip("/")

    # ------------------------------------------------------------------
    # 显式校验
    # ------------------------------------------------------------------

    def missing_required(self) -> list[str]:
        """返回缺失的必填 API 配置（中文描述列表）。"""
        missing: list[str] = []
        for field_name, description in REQUIRED_API_FIELDS.items():
            value = getattr(self, field_name)
            if value is None or (isinstance(value, SecretStr) and not value.get_secret_value().strip()):
                missing.append(description)
        return missing

    def require_ready(self) -> None:
        """检查必填 API 配置；缺失时抛出 ``ConfigurationError``。

        仅列出变量名与用途，绝不打印密钥值。
        """
        missing = self.missing_required()
        if not missing:
            return

        message = (
            "缺少必要的 API 配置：\n"
            + "\n".join(f"  - {item}" for item in missing)
            + f"\n\n请将 {ENV_FILE.name}.example 复制为 {ENV_FILE.name}，"
            "并按服务商官方文档 / 项目一已验证实现填写上述变量。\n"
            f"配置文件位置：{ENV_FILE}\n"
            "注意：.env 包含密钥，不要提交到代码仓库。"
        )
        logger.error("配置校验失败，缺失 %d 项必要配置。", len(missing))
        raise ConfigurationError(message)


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """加载配置（结果缓存，进程内单例）。

    导入阶段不抛异常：即使 `.env` 缺失或 Key 为空也返回 Settings 对象。
    需要 Key 的模块应在首次调用外部 API 前显式调用 ``require_ready()``。
    """
    settings = Settings()
    logger.debug(
        "配置已加载：env=%s timezone=%s db=%s concurrency=%d monitor=%02d:%02d",
        settings.app_env,
        settings.app_timezone,
        settings.database_url,
        settings.search_concurrency,
        settings.monitor_hour,
        settings.monitor_minute,
    )
    return settings


def validate_required_settings(settings: Settings | None = None) -> None:
    """显式校验必填 API 配置，供正式运行前调用。"""
    (settings or get_settings()).require_ready()


def ensure_data_dir(settings: Settings | None = None) -> Path:
    """确保 SQLite 所在目录存在，返回数据库文件路径。"""
    path = (settings or get_settings()).database_path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


__all__ = [
    "DATA_DIR",
    "DEFAULT_DATABASE_URL",
    "DEFAULT_DEEPSEEK_FETCH_ENDPOINT",
    "ENV_FILE",
    "OUTPUT_DIR",
    "PROJECT_ROOT",
    "ConfigurationError",
    "Settings",
    "ensure_data_dir",
    "get_settings",
    "validate_required_settings",
]
