"""项目配置包。

对外只暴露集中配置入口，业务代码应使用：

    from config.settings import Settings, get_settings

不要在业务代码中直接读取 os.environ。
"""

from config.settings import (
    ConfigurationError,
    Settings,
    get_settings,
    validate_required_settings,
)

__all__ = [
    "ConfigurationError",
    "Settings",
    "get_settings",
    "validate_required_settings",
]
