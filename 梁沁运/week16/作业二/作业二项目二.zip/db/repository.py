"""招投标记录的入库、URL 去重与查询。

去重规则（任务书第三节第 3 条）：

- 去重键是 ``normalized_url``（见 ``db.database.normalize_source_url``），
  表上建立 UNIQUE 约束；
- 相同规范化 URL 再次入库判定为重复，**不新增记录、不覆盖已有记录、
  不抛未处理异常**；
- ``project_code`` 相同**不算**重复：同一项目的招标 / 中标 / 更正公告
  各自保存，互不覆盖。

金额在库中以 TEXT 保存 Decimal 字符串，读取时还原为 Decimal（不经过 float）。
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any

from config.settings import get_settings
from db.database import TendersDatabase, get_database, normalize_source_url
from models.tender import TenderRecord

logger = logging.getLogger(__name__)

TABLE_NAME = "tender_records"

# TenderRecord 字段 -> 数据库列（顺序与表结构一致）
_RECORD_COLUMNS: tuple[str, ...] = (
    "project_name",
    "announcement_type",
    "publish_date",
    "region",
    "industry",
    "buyer",
    "winning_supplier",
    "project_code",
    "budget_amount",
    "ceiling_price",
    "bid_amount",
    "contract_amount",
    "amount_currency",
    "source_url",
    "normalized_url",
    "source_title",
    "summary",
    "confidence",
    "remarks",
    "created_at",
)

_AMOUNT_COLUMNS: tuple[str, ...] = (
    "budget_amount",
    "ceiling_price",
    "bid_amount",
    "contract_amount",
)

_INSERT_SQL = (
    f"INSERT INTO {TABLE_NAME} ({', '.join(_RECORD_COLUMNS)}) "
    f"VALUES ({', '.join('?' for _ in _RECORD_COLUMNS)})"
)


class SaveOutcome(StrEnum):
    """入库结果。"""

    INSERTED = "inserted"
    DUPLICATE = "duplicate"


@dataclass(frozen=True)
class SaveResult:
    """入库返回值：区分新插入与重复。"""

    outcome: SaveOutcome
    record_id: int
    normalized_url: str

    @property
    def inserted(self) -> bool:
        return self.outcome is SaveOutcome.INSERTED

    @property
    def duplicate(self) -> bool:
        return self.outcome is SaveOutcome.DUPLICATE


class DuplicateRecordError(ValueError):
    """严格模式下令库发现重复时抛出（仅在 ``strict=True`` 时使用）。"""

    def __init__(self, normalized_url: str, existing_id: int) -> None:
        super().__init__(f"记录已存在：normalized_url={normalized_url}，id={existing_id}")
        self.normalized_url = normalized_url
        self.existing_id = existing_id


# ---------------------------------------------------------------------------
# 序列化
# ---------------------------------------------------------------------------


def _amount_to_text(value: Decimal | None) -> str | None:
    """Decimal -> TEXT。使用定点字符串，绝不变成 float 科学计数法。"""
    if value is None:
        return None
    return format(value, "f")


def _text_to_amount(value: str | None) -> Decimal | None:
    """TEXT -> Decimal；空值仍为 None，绝不为 0。"""
    if value is None or value == "":
        return None
    try:
        return Decimal(value)
    except InvalidOperation as exc:  # 数据被外部改坏时给出明确错误
        raise ValueError(f"数据库中金额字段不是合法 Decimal：{value!r}") from exc


def _record_to_row(
    record: TenderRecord, normalized_url: str, created_at: datetime
) -> tuple[Any, ...]:
    data: dict[str, Any] = {
        "project_name": record.project_name,
        "announcement_type": record.announcement_type.value,
        "publish_date": record.publish_date.isoformat() if record.publish_date else None,
        "region": record.region,
        "industry": record.industry.value,
        "buyer": record.buyer,
        "winning_supplier": record.winning_supplier,
        "project_code": record.project_code,
        "budget_amount": _amount_to_text(record.budget_amount),
        "ceiling_price": _amount_to_text(record.ceiling_price),
        "bid_amount": _amount_to_text(record.bid_amount),
        "contract_amount": _amount_to_text(record.contract_amount),
        "amount_currency": record.amount_currency,
        "source_url": str(record.source_url),
        "normalized_url": normalized_url,
        "source_title": record.source_title,
        "summary": record.summary,
        "confidence": record.confidence,
        "remarks": record.remarks,
        "created_at": created_at.isoformat(timespec="seconds"),
    }
    return tuple(data[column] for column in _RECORD_COLUMNS)


def _row_to_record(row: sqlite3.Row) -> TenderRecord:
    """数据库行 -> TenderRecord（金额按 Decimal 还原，日期/枚举由 Pydantic 校验）。"""
    return TenderRecord.model_validate(
        {
            "project_name": row["project_name"],
            "announcement_type": row["announcement_type"],
            "publish_date": row["publish_date"],
            "region": row["region"],
            "industry": row["industry"],
            "buyer": row["buyer"],
            "winning_supplier": row["winning_supplier"],
            "project_code": row["project_code"],
            "budget_amount": _text_to_amount(row["budget_amount"]),
            "ceiling_price": _text_to_amount(row["ceiling_price"]),
            "bid_amount": _text_to_amount(row["bid_amount"]),
            "contract_amount": _text_to_amount(row["contract_amount"]),
            "amount_currency": row["amount_currency"],
            "source_url": row["source_url"],
            "source_title": row["source_title"],
            "summary": row["summary"],
            "confidence": row["confidence"],
            "remarks": row["remarks"],
        }
    )


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    """带 id / normalized_url / created_at 的原始行（便于审计与前端展示）。"""
    data = dict(row)
    for column in _AMOUNT_COLUMNS:
        data[column] = _text_to_amount(data.get(column))
    return data


# ---------------------------------------------------------------------------
# 仓库
# ---------------------------------------------------------------------------


class TenderRepository:
    """招投标记录仓库。"""

    def __init__(
        self,
        database: TendersDatabase | None = None,
        *,
        clock: Any = None,
    ) -> None:
        self._db = database or get_database()
        self._db.initialize()
        self._clock = clock or (lambda: datetime.now(get_settings().timezone))

    @property
    def database(self) -> TendersDatabase:
        return self._db

    # --- 写入 ----------------------------------------------------------

    def save_record(self, record: TenderRecord, *, strict: bool = False) -> SaveResult:
        """保存一条记录；相同规范化 URL 视为重复。

        :param strict: ``True`` 时发现重复抛 ``DuplicateRecordError``，
            默认 ``False`` 返回 ``SaveOutcome.DUPLICATE``，不抛异常。
        """
        normalized = normalize_source_url(str(record.source_url))
        row = _record_to_row(record, normalized, self._clock())

        with self._db.connect() as conn:
            try:
                cursor = conn.execute(_INSERT_SQL, row)
            except sqlite3.IntegrityError as exc:
                existing = self._find_id_by_normalized_url(conn, normalized)
                if existing is None:
                    raise  # 非 UNIQUE 冲突（如 NOT NULL），如实抛出
                logger.info("重复公告已跳过：id=%s url=%s", existing, normalized)
                if strict:
                    raise DuplicateRecordError(normalized, existing) from exc
                return SaveResult(SaveOutcome.DUPLICATE, existing, normalized)
            record_id = int(cursor.lastrowid)

        logger.info("新公告入库：id=%d url=%s", record_id, normalized)
        return SaveResult(SaveOutcome.INSERTED, record_id, normalized)

    def save_records(self, records: list[TenderRecord]) -> list[SaveResult]:
        """批量保存（逐条提交，单条失败不影响已成功记录）。"""
        return [self.save_record(record) for record in records]

    @staticmethod
    def _find_id_by_normalized_url(
        conn: sqlite3.Connection, normalized_url: str
    ) -> int | None:
        row = conn.execute(
            f"SELECT id FROM {TABLE_NAME} WHERE normalized_url = ?",
            (normalized_url,),
        ).fetchone()
        return int(row["id"]) if row is not None else None

    # --- 查询 ----------------------------------------------------------

    def exists_by_url(self, source_url: str) -> bool:
        """该来源 URL（规范化后）是否已入库。"""
        return self.find_id_by_url(source_url) is not None

    def find_id_by_url(self, source_url: str) -> int | None:
        normalized = normalize_source_url(source_url)
        with self._db.connect() as conn:
            return self._find_id_by_normalized_url(conn, normalized)

    def get_by_id(self, record_id: int) -> TenderRecord | None:
        with self._db.connect() as conn:
            row = conn.execute(
                f"SELECT * FROM {TABLE_NAME} WHERE id = ?", (record_id,)
            ).fetchone()
        return _row_to_record(row) if row is not None else None

    def get_detail_by_id(self, record_id: int) -> dict[str, Any] | None:
        with self._db.connect() as conn:
            row = conn.execute(
                f"SELECT * FROM {TABLE_NAME} WHERE id = ?", (record_id,)
            ).fetchone()
        return _row_to_dict(row) if row is not None else None

    def get_by_source_url(self, source_url: str) -> TenderRecord | None:
        normalized = normalize_source_url(source_url)
        with self._db.connect() as conn:
            row = conn.execute(
                f"SELECT * FROM {TABLE_NAME} WHERE normalized_url = ?",
                (normalized,),
            ).fetchone()
        return _row_to_record(row) if row is not None else None

    def list_records(
        self, *, limit: int = 100, offset: int = 0
    ) -> list[TenderRecord]:
        """按 id 升序分页查询。"""
        if limit < 1:
            raise ValueError("limit 必须为正整数")
        if offset < 0:
            raise ValueError("offset 不能为负数")
        with self._db.connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM {TABLE_NAME} ORDER BY id ASC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        return [_row_to_record(row) for row in rows]

    def find_by_project_code(self, project_code: str) -> list[TenderRecord]:
        """按项目编号查询（可能包含招标/中标/更正等多条公告）。"""
        with self._db.connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM {TABLE_NAME} WHERE project_code = ? ORDER BY id ASC",
                (project_code,),
            ).fetchall()
        return [_row_to_record(row) for row in rows]

    def count(self) -> int:
        with self._db.connect() as conn:
            row = conn.execute(f"SELECT COUNT(*) AS n FROM {TABLE_NAME}").fetchone()
        return int(row["n"])


__all__ = [
    "DuplicateRecordError",
    "SaveOutcome",
    "SaveResult",
    "TenderRepository",
]
