"""SQLite 持久化包（标准库 sqlite3，不引入 ORM）。

- ``database``：连接、路径处理、建表初始化。
- ``repository``：入库、URL 去重、查询。
"""

from db.database import (
    SCHEMA_SQL,
    TendersDatabase,
    get_database,
    normalize_source_url,
)
from db.repository import (
    DuplicateRecordError,
    SaveOutcome,
    SaveResult,
    TenderRepository,
)

__all__ = [
    "SCHEMA_SQL",
    "DuplicateRecordError",
    "SaveOutcome",
    "SaveResult",
    "TenderRepository",
    "TendersDatabase",
    "get_database",
    "normalize_source_url",
]
