"""SQLite 连接、路径处理与建表（Python 标准库 ``sqlite3``）。

数据库位置完全由 ``settings.database_url`` 决定（默认 ``sqlite:///data/esg_tender.db``），
本模块不读取任何环境变量，也不改变现有配置。

金额字段以 TEXT 保存 Decimal，避免浮点精度损失；日期保存 ISO 字符串；
枚举字段保存枚举的实际取值。
"""

from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator
from urllib.parse import urlsplit, urlunsplit

from config.settings import Settings, get_settings

logger = logging.getLogger(__name__)

DEFAULT_DB_PATH: Path = Path("data") / "esg_tender.db"


def normalize_source_url(url: str) -> str:
    """入库去重用的轻量 URL 规范化。

    只做三件事（任务书第三节第 3 条）：

    1. 去除首尾空白；
    2. scheme 与 hostname 统一小写（含端口之外的 userinfo 不动）；
    3. 移除 fragment（``#...``）。

    **不**删除查询参数、**不**合并路径中的重复斜杠、
    **不**统一末尾斜杠、**不**改动路径大小写。
    """
    value = url.strip()
    if not value:
        raise ValueError("URL 不能为空")

    parts = urlsplit(value)
    if not parts.scheme and not parts.netloc:
        return value

    netloc = parts.netloc
    if "@" in netloc:
        userinfo, _, hostport = netloc.rpartition("@")
        netloc = f"{userinfo}@{hostport.lower()}"
    else:
        netloc = netloc.lower()

    return urlunsplit(
        (parts.scheme.lower(), netloc, parts.path, parts.query, "")
    )


# 字段顺序与 TenderRecord 保持一致；金额列以 _text 结尾，存 Decimal 的字符串形式。
SCHEMA_SQL: str = """
CREATE TABLE IF NOT EXISTS tender_records (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name      TEXT    NOT NULL,
    announcement_type TEXT    NOT NULL,
    publish_date      TEXT,
    region            TEXT,
    industry          TEXT    NOT NULL,
    buyer             TEXT,
    winning_supplier  TEXT,
    project_code      TEXT,
    budget_amount     TEXT,
    ceiling_price     TEXT,
    bid_amount        TEXT,
    contract_amount   TEXT,
    amount_currency   TEXT    NOT NULL DEFAULT 'CNY',
    source_url        TEXT    NOT NULL,
    normalized_url    TEXT    NOT NULL UNIQUE,
    source_title      TEXT,
    summary           TEXT,
    confidence        REAL    NOT NULL,
    remarks           TEXT,
    created_at        TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tender_records_source_url
    ON tender_records (source_url);

CREATE INDEX IF NOT EXISTS idx_tender_records_project_code
    ON tender_records (project_code);

CREATE INDEX IF NOT EXISTS idx_tender_records_publish_date
    ON tender_records (publish_date);
"""


@dataclass(frozen=True)
class DatabaseInfo:
    """数据库位置的描述信息（便于日志与排查）。"""

    path: Path
    exists: bool


def resolve_database_path(settings: Settings | None = None) -> Path:
    """从 settings 解析 SQLite 文件路径；非 sqlite 配置直接报错。"""
    settings = settings or get_settings()
    return settings.database_path


class TendersDatabase:
    """SQLite 数据库句柄：负责建表与提供连接。

    - 每次操作使用独立连接（``with self.connect() as conn``），
      避免跨线程共享连接；仓库层会显式 ``commit``。
    - 文件型数据库首次使用时自动创建父目录。
    - 支持 ``:memory:``（测试用），但内存库的每次新连接都是空库，
      因此测试应使用临时文件路径。
    """

    def __init__(self, path: Path | str | None = None, settings: Settings | None = None) -> None:
        if path is None:
            path = resolve_database_path(settings)
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    @property
    def info(self) -> DatabaseInfo:
        return DatabaseInfo(path=self._path, exists=self._path.exists())

    def _ensure_directory(self) -> None:
        if str(self._path) == ":memory:":
            return
        self._path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """打开连接；正常退出时提交，异常时回滚。"""
        self._ensure_directory()
        conn = sqlite3.connect(str(self._path), timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def initialize(self) -> DatabaseInfo:
        """创建表与索引（幂等）。"""
        with self.connect() as conn:
            conn.executescript(SCHEMA_SQL)
        logger.info("数据库已初始化：%s", self._path)
        return self.info

    def table_exists(self, table: str = "tender_records") -> bool:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table,),
            ).fetchone()
        return row is not None

    def count(self, table: str = "tender_records") -> int:
        self.initialize()
        with self.connect() as conn:
            row = conn.execute(f"SELECT COUNT(*) AS n FROM {table}").fetchone()
        return int(row["n"])


_default_database: TendersDatabase | None = None


def get_database(settings: Settings | None = None) -> TendersDatabase:
    """进程内默认数据库（路径来自 settings）。"""
    global _default_database
    if _default_database is None:
        _default_database = TendersDatabase(settings=settings)
        _default_database.initialize()
    return _default_database


__all__ = [
    "DEFAULT_DB_PATH",
    "SCHEMA_SQL",
    "DatabaseInfo",
    "TendersDatabase",
    "get_database",
    "normalize_source_url",
    "resolve_database_path",
]
