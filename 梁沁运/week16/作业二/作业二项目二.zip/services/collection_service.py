"""历史公告采集流程编排（任务 A 的采集阶段）。

只做编排，不重写任何已有能力：

    scripts.query_builder.build_historical_queries   生成 Query
    scripts.date_utils.get_historical_date_range     计算两年窗口
    services.deepseek_client.DeepSeekClient          Search / Fetch（自带 Semaphore）
    services.extraction_service.ExtractionService    结构化提取
    db.repository.TenderRepository                   入库与 URL 去重

流程：Query → Search（并发）→ URL 去重 → 跳过库内已有 → Fetch（并发）
     → 模型提取（顺序执行）→ 入库 → 汇总统计。

并发说明：Search / Fetch 的并发完全由 ``DeepSeekClient`` 内部
``asyncio.Semaphore(SEARCH_CONCURRENCY)`` 控制；本模块**不新建第二套并发机制**，
提取阶段顺序执行，避免对 SiliconFlow 造成未受控的并发压力。

异常隔离：单条公告 Fetch 失败、提取失败或入库失败只记录在 ``failures`` 中，
不会中断整个任务；配置缺失（如未填 SiliconFlow Key）属于全局问题，直接抛出。
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Literal

from config.settings import ConfigurationError, Settings, get_settings
from db.database import normalize_source_url
from db.repository import SaveOutcome, TenderRepository
from models.tender import TenderRecord
from scripts.date_utils import DateRange, get_historical_date_range
from scripts.query_builder import build_historical_queries
from services.deepseek_client import DeepSeekClient, SearchResult
from services.extraction_service import ExtractionService, get_extraction_service

logger = logging.getLogger(__name__)

FailureStage = Literal["fetch", "extraction", "save"]


@dataclass
class CollectionStats:
    """单次采集运行的统计（字段名与任务书要求一一对应）。"""

    query_count: int = 0
    search_url_count: int = 0
    unique_url_count: int = 0
    skipped_existing_count: int = 0
    fetch_success_count: int = 0
    fetch_failed_count: int = 0
    extraction_success_count: int = 0
    extraction_failed_count: int = 0
    inserted_count: int = 0
    duplicate_count: int = 0
    # 额外统计：入库异常（任务书未要求，但便于排查数据库问题）
    save_failed_count: int = 0

    def as_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(frozen=True)
class CollectionFailure:
    """单条公告的失败记录。"""

    url: str
    stage: FailureStage
    error: str

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class CollectionReport:
    """采集运行结果。"""

    date_range: DateRange
    started_at: datetime
    finished_at: datetime
    stats: CollectionStats
    failures: list[CollectionFailure] = field(default_factory=list)
    inserted_record_ids: list[int] = field(default_factory=list)

    @property
    def duration_seconds(self) -> float:
        return (self.finished_at - self.started_at).total_seconds()

    def as_dict(self) -> dict[str, Any]:
        return {
            "date_range": self.date_range.describe(),
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat(),
            "duration_seconds": round(self.duration_seconds, 2),
            "stats": self.stats.as_dict(),
            "failures": [item.as_dict() for item in self.failures],
            "inserted_record_ids": list(self.inserted_record_ids),
        }


@dataclass(frozen=True)
class _Candidate:
    """去重后的待处理公告。"""

    url: str
    title: str = ""


async def run_historical_collection(
    *,
    date_range: DateRange | None = None,
    client: DeepSeekClient | None = None,
    extractor: ExtractionService | None = None,
    repository: TenderRepository | None = None,
    settings: Settings | None = None,
    max_urls: int | None = None,
) -> CollectionReport:
    """执行一次历史公告采集。

    :param date_range: 采集窗口；为空则按运行日期往前推两年
    :param client: 可注入的 ``DeepSeekClient``（测试用）；未注入时自建并关闭
    :param extractor: 可注入的提取服务；默认使用进程内共享实例
    :param repository: 可注入的仓库；默认使用 settings 指向的 SQLite
    :param max_urls: 本次最多处理的 URL 数（安全阀，便于小规模试跑）
    """
    settings = settings or get_settings()
    date_range = date_range or get_historical_date_range()
    repository = repository or TenderRepository()
    extractor = extractor or get_extraction_service()

    owns_client = client is None
    client = client or DeepSeekClient(settings=settings)

    started_at = datetime.now(settings.timezone)
    stats = CollectionStats()
    failures: list[CollectionFailure] = []
    inserted_ids: list[int] = []

    try:
        # --- 1. Query ----------------------------------------------------
        queries = build_historical_queries(date_range)
        stats.query_count = len(queries)
        logger.info(
            "历史采集开始：报告期 %s，Query %d 条", date_range.describe(), len(queries)
        )

        # --- 2. Search（并发由 DeepSeekClient 控制）-----------------------
        search_results = await client.search_many([query.text for query in queries])
        stats.search_url_count = sum(len(result.items) for result in search_results)
        logger.info(
            "Search 完成：Query %d，返回 URL %d 条",
            len(search_results),
            stats.search_url_count,
        )

        # --- 3. 批内 URL 去重 --------------------------------------------
        candidates = _deduplicate_candidates(search_results)
        stats.unique_url_count = len(candidates)
        logger.info("批内去重后 URL %d 条", stats.unique_url_count)

        # --- 4. 跳过库内已有 URL（不再 Fetch）----------------------------
        pending: list[_Candidate] = []
        for candidate in candidates.values():
            if repository.exists_by_url(candidate.url):
                stats.skipped_existing_count += 1
                continue
            pending.append(candidate)
        logger.info(
            "跳过库内已有 %d 条，待抓取 %d 条",
            stats.skipped_existing_count,
            len(pending),
        )

        if max_urls is not None:
            if max_urls < 1:
                raise ValueError("max_urls 必须为正整数")
            if len(pending) > max_urls:
                logger.info("按 max_urls=%d 截断待处理 URL", max_urls)
                pending = pending[:max_urls]

        # --- 5. Fetch（并发由 DeepSeekClient 控制）-----------------------
        fetch_results = await client.fetch_many([item.url for item in pending])

        # --- 6~8. 提取 + 入库（逐条，失败隔离）---------------------------
        for candidate, fetched in zip(pending, fetch_results, strict=True):
            if fetched.status == "error" or not fetched.content.strip():
                stats.fetch_failed_count += 1
                reason = fetched.error or "正文为空"
                failures.append(CollectionFailure(candidate.url, "fetch", reason))
                logger.warning("Fetch 失败，跳过：%s（%s）", candidate.url, reason)
                continue
            stats.fetch_success_count += 1

            title = (fetched.title or candidate.title or "").strip()
            try:
                record = await extractor.extract_tender_record(
                    fetched.content, fetched.url, title or None
                )
            except ConfigurationError:
                # 全局配置问题，不应被逐条吞掉
                raise
            except Exception as exc:
                stats.extraction_failed_count += 1
                message = f"{type(exc).__name__}: {exc}"
                failures.append(CollectionFailure(candidate.url, "extraction", message))
                logger.warning("提取失败，跳过：%s（%s）", candidate.url, message)
                continue
            stats.extraction_success_count += 1

            try:
                save_result = repository.save_record(record)
            except Exception as exc:
                stats.save_failed_count += 1
                message = f"{type(exc).__name__}: {exc}"
                failures.append(CollectionFailure(candidate.url, "save", message))
                logger.warning("入库失败，跳过：%s（%s）", candidate.url, message)
                continue

            if save_result.outcome is SaveOutcome.INSERTED:
                stats.inserted_count += 1
                inserted_ids.append(save_result.record_id)
            else:
                stats.duplicate_count += 1
    finally:
        if owns_client:
            await client.aclose()

    finished_at = datetime.now(settings.timezone)
    report = CollectionReport(
        date_range=date_range,
        started_at=started_at,
        finished_at=finished_at,
        stats=stats,
        failures=failures,
        inserted_record_ids=inserted_ids,
    )
    logger.info(
        "历史采集完成：Query %d，URL %d，新增 %d，重复 %d，Fetch 失败 %d，提取失败 %d，"
        "耗时 %.1f 秒",
        stats.query_count,
        stats.unique_url_count,
        stats.inserted_count,
        stats.duplicate_count,
        stats.fetch_failed_count,
        stats.extraction_failed_count,
        report.duration_seconds,
    )
    return report


def _deduplicate_candidates(
    search_results: list[SearchResult],
) -> dict[str, _Candidate]:
    """把多条 Query 的搜索结果合并，按规范化 URL 去重（保留首条标题）。"""
    candidates: dict[str, _Candidate] = {}
    for search_result in search_results:
        for item in search_result.items:
            try:
                key = normalize_source_url(item.url)
            except ValueError:
                continue
            if key in candidates:
                continue
            candidates[key] = _Candidate(url=item.url, title=item.title)
    return candidates


__all__ = [
    "CollectionFailure",
    "CollectionReport",
    "CollectionStats",
    "run_historical_collection",
]
