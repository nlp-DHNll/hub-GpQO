"""DeepSeek Search / Fetch 异步客户端。

请求格式**完全复用项目一已验证实现**（``ESG Monthly Report Agent``）：

Search（``agents/researcher.py``）::

    POST {DEEPSEEK_SEARCH_BASE_URL 推导出的 /v1/tools/search}
    Authorization: Bearer <DEEPSEEK_SEARCH_API_KEY>
    Content-Type: application/json
    {"query": "...", "count": 10, "need_content": false}
    -> {"results": [{"url", "title", "snippet", "summary", "content",
                     "site_name", "site_icon", "date", "authority", "rerank_score"}, ...]}

Fetch（``agents/reader.py``）::

    POST https://api.deepseek.com/v1/tools/fetch
    Authorization: Bearer <DEEPSEEK_SEARCH_API_KEY>
    Content-Type: application/json
    {"url": "https://..."}
    -> {"content": "...markdown...", "title": "..."}

重试策略同样沿用项目一：最多 2 次尝试，超时/网络异常/429/5xx 重试；
Fetch 额外对 408 重试；其余 4xx 不重试。

并发控制：所有 HTTP 请求共用一个 ``asyncio.Semaphore``，
上限来自 ``settings.search_concurrency``（默认 3）。

本模块不会在日志或异常信息中输出 API Key。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Literal, Sequence
from urllib.parse import urlparse, urlsplit, urlunsplit

import httpx
from pydantic import BaseModel, Field

from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

# DeepSeek API 约束（与项目一一致）
SEARCH_RESULT_COUNT: int = 10
MAX_QUERY_LENGTH: int = 128
MAX_URL_LENGTH: int = 8192

# 重试策略（与项目一一致）
MAX_ATTEMPTS: int = 2
RETRY_BACKOFF_SECONDS: float = 0.5
ERROR_BODY_PREVIEW: int = 300

ResultStatus = Literal["success", "empty", "error"]


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------


class DeepSeekError(RuntimeError):
    """DeepSeek 调用失败的基类。消息中不包含 API Key。"""

    def __init__(self, message: str, attempts: int = 0) -> None:
        super().__init__(message)
        self.attempts = attempts


class SearchError(DeepSeekError):
    """Search 调用失败。"""


class FetchError(DeepSeekError):
    """Fetch 调用失败。"""


# ---------------------------------------------------------------------------
# 结果模型
# ---------------------------------------------------------------------------


class SearchResultItem(BaseModel):
    """单条搜索结果，保留 API 原始字段与原始 JSON。"""

    title: str = ""
    url: str
    snippet: str = ""
    summary: str = ""
    content: str = ""
    site_name: str | None = None
    site_icon: str | None = None
    date: str | None = None
    authority: int | None = None
    rerank_score: float | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class SearchResult(BaseModel):
    """单条 Query 的搜索结果。"""

    query: str
    status: ResultStatus
    items: list[SearchResultItem] = Field(default_factory=list)
    error: str | None = None
    raw_response: dict[str, Any] | None = None
    attempts: int = 0


class FetchResult(BaseModel):
    """单个网页的抓取结果。"""

    url: str
    title: str = ""
    content: str = ""
    status: ResultStatus
    error: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
    attempts: int = 0


# ---------------------------------------------------------------------------
# URL 工具（与项目一一致）
# ---------------------------------------------------------------------------


def normalize_url(url: str) -> str:
    """去重用的 URL 规范化：忽略协议/域名大小写、片段和末尾斜杠。"""
    value = url.strip()
    parts = urlsplit(value)
    if not parts.scheme and not parts.netloc:
        return value.lower().rstrip("/")
    path = parts.path.rstrip("/") or "/"
    return urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), path, parts.query, "")
    )


def strip_url_fragment(url: str) -> str:
    """去掉 URL 片段（如搜索结果附带的 #1），便于 Fetch 抓取。"""
    parts = urlsplit(url.strip())
    if not parts.scheme and not parts.netloc:
        return url.strip()
    return urlunsplit((parts.scheme, parts.netloc, parts.path, parts.query, ""))


def is_fetchable_url(url: str) -> bool:
    """Fetch API 只接受带 host 的 http/https URL。"""
    if not url or len(url) > MAX_URL_LENGTH:
        return False
    parsed = urlparse(url)
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname)


def _as_text(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _as_optional_text(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _as_optional_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _as_optional_float(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _extract_item(raw: Any) -> SearchResultItem | None:
    """从单条原始结果提取字段；没有可用 URL 的结果直接丢弃。"""
    if not isinstance(raw, dict):
        return None
    url = raw.get("url")
    if not isinstance(url, str) or not url.strip():
        return None
    return SearchResultItem(
        title=_as_text(raw.get("title")),
        url=strip_url_fragment(url),
        snippet=_as_text(raw.get("snippet")),
        summary=_as_text(raw.get("summary")),
        content=_as_text(raw.get("content")),
        site_name=_as_optional_text(raw.get("site_name")),
        site_icon=_as_optional_text(raw.get("site_icon")),
        date=_as_optional_text(raw.get("date")),
        authority=_as_optional_int(raw.get("authority")),
        rerank_score=_as_optional_float(raw.get("rerank_score")),
        raw=dict(raw),
    )


# ---------------------------------------------------------------------------
# 客户端
# ---------------------------------------------------------------------------


class DeepSeekClient:
    """统一的 DeepSeek Search / Fetch 客户端。

    :param settings: 不传则使用 ``get_settings()``
    :param client: 可注入 ``httpx.AsyncClient``（测试用 MockTransport）；
        未注入时由本类创建并在 ``aclose()`` 中关闭
    :param max_attempts: 单请求最大尝试次数（含首次），默认 2
    :param retry_backoff_seconds: 重试退避基数（秒），默认 0.5
    """

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        max_attempts: int = MAX_ATTEMPTS,
        retry_backoff_seconds: float = RETRY_BACKOFF_SECONDS,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts 必须至少为 1")
        self._settings = settings or get_settings()
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient()
        self._max_attempts = max_attempts
        self._retry_backoff_seconds = max(0.0, retry_backoff_seconds)
        self._timeout = self._settings.request_timeout_seconds
        self._concurrency = max(1, self._settings.search_concurrency)
        # 所有请求共用同一个信号量：并发上限来自配置，默认 3
        self._semaphore = asyncio.Semaphore(self._concurrency)

    # --- 生命周期 ------------------------------------------------------

    @property
    def concurrency(self) -> int:
        return self._concurrency

    async def aclose(self) -> None:
        """关闭自建的 httpx 客户端；注入的客户端由调用方负责。"""
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "DeepSeekClient":
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    # --- 配置校验 ------------------------------------------------------

    def _require_search_settings(self) -> None:
        missing = [
            name
            for name, value in (
                ("DEEPSEEK_SEARCH_API_KEY", self._settings.deepseek_search_api_key),
                ("DEEPSEEK_SEARCH_BASE_URL", self._settings.deepseek_search_base_url),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "DeepSeek Search 缺少必要配置："
                + "、".join(missing)
                + "。请填写 DeepSeek 官方 Search API 的 Key 与地址（不要使用 "
                "SILICONFLOW_API_KEY 代替）。"
            )

    def _require_fetch_settings(self) -> None:
        if not self._settings.deepseek_search_api_key:
            raise ConfigurationError(
                "DeepSeek Fetch 缺少必要配置：DEEPSEEK_SEARCH_API_KEY。"
                "Fetch 与 Search 共用 DeepSeek 官方 Key。"
            )

    def _api_key(self) -> str:
        """取 Key 明文，仅用于构造请求头；绝不写入日志或异常信息。"""
        secret = self._settings.deepseek_search_api_key
        if secret is None:
            raise ConfigurationError("DEEPSEEK_SEARCH_API_KEY 未配置")
        return secret.get_secret_value()

    # --- Search --------------------------------------------------------

    async def search(
        self,
        query: str,
        *,
        count: int = SEARCH_RESULT_COUNT,
        need_content: bool = False,
        freshness: str | None = None,
    ) -> SearchResult:
        """执行一次 Search。

        :param freshness: 可选的时效过滤（如 ``"d1"``）。
            项目一已验证的请求体**不包含**该字段，因此默认 ``None`` 时不发送；
            只有在确认接口支持后再显式传入，避免擅自增加未验证参数。
        :raises SearchError: 请求失败 / 响应格式异常
        :raises ConfigurationError: 缺少必要配置
        """
        self._require_search_settings()

        text = query.strip()
        if not 1 <= len(text) <= MAX_QUERY_LENGTH:
            raise SearchError(
                f"search query 长度必须在 1～{MAX_QUERY_LENGTH} 字符之间"
            )
        if not 1 <= count <= 50:
            raise ValueError("count 必须在 1～50 之间")

        payload: dict[str, Any] = {
            "query": text,
            "count": count,
            "need_content": need_content,
        }
        if freshness is not None:
            payload["freshness"] = freshness

        endpoint = self._settings.search_endpoint
        response, attempts = await self._post(
            endpoint,
            payload,
            error_cls=SearchError,
            label=f"Search({text!r})",
            retry_408=False,
        )
        return self._parse_search_response(text, response, attempts)

    async def search_many(
        self,
        queries: Sequence[str],
        *,
        count: int = SEARCH_RESULT_COUNT,
        need_content: bool = False,
        freshness: str | None = None,
    ) -> list[SearchResult]:
        """并发执行多条 Query；单条失败不影响其他 Query。

        并发上限由客户端构造时读取的 ``SEARCH_CONCURRENCY`` 决定。
        """

        async def run_one(query: str) -> SearchResult:
            try:
                return await self.search(
                    query,
                    count=count,
                    need_content=need_content,
                    freshness=freshness,
                )
            except SearchError as exc:
                logger.warning("Query %r 搜索失败：%s", query, exc)
                return SearchResult(
                    query=query,
                    status="error",
                    error=str(exc),
                    attempts=exc.attempts,
                )
            except Exception as exc:  # 保证单条异常不中断整批
                logger.exception("Query %r 出现未预期异常", query)
                return SearchResult(
                    query=query,
                    status="error",
                    error=f"未预期错误：{exc}",
                )

        outcomes = await asyncio.gather(*(run_one(query) for query in queries))
        success = sum(1 for item in outcomes if item.status == "success")
        empty = sum(1 for item in outcomes if item.status == "empty")
        failed = sum(1 for item in outcomes if item.status == "error")
        logger.info(
            "Search 批量完成：成功 %d，空结果 %d，失败 %d（并发上限 %d）",
            success,
            empty,
            failed,
            self._concurrency,
        )
        return list(outcomes)

    def _parse_search_response(
        self,
        query: str,
        response: httpx.Response,
        attempts: int,
    ) -> SearchResult:
        try:
            payload = response.json()
        except ValueError as exc:
            raise SearchError(f"搜索响应不是合法 JSON：{exc}", attempts) from exc
        if not isinstance(payload, dict):
            raise SearchError("搜索响应 JSON 顶层不是对象", attempts)

        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            raise SearchError("搜索响应缺少 results 数组", attempts)

        items: list[SearchResultItem] = []
        seen_urls: set[str] = set()
        for raw in raw_results:
            item = _extract_item(raw)
            if item is None:
                continue
            key = normalize_url(item.url)
            if key in seen_urls:
                continue
            seen_urls.add(key)
            items.append(item)

        return SearchResult(
            query=query,
            status="success" if items else "empty",
            items=items,
            raw_response=payload,
            attempts=attempts,
        )

    # --- Fetch ---------------------------------------------------------

    async def fetch(self, url: str) -> FetchResult:
        """抓取单个网页并返回正文（接口提供 Markdown 时即 Markdown）。

        :raises FetchError: URL 非法 / 请求失败 / 响应格式异常
        :raises ConfigurationError: 缺少必要配置
        """
        self._require_fetch_settings()

        target = url.strip()
        if not is_fetchable_url(target):
            raise FetchError(
                "URL 不合法：必须是带 host 的 http/https 地址，且不超过 "
                f"{MAX_URL_LENGTH} 字符"
            )

        response, attempts = await self._post(
            self._settings.fetch_endpoint,
            {"url": target},
            error_cls=FetchError,
            label=f"Fetch({target})",
            retry_408=True,
        )
        return self._parse_fetch_response(target, response, attempts)

    async def fetch_many(self, urls: Sequence[str]) -> list[FetchResult]:
        """并发抓取多个网页；单个失败不影响其他网页。"""

        async def run_one(url: str) -> FetchResult:
            try:
                return await self.fetch(url)
            except FetchError as exc:
                logger.warning("网页 %s 抓取失败：%s", url, exc)
                return FetchResult(
                    url=url,
                    status="error",
                    error=str(exc),
                    attempts=exc.attempts,
                )
            except Exception as exc:  # 保证单页异常不中断整批
                logger.exception("网页 %s 出现未预期异常", url)
                return FetchResult(
                    url=url,
                    status="error",
                    error=f"未预期错误：{exc}",
                )

        outcomes = await asyncio.gather(*(run_one(url) for url in urls))
        success = sum(1 for item in outcomes if item.status == "success")
        empty = sum(1 for item in outcomes if item.status == "empty")
        failed = sum(1 for item in outcomes if item.status == "error")
        logger.info(
            "Fetch 批量完成：成功 %d，空正文 %d，失败 %d（并发上限 %d）",
            success,
            empty,
            failed,
            self._concurrency,
        )
        return list(outcomes)

    def _parse_fetch_response(
        self,
        url: str,
        response: httpx.Response,
        attempts: int,
    ) -> FetchResult:
        try:
            payload = response.json()
        except ValueError as exc:
            raise FetchError(f"Fetch 响应不是合法 JSON：{exc}", attempts) from exc
        if not isinstance(payload, dict):
            raise FetchError("Fetch 响应 JSON 顶层不是对象", attempts)

        content = payload.get("content")
        if not isinstance(content, str):
            raise FetchError("Fetch 响应缺少字符串类型的 content 字段", attempts)

        title = payload.get("title")
        if not isinstance(title, str):
            title = ""

        status: ResultStatus = "success" if content.strip() else "empty"
        return FetchResult(
            url=url,
            title=title,
            content=content,
            status=status,
            error=None if status == "success" else "正文为空",
            raw=payload,
            attempts=attempts,
        )

    # --- HTTP 基础设施 -------------------------------------------------

    async def _post(
        self,
        endpoint: str,
        payload: dict[str, Any],
        *,
        error_cls: type[DeepSeekError],
        label: str,
        retry_408: bool,
    ) -> tuple[httpx.Response, int]:
        """带重试的 POST，返回 (响应, 实际尝试次数)。

        ``error_cls`` 决定失败时抛 ``SearchError`` 还是 ``FetchError``；
        错误消息只包含状态码与响应片段，绝不包含 Authorization 头。
        """
        headers = {
            "Authorization": f"Bearer {self._api_key()}",
            "Content-Type": "application/json",
        }
        last_error = "未知错误"

        for attempt in range(1, self._max_attempts + 1):
            try:
                async with self._semaphore:
                    response = await self._client.post(
                        endpoint,
                        headers=headers,
                        json=payload,
                        timeout=self._timeout,
                    )
            except httpx.TimeoutException:
                last_error = f"{label} 请求超时（{self._timeout:g} 秒）"
                logger.warning("%s 第 %d/%d 次请求超时", label, attempt, self._max_attempts)
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                raise error_cls(last_error, attempt) from None
            except httpx.HTTPError as exc:
                last_error = f"{label} 网络请求异常：{type(exc).__name__}: {exc}"
                logger.warning(
                    "%s 第 %d/%d 次网络异常：%s",
                    label,
                    attempt,
                    self._max_attempts,
                    type(exc).__name__,
                )
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                raise error_cls(last_error, attempt) from None

            if 200 <= response.status_code < 300:
                return response, attempt

            body_preview = response.text[:ERROR_BODY_PREVIEW]
            last_error = f"{label} 返回 HTTP {response.status_code}：{body_preview}"
            retryable = (
                response.status_code == 429
                or 500 <= response.status_code < 600
                or (retry_408 and response.status_code == 408)
            )
            if retryable and attempt < self._max_attempts:
                logger.warning(
                    "%s 第 %d/%d 次返回 HTTP %d，准备重试",
                    label,
                    attempt,
                    self._max_attempts,
                    response.status_code,
                )
                await asyncio.sleep(self._retry_backoff_seconds * attempt)
                continue
            raise error_cls(last_error, attempt)

        raise error_cls(last_error, self._max_attempts)


__all__ = [
    "MAX_ATTEMPTS",
    "MAX_QUERY_LENGTH",
    "SEARCH_RESULT_COUNT",
    "DeepSeekClient",
    "DeepSeekError",
    "FetchError",
    "FetchResult",
    "SearchError",
    "SearchResult",
    "SearchResultItem",
    "is_fetchable_url",
    "normalize_url",
    "strip_url_fragment",
]
