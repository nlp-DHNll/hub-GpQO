"""历史数据统计与 Markdown 分析报告。

核心原则（CLAUDE.md 第五节、任务书第三章）：

- **Python 负责全部统计计算**，金额用 ``Decimal`` 累加，占比用 Python 计算；
- AI 只负责在**已算好的统计结果**基础上撰写分析文字，不得修改数字；
- 低质量记录只在统计时排除，**不删除、不修改**数据库原始记录；
- 模型调用失败时，仍生成包含全部统计表格与数字的基础 Markdown 报告。

统计口径（顺序过滤，每步只统计"本步新增排除"，保证可解释且不重复计数）：

    原始记录
      → [1] source_url 无效/缺失       -> excluded_invalid_url
      → [2] announcement_type == 其他  -> excluded_other_type
      → [3] confidence 缺失或 < 0.3    -> excluded_low_confidence
      = 正式统计纳入记录

    原始总数 == 纳入数 + 三类排除数之和
"""

from __future__ import annotations

import logging
import re
import statistics
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlparse

from config.settings import OUTPUT_DIR, ConfigurationError, Settings, get_settings
from db.repository import TenderRepository
from models.tender import AnnouncementType, Industry, TenderRecord

logger = logging.getLogger(__name__)

MIN_CONFIDENCE = 0.3
MIN_BID_SAMPLE_FOR_INSIGHTS = 3
REPORT_FILENAME = "historical_analysis_report.md"
ANALYTICS_PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "analytics_report_prompt.txt"

# 金额以「元」为单位
TEN_THOUSAND = Decimal("10000")


# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------


@dataclass
class AmountBucket:
    """中标金额区间。``lower`` 含、``upper`` 不含；``None`` 表示无界。

    非冻结：统计时按区间回填 ``count``（模块级 ``AMOUNT_BUCKETS`` 只作为模板，
    每次统计都会深拷贝出新实例，模板本身不会被改写）。
    """

    label: str
    lower: Decimal
    upper: Decimal | None
    count: int = 0


AMOUNT_BUCKETS: tuple[AmountBucket, ...] = (
    AmountBucket("100万元以下", Decimal("0"), Decimal("100")),
    AmountBucket("100万–500万元", Decimal("100"), Decimal("500")),
    AmountBucket("500万–1000万元", Decimal("500"), Decimal("1000")),
    AmountBucket("1000万–5000万元", Decimal("1000"), Decimal("5000")),
    AmountBucket("5000万–1亿元", Decimal("5000"), Decimal("10000")),
    AmountBucket("1亿元及以上", Decimal("10000"), None),
)


@dataclass
class FilterStats:
    """数据质量与过滤统计。"""

    raw_count: int = 0
    included_count: int = 0
    excluded_invalid_url: int = 0
    excluded_other_type: int = 0
    excluded_low_confidence: int = 0

    @property
    def excluded_total(self) -> int:
        return (
            self.excluded_invalid_url
            + self.excluded_other_type
            + self.excluded_low_confidence
        )

    def as_dict(self) -> dict[str, int]:
        data = asdict(self)
        data["excluded_total"] = self.excluded_total
        return data

    def is_consistent(self) -> bool:
        """原始数 == 纳入 + 排除（顺序过滤下必须成立）。"""
        return self.raw_count == self.included_count + self.excluded_total


@dataclass(frozen=True)
class DistributionItem:
    label: str
    count: int
    ratio: Decimal  # 百分比，保留两位小数

    def as_dict(self) -> dict[str, Any]:
        return {"label": self.label, "count": self.count, "ratio": format(self.ratio, "f")}


@dataclass
class BidAmountStats:
    """中标金额统计（只基于 ``bid_amount``）。"""

    sample_count: int = 0
    undisclosed_count: int = 0
    invalid_count: int = 0
    total: Decimal | None = None
    average: Decimal | None = None
    median: Decimal | None = None
    max_amount: Decimal | None = None
    min_amount: Decimal | None = None
    buckets: list[AmountBucket] = field(
        default_factory=lambda: [AmountBucket(b.label, b.lower, b.upper) for b in AMOUNT_BUCKETS]
    )

    @property
    def sample_sufficient(self) -> bool:
        return self.sample_count >= MIN_BID_SAMPLE_FOR_INSIGHTS

    def as_dict(self) -> dict[str, Any]:
        return {
            "sample_count": self.sample_count,
            "undisclosed_count": self.undisclosed_count,
            "invalid_count": self.invalid_count,
            "sample_sufficient": self.sample_sufficient,
            "total": _dec_str(self.total),
            "total_wan": _dec_str(_to_wan(self.total)),
            "average": _dec_str(self.average),
            "average_wan": _dec_str(_to_wan(self.average)),
            "median": _dec_str(self.median),
            "median_wan": _dec_str(_to_wan(self.median)),
            "max_amount": _dec_str(self.max_amount),
            "max_amount_wan": _dec_str(_to_wan(self.max_amount)),
            "min_amount": _dec_str(self.min_amount),
            "min_amount_wan": _dec_str(_to_wan(self.min_amount)),
            "buckets": [
                {
                    "label": bucket.label,
                    "count": bucket.count,
                    "range_symbol": f"[{bucket.lower}, {bucket.upper if bucket.upper is not None else '∞'}) 万元",
                }
                for bucket in self.buckets
            ],
        }


@dataclass
class DisclosedAmountStats:
    """四类金额各自的非空披露数量（严格独立）。"""

    budget_amount: int = 0
    ceiling_price: int = 0
    bid_amount: int = 0
    contract_amount: int = 0

    def as_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass
class AnalyticsResult:
    """确定性统计结果。"""

    generated_at: datetime
    filters: FilterStats
    basic: dict[str, Any]
    industry_distribution: list[DistributionItem]
    announcement_distribution: list[DistributionItem]
    bid_amount: BidAmountStats
    disclosed: DisclosedAmountStats
    region_covered_count: int
    earliest_publish_date: date | None
    latest_publish_date: date | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at.isoformat(),
            "filters": self.filters.as_dict(),
            "basic": self.basic,
            "industry_distribution": [item.as_dict() for item in self.industry_distribution],
            "announcement_distribution": [
                item.as_dict() for item in self.announcement_distribution
            ],
            "bid_amount": self.bid_amount.as_dict(),
            "disclosed_amounts": self.disclosed.as_dict(),
            "region_covered_count": self.region_covered_count,
            "earliest_publish_date": (
                self.earliest_publish_date.isoformat() if self.earliest_publish_date else None
            ),
            "latest_publish_date": (
                self.latest_publish_date.isoformat() if self.latest_publish_date else None
            ),
        }


@dataclass
class ReportOutcome:
    """报告生成结果。"""

    result: AnalyticsResult
    report_path: Path
    markdown: str
    ai_used: bool
    ai_error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "report_path": str(self.report_path),
            "ai_used": self.ai_used,
            "ai_error": self.ai_error,
            "analysis": self.result.as_dict(),
        }


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------


def _dec_str(value: Decimal | None) -> str | None:
    return format(value, "f") if value is not None else None


def _to_wan(value: Decimal | None) -> Decimal | None:
    if value is None:
        return None
    return (value / TEN_THOUSAND).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _ratio(count: int, total: int) -> Decimal:
    """百分比，保留两位小数，使用 ROUND_HALF_UP。"""
    if total <= 0:
        return Decimal("0.00")
    return (Decimal(count) * Decimal(100) / Decimal(total)).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )


def is_valid_source_url(url: Any) -> bool:
    """来源 URL 有效：非空、http/https、带 host。"""
    if url is None:
        return False
    text = str(url).strip()
    if not text:
        return False
    parts = urlparse(text)
    return parts.scheme.lower() in {"http", "https"} and bool(parts.hostname)


# ---------------------------------------------------------------------------
# 统计
# ---------------------------------------------------------------------------


def filter_records(records: Sequence[TenderRecord]) -> tuple[list[TenderRecord], FilterStats]:
    """顺序过滤并给出可解释的过滤统计。"""
    stats = FilterStats(raw_count=len(records))
    after_url: list[TenderRecord] = []
    for record in records:
        if is_valid_source_url(record.source_url):
            after_url.append(record)
        else:
            stats.excluded_invalid_url += 1

    after_type: list[TenderRecord] = []
    for record in after_url:
        if record.announcement_type is AnnouncementType.OTHER:
            stats.excluded_other_type += 1
        else:
            after_type.append(record)

    included: list[TenderRecord] = []
    for record in after_type:
        if record.confidence is None or record.confidence < MIN_CONFIDENCE:
            stats.excluded_low_confidence += 1
        else:
            included.append(record)

    stats.included_count = len(included)
    logger.info(
        "统计过滤：原始 %d，纳入 %d，URL 无效 %d，其他类型 %d，低置信度 %d",
        stats.raw_count,
        stats.included_count,
        stats.excluded_invalid_url,
        stats.excluded_other_type,
        stats.excluded_low_confidence,
    )
    return included, stats


def compute_bid_amount_stats(records: Sequence[TenderRecord]) -> BidAmountStats:
    """只使用 ``bid_amount`` 计算中标金额统计。

    严禁使用 budget / ceiling / contract 顶替；未披露记录单独计数。

    - 非空且 >= 0 的 ``bid_amount`` 进入样本；
    - 负数 ``bid_amount`` 视为异常数据，既不计入样本也不计入"未披露"，
      数量体现在 ``invalid_count`` 中（防止悄悄混进统计）。
    """
    stats = BidAmountStats()
    amounts: list[Decimal] = []
    invalid = 0
    for record in records:
        amount = record.bid_amount
        if amount is None:
            stats.undisclosed_count += 1
            continue
        if amount < 0:
            invalid += 1
            continue
        amounts.append(amount)

    stats.sample_count = len(amounts)
    stats.invalid_count = invalid
    if not amounts:
        return stats

    stats.total = sum(amounts, start=Decimal("0"))
    stats.average = (stats.total / Decimal(len(amounts))).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    stats.median = Decimal(str(statistics.median(amounts))).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    stats.max_amount = max(amounts)
    stats.min_amount = min(amounts)

    wan_values = [amount / TEN_THOUSAND for amount in amounts]
    for bucket in stats.buckets:
        bucket.count = sum(
            1
            for value in wan_values
            if value >= bucket.lower and (bucket.upper is None or value < bucket.upper)
        )
    return stats


def compute_distribution(
    records: Sequence[TenderRecord],
) -> tuple[list[DistributionItem], list[DistributionItem]]:
    """行业分布与公告类型分布（数量 + 占比，占比保留两位小数）。"""
    total = len(records)

    announcement_counts = {member: 0 for member in AnnouncementType}
    industry_counts = {member: 0 for member in Industry}
    for record in records:
        announcement_counts[record.announcement_type] += 1
        industry_counts[record.industry] += 1

    announcement_items = [
        DistributionItem(member.value, count, _ratio(count, total))
        for member, count in announcement_counts.items()
    ]
    industry_items = [
        DistributionItem(member.value, count, _ratio(count, total))
        for member, count in industry_counts.items()
    ]
    return announcement_items, industry_items


def compute_disclosed_counts(records: Sequence[TenderRecord]) -> DisclosedAmountStats:
    """四类金额各自的非空数量，互不替代。"""
    return DisclosedAmountStats(
        budget_amount=sum(1 for record in records if record.budget_amount is not None),
        ceiling_price=sum(1 for record in records if record.ceiling_price is not None),
        bid_amount=sum(1 for record in records if record.bid_amount is not None),
        contract_amount=sum(1 for record in records if record.contract_amount is not None),
    )


def analyze_records(
    records: Sequence[TenderRecord], *, generated_at: datetime | None = None
) -> AnalyticsResult:
    """对给定记录执行全部确定性统计。"""
    included, filters = filter_records(records)
    announcement_distribution, industry_distribution = compute_distribution(included)
    bid_stats = compute_bid_amount_stats(included)
    disclosed = compute_disclosed_counts(included)

    publish_dates = [item.publish_date for item in included if item.publish_date is not None]
    region_covered = sum(1 for item in included if item.region and item.region.strip())
    announcement_counts = {
        item.label: item.count for item in announcement_distribution
    }

    basic: dict[str, Any] = {
        "included_count": filters.included_count,
        "tender_count": announcement_counts.get(AnnouncementType.TENDER.value, 0),
        "award_count": announcement_counts.get(AnnouncementType.AWARD.value, 0),
        "procurement_count": announcement_counts.get(
            AnnouncementType.PROCUREMENT.value, 0
        ),
        "correction_count": announcement_counts.get(
            AnnouncementType.CORRECTION.value, 0
        ),
        "region_covered_count": region_covered,
        "earliest_publish_date": min(publish_dates).isoformat() if publish_dates else None,
        "latest_publish_date": max(publish_dates).isoformat() if publish_dates else None,
    }

    if generated_at is None:
        generated_at = datetime.now(get_settings().timezone)

    return AnalyticsResult(
        generated_at=generated_at,
        filters=filters,
        basic=basic,
        industry_distribution=industry_distribution,
        announcement_distribution=announcement_distribution,
        bid_amount=bid_stats,
        disclosed=disclosed,
        region_covered_count=region_covered,
        earliest_publish_date=min(publish_dates) if publish_dates else None,
        latest_publish_date=max(publish_dates) if publish_dates else None,
    )


# ---------------------------------------------------------------------------
# Markdown 渲染（确定性部分）
# ---------------------------------------------------------------------------


def render_base_markdown(result: AnalyticsResult) -> str:
    """无 AI 参与的基础报告：所有数字都来自 ``AnalyticsResult``。"""
    f = result.filters
    b = result.basic
    bid = result.bid_amount
    lines: list[str] = []

    lines.append("# ESG 招投标历史数据分析报告")
    lines.append("")
    lines.append(f"- 生成日期：{result.generated_at.strftime('%Y-%m-%d %H:%M:%S %Z')}")
    lines.append("- 数据来源：SQLite 数据库 `data/esg_tender.db` 中的历史公告记录")
    lines.append("- 搜索范围：全国范围，运行日期往前推两年")
    lines.append("")
    lines.append("> **本报告基于公开网络可检索信息，非全量统计。**")
    lines.append(
        "> 数据可能存在地区、来源渠道和字段披露覆盖不足的问题；"
        "金额未披露的记录不参与金额统计，也不做任何推算。"
    )
    lines.append("")

    # --- 1. 数据质量 ---------------------------------------------------
    lines.append("## 一、数据质量与过滤情况")
    lines.append("")
    lines.append("统计采用**顺序过滤**：先排除来源 URL 无效记录，再排除公告类型为「其他」的记录，"
                 "最后排除置信度缺失或低于 "
                 f"{MIN_CONFIDENCE} 的记录。每条记录只会被计入一类排除，各项之和等于原始记录数。")
    lines.append("")
    lines.append("| 项目 | 数量 |")
    lines.append("|---|---:|")
    lines.append(f"| 数据库原始记录总数 | {f.raw_count} |")
    lines.append(f"| 因来源 URL 无效或缺失排除 | {f.excluded_invalid_url} |")
    lines.append(f"| 因公告类型为「其他」排除 | {f.excluded_other_type} |")
    lines.append(f"| 因置信度缺失或低于 {MIN_CONFIDENCE} 排除 | {f.excluded_low_confidence} |")
    lines.append(f"| 排除合计 | {f.excluded_total} |")
    lines.append(f"| **正式统计纳入记录数** | **{f.included_count}** |")
    lines.append("")

    if f.included_count == 0:
        lines.append("正式统计纳入记录数为 0，本章节之后暂无可用数据。")
        lines.append("")
        return "\n".join(lines)

    # --- 2. 基础统计 ---------------------------------------------------
    lines.append("## 二、基础统计")
    lines.append("")
    lines.append("| 项目 | 数值 |")
    lines.append("|---|---:|")
    lines.append(f"| 正式统计记录总数 | {b['included_count']} |")
    lines.append(f"| 招标公告 | {b['tender_count']} |")
    lines.append(f"| 中标公告 | {b['award_count']} |")
    lines.append(f"| 采购公告 | {b['procurement_count']} |")
    lines.append(f"| 更正公告 | {b['correction_count']} |")
    lines.append(
        f"| 发布日期覆盖 | {b['earliest_publish_date'] or '暂无数据'} ~ "
        f"{b['latest_publish_date'] or '暂无数据'} |"
    )
    lines.append(f"| 地区信息覆盖数量 | {b['region_covered_count']} |")
    lines.append("")

    # --- 3. 公告类型 ---------------------------------------------------
    lines.append("## 三、公告类型分布")
    lines.append("")
    lines.extend(_render_distribution_table(result.announcement_distribution))
    lines.append("")

    # --- 4. 行业分布 ---------------------------------------------------
    lines.append("## 四、ESG 细分行业分布")
    lines.append("")
    lines.extend(_render_distribution_table(result.industry_distribution))
    lines.append("")

    # --- 5. 中标金额 ---------------------------------------------------
    lines.append("## 五、中标金额统计")
    lines.append("")
    lines.append(
        "**口径说明**：本章节只统计 `bid_amount`（中标金额）。"
        "预算金额、最高限价、合同金额不参与任何中标金额计算，也不用于填补缺失。"
    )
    lines.append("")
    lines.append(f"- 有效中标金额样本：**{bid.sample_count}** 条")
    lines.append(f"- 中标金额未披露：{bid.undisclosed_count} 条")
    if bid.invalid_count:
        lines.append(f"- 中标金额为负、被视为异常并排除：{bid.invalid_count} 条")
    lines.append("")
    if bid.sample_count == 0:
        lines.append("暂无有效中标金额数据。")
        lines.append("")
    else:
        lines.append("| 指标 | 金额（元） | 金额（万元） |")
        lines.append("|---|---:|---:|")
        lines.append(f"| 总额 | {_dec_str(bid.total)} | {_dec_str(_to_wan(bid.total))} |")
        lines.append(f"| 平均 | {_dec_str(bid.average)} | {_dec_str(_to_wan(bid.average))} |")
        lines.append(f"| 中位数 | {_dec_str(bid.median)} | {_dec_str(_to_wan(bid.median))} |")
        lines.append(f"| 最大值 | {_dec_str(bid.max_amount)} | {_dec_str(_to_wan(bid.max_amount))} |")
        lines.append(f"| 最小值 | {_dec_str(bid.min_amount)} | {_dec_str(_to_wan(bid.min_amount))} |")
        lines.append("")
        lines.append("**金额区间分布**")
        lines.append("")
        lines.append("| 区间 | 记录数 |")
        lines.append("|---|---:|")
        for bucket in bid.buckets:
            lines.append(f"| {bucket.label} | {bucket.count} |")
        lines.append("")
        if not bid.sample_sufficient:
            lines.append(
                f"> 有效中标金额样本仅 {bid.sample_count} 条（少于 "
                f"{MIN_BID_SAMPLE_FOR_INSIGHTS} 条），以上仅为客观罗列，"
                "**不做行业金额规律、市场趋势或金额分布规律推断**。"
            )
            lines.append("")

    # --- 6. 金额披露 ---------------------------------------------------
    lines.append("## 六、金额字段披露情况")
    lines.append("")
    lines.append("四类金额严格独立，互不替代。")
    lines.append("")
    lines.append("| 金额字段 | 非空记录数 | 含义 |")
    lines.append("|---|---:|---|")
    lines.append(f"| budget_amount | {result.disclosed.budget_amount} | 预算金额 |")
    lines.append(f"| ceiling_price | {result.disclosed.ceiling_price} | 最高限价 |")
    lines.append(f"| bid_amount | {result.disclosed.bid_amount} | 中标金额 |")
    lines.append(f"| contract_amount | {result.disclosed.contract_amount} | 合同金额 |")
    lines.append("")

    # --- 7. AI 分析占位 -------------------------------------------------
    lines.append("## 七、数据局限性与结论")
    lines.append("")
    lines.append(_limitations_text(result))
    lines.append("")
    return "\n".join(lines)


def _render_distribution_table(items: list[DistributionItem]) -> list[str]:
    lines = ["| 分类 | 数量 | 占比 |", "|---|---:|---:|"]
    for item in items:
        lines.append(f"| {item.label} | {item.count} | {format(item.ratio, 'f')}% |")
    return lines


def _limitations_text(result: AnalyticsResult) -> str:
    f = result.filters
    bid = result.bid_amount
    parts = [
        "- 本报告基于公开网络可检索信息，非全量统计；搜索引擎结果受索引覆盖、排序与 Query "
        "设计影响，可能存在遗漏。",
        f"- 原始记录 {f.raw_count} 条中有 {f.excluded_total} 条因数据质量问题被排除在统计口径之外"
        "（记录本身仍保留在数据库中）。",
        f"- 地区字段覆盖 {result.region_covered_count}/{f.included_count} 条，"
        "地区维度统计的可靠性有限。",
        f"- 中标金额仅 {bid.sample_count} 条有效披露，"
        f"{bid.undisclosed_count} 条未披露；未披露金额不做任何推算。",
    ]
    if not bid.sample_sufficient:
        parts.append(
            f"- 有效金额样本少于 {MIN_BID_SAMPLE_FOR_INSIGHTS} 条，"
            "因此不对金额分布、行业金额水平或市场趋势作任何推断。"
        )
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# AI 文字（可选）
# ---------------------------------------------------------------------------


class AIAnalysisError(RuntimeError):
    """AI 分析文字生成失败（服务层会降级为基础报告）。"""


async def _render_ai_section(result: AnalyticsResult) -> str:
    """调用 SiliconFlow 生成分析文字；失败时抛出异常，由调用方降级。"""
    import json

    from openai import AsyncOpenAI

    settings = get_settings()
    missing = [
        name
        for name, value in (
            ("SILICONFLOW_API_KEY", settings.siliconflow_api_key),
            ("SILICONFLOW_BASE_URL", settings.siliconflow_base_url),
            ("DEEPSEEK_MODEL", settings.deepseek_model),
        )
        if not value
    ]
    if missing:
        raise ConfigurationError("分析文字生成缺少必要配置：" + "、".join(missing))

    if not ANALYTICS_PROMPT_PATH.exists():
        raise ConfigurationError(f"缺少分析提示词文件：{ANALYTICS_PROMPT_PATH}")
    prompt = ANALYTICS_PROMPT_PATH.read_text(encoding="utf-8").strip()
    if not prompt:
        raise ConfigurationError(f"分析提示词文件为空：{ANALYTICS_PROMPT_PATH}")

    stats_json = json.dumps(result.as_dict(), ensure_ascii=False, indent=2)
    assert settings.siliconflow_api_key is not None  # 已校验
    client = AsyncOpenAI(
        api_key=settings.siliconflow_api_key.get_secret_value(),
        base_url=str(settings.siliconflow_base_url),
    )
    try:
        response = await client.chat.completions.create(
            model=settings.deepseek_model,
            messages=[
                {"role": "system", "content": prompt},
                {
                    "role": "user",
                    "content": (
                        "以下是 Python 计算好的确定性统计结果（JSON）。"
                        "请严格基于这些数字撰写分析，不得修改或补充数字。\n\n"
                        f"<statistics>\n{stats_json}\n</statistics>"
                    ),
                },
            ],
            temperature=0.0,
            max_tokens=1_500,
            timeout=settings.request_timeout_seconds,
        )
    except Exception as exc:
        raise AIAnalysisError(f"分析文字生成失败（{type(exc).__name__}）") from exc

    if not getattr(response, "choices", None):
        raise AIAnalysisError("分析文字生成失败：模型未返回 choices")
    text = (response.choices[0].message.content or "").strip()
    if not text:
        raise AIAnalysisError("分析文字生成失败：模型返回为空")
    return text


_HEADING_PATTERN = re.compile(r"^(#{1,6})[ \t]+", re.MULTILINE)


def _normalize_ai_headings(text: str) -> str:
    """把模型输出中的标题降级为报告内的子标题（最多 ######）。

    模型常自带 "# 标题 / ## 一、…" 结构，若原样嵌入会与报告主章节冲突，
    因此统一降 2 级：主章节「##」→ 分析「###」→ 模型小节「####」。
    """

    def demote(match: re.Match[str]) -> str:
        level = min(len(match.group(1)) + 2, 6)
        return "#" * level + " "

    return _HEADING_PATTERN.sub(demote, text)


def _inject_ai_section(markdown: str, ai_text: str) -> str:
    """把 AI 分析插入「数据局限性与结论」之前。"""
    body = _normalize_ai_headings(ai_text.strip())
    section = f"### 分析（由模型基于上述统计生成）\n\n{body}\n"
    marker = "## 七、数据局限性与结论"
    if marker in markdown:
        return markdown.replace(marker, section + "\n" + marker, 1)
    return markdown + "\n" + section


async def analyze_historical_data(
    *,
    repository: TenderRepository | None = None,
    settings: Settings | None = None,
) -> AnalyticsResult:
    """读取数据库 → 过滤 → 确定性统计。"""
    repository = repository or TenderRepository()
    records = repository.list_records(limit=1_000_000, offset=0)
    generated_at = datetime.now((settings or get_settings()).timezone)
    result = analyze_records(records, generated_at=generated_at)
    if not result.filters.is_consistent():
        logger.error(
            "过滤统计不自洽：原始 %d vs 纳入 %d + 排除 %d",
            result.filters.raw_count,
            result.filters.included_count,
            result.filters.excluded_total,
        )
    logger.info("统计完成：原始 %d 条，纳入 %d 条",
                result.filters.raw_count, result.filters.included_count)
    return result


async def generate_historical_analysis_report(
    *,
    repository: TenderRepository | None = None,
    use_ai: bool = True,
    output_path: Path | None = None,
    settings: Settings | None = None,
    ai_renderer: Any = None,
) -> ReportOutcome:
    """完整入口：统计 → 生成 Markdown → 保存 → 返回结果与路径。

    :param use_ai: 是否调用模型生成分析文字
    :param ai_renderer: 可注入的异步渲染函数（测试用），
        默认 ``_render_ai_section``；失败时自动降级为基础报告
    """
    result = await analyze_historical_data(repository=repository, settings=settings)
    markdown = render_base_markdown(result)
    ai_used = False
    ai_error: str | None = None

    if use_ai and result.filters.included_count > 0:
        renderer = ai_renderer or _render_ai_section
        try:
            ai_text = await renderer(result)
            markdown = _inject_ai_section(markdown, ai_text)
            ai_used = True
        except ConfigurationError:
            raise
        except Exception as exc:
            ai_error = f"{type(exc).__name__}: {exc}"
            logger.warning("AI 分析文字生成失败，输出基础报告：%s", ai_error)

    target = Path(output_path) if output_path else OUTPUT_DIR / REPORT_FILENAME
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(markdown, encoding="utf-8", newline="\n")
    logger.info("历史分析报告已保存：%s（AI 分析：%s）", target, "是" if ai_used else "否")

    return ReportOutcome(
        result=result,
        report_path=target,
        markdown=markdown,
        ai_used=ai_used,
        ai_error=ai_error,
    )


__all__ = [
    "AMOUNT_BUCKETS",
    "AIAnalysisError",
    "ANALYTICS_PROMPT_PATH",
    "MIN_BID_SAMPLE_FOR_INSIGHTS",
    "MIN_CONFIDENCE",
    "AnalyticsResult",
    "AmountBucket",
    "BidAmountStats",
    "DisclosedAmountStats",
    "DistributionItem",
    "FilterStats",
    "ReportOutcome",
    "analyze_historical_data",
    "analyze_records",
    "compute_bid_amount_stats",
    "compute_disclosed_counts",
    "compute_distribution",
    "filter_records",
    "generate_historical_analysis_report",
    "is_valid_source_url",
    "render_base_markdown",
]
