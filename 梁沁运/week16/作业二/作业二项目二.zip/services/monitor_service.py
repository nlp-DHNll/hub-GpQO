"""每日 ESG 招投标公告监控（任务 B）。

流程（全部复用现有能力）：

    get_last_24_hours_range           过去 24 小时窗口
    build_daily_monitor_queries       每日 Query（无年份）
    DeepSeekClient.search_many        Search（内部 Semaphore 控并发）
    normalize_source_url              批内 URL 去重
    TenderRepository.exists_by_url    库内 URL 去重
    DeepSeekClient.fetch_many         Fetch（同一 Semaphore）
    ExtractionService                 TenderRecord 提取
    ── 本模块 ──                      24 小时时间过滤 + 质量过滤
    TenderRepository.save_record      入库（UNIQUE 最终兜底）
    render_daily_markdown             每日简报

时间过滤规则（任务书第四节）：

    start_time < publish_time <= end_time

- ``publish_time`` 必须是公告正文中**明确披露**的日期+时分秒。
  ``TenderRecord.publish_date`` 只有 ``date``，因此额外从 Fetch 正文中用
  确定性正则提取"发布时间 2026-06-23 08:51:29"这类字面量；
  取不到时分秒、或正文日期与结构化日期冲突 → **待核实**，不进日报。
- 绝不使用抓取时间代替公告发布时间。
- 晚于当前时间的公告 → 排除并记录异常。
"""

from __future__ import annotations

import logging
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from datetime import date, datetime, time
from typing import Any, Awaitable, Callable, Literal
from zoneinfo import ZoneInfo

from config.settings import OUTPUT_DIR, ConfigurationError, Settings, get_settings
from db.database import normalize_source_url
from db.repository import SaveOutcome, TenderRepository
from models.tender import AnnouncementType, TenderRecord
from scripts.date_utils import TimeRange, get_current_time, get_last_24_hours_range
from scripts.query_builder import build_daily_monitor_queries
from services.deepseek_client import DeepSeekClient
from services.extraction_service import ExtractionService, get_extraction_service

logger = logging.getLogger(__name__)

REPORT_FILENAME = "daily_monitor_report.md"
MIN_CONFIDENCE = 0.3
AI_SUMMARY_CHAR_LIMIT = 300

# 不在每日日报中出现的公告类型（更正公告属于对既有公告的修订）
_EXCLUDED_TYPES = frozenset({AnnouncementType.OTHER, AnnouncementType.CORRECTION})

DecisionStatus = Literal[
    "included",
    "pending",
    "excluded_old",
    "excluded_future",
    "excluded_type",
    "excluded_low_confidence",
]

FailureStage = Literal["fetch", "extraction", "save", "filter"]

# ---------------------------------------------------------------------------
# 发布时间提取（确定性，不做推断）
# ---------------------------------------------------------------------------

_TIME_TOKEN = r"(?P<time>\d{1,2}\s*[:：]\s*\d{2}(?:\s*[:：]\s*\d{2})?)"
_DATE_TOKEN = (
    r"(?P<date>\d{4}\s*[-/.年]\s*\d{1,2}\s*[-/.月]\s*\d{1,2}\s*日?)"
)

_PUBLISH_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(rf"(?:发布|公告|上网|更新)\s*(?:时间|日期)\s*[：:]\s*{_DATE_TOKEN}\s*{_TIME_TOKEN}"),
    re.compile(rf"{_DATE_TOKEN}\s*[T ]\s*{_TIME_TOKEN}"),
    re.compile(rf"{_DATE_TOKEN}\s*{_TIME_TOKEN}"),
)


def _parse_date_token(token: str) -> date:
    normalized = re.sub(r"\s+", "", token)
    normalized = re.sub(r"[年月]", "-", normalized).replace("日", "")
    normalized = normalized.replace("/", "-").replace(".", "-")
    parts = normalized.split("-")
    if len(parts) != 3:
        raise ValueError(f"无法解析日期：{token!r}")
    return date(int(parts[0]), int(parts[1]), int(parts[2]))


def _parse_time_token(token: str) -> time:
    normalized = re.sub(r"\s+", "", token).replace("：", ":")
    parts = normalized.split(":")
    if len(parts) == 2:
        return time(int(parts[0]), int(parts[1]))
    if len(parts) == 3:
        return time(int(parts[0]), int(parts[1]), int(parts[2]))
    raise ValueError(f"无法解析时间：{token!r}")


def extract_publish_datetime(content: str) -> datetime | None:
    """从正文中提取"日期 + 时分秒"的发布时间；取不到返回 ``None``。

    只匹配明确出现的发布时间字面量，不做任何推测或默认值。
    """
    if not content:
        return None
    for pattern in _PUBLISH_PATTERNS:
        match = pattern.search(content)
        if match is None:
            continue
        try:
            parsed_date = _parse_date_token(match.group("date"))
            parsed_time = _parse_time_token(match.group("time"))
        except (ValueError, TypeError):
            continue
        return datetime.combine(parsed_date, parsed_time)
    return None


def resolve_publish_time(
    publish_date: date | None,
    content: str,
    tz: ZoneInfo,
) -> tuple[datetime | None, str | None]:
    """解析公告发布时间。

    返回 ``(带时区的发布时间, 待核实原因)``：

    - ``publish_date`` 缺失 → 待核实（规则 6）
    - 正文没有时分秒 → 待核实（规则 5）
    - 正文日期与结构化日期冲突 → 待核实（证据不一致，不擅自取舍）
    - 成功 → ``(datetime, None)``
    """
    if publish_date is None:
        return None, "公告发布日期缺失"

    parsed = extract_publish_datetime(content)
    if parsed is None:
        return None, "仅有日期，正文无法确认时分秒"

    if parsed.date() != publish_date:
        return None, (
            f"正文发布时间 {parsed.date().isoformat()} 与结构化发布日期 "
            f"{publish_date.isoformat()} 不一致"
        )
    return parsed.replace(tzinfo=tz), None


# ---------------------------------------------------------------------------
# 过滤判定
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AnnouncementDecision:
    status: DecisionStatus
    reason: str | None = None
    publish_time: datetime | None = None


def evaluate_announcement(
    record: TenderRecord,
    content: str,
    window: TimeRange,
    tz: ZoneInfo,
) -> AnnouncementDecision:
    """按任务书第四节的顺序判定一条公告。

    顺序：公告类型 → 置信度 → 发布时间解析 → 时间窗口。
    每条记录只会落入一个状态，统计不会重复计数。
    """
    if record.announcement_type in _EXCLUDED_TYPES:
        return AnnouncementDecision(
            "excluded_type", reason=f"公告类型为{record.announcement_type.value}"
        )

    if record.confidence is None or record.confidence < MIN_CONFIDENCE:
        return AnnouncementDecision(
            "excluded_low_confidence",
            reason=f"置信度 {record.confidence} 低于 {MIN_CONFIDENCE}",
        )

    publish_time, pending_reason = resolve_publish_time(record.publish_date, content, tz)
    if publish_time is None:
        return AnnouncementDecision("pending", reason=pending_reason)

    if publish_time > window.end:
        return AnnouncementDecision(
            "excluded_future",
            reason=f"发布时间 {publish_time.isoformat()} 晚于当前时间",
            publish_time=publish_time,
        )
    if publish_time <= window.start:
        return AnnouncementDecision(
            "excluded_old",
            reason=f"发布时间 {publish_time.isoformat()} 早于 24 小时窗口",
            publish_time=publish_time,
        )
    return AnnouncementDecision("included", publish_time=publish_time)


# ---------------------------------------------------------------------------
# 统计与结果
# ---------------------------------------------------------------------------


@dataclass
class MonitorStats:
    query_count: int = 0
    search_url_count: int = 0
    unique_url_count: int = 0
    skipped_existing_count: int = 0
    fetch_success_count: int = 0
    fetch_failed_count: int = 0
    extraction_success_count: int = 0
    extraction_failed_count: int = 0
    included_count: int = 0
    excluded_old_count: int = 0
    excluded_future_count: int = 0
    pending_verification_count: int = 0
    excluded_announcement_type_count: int = 0
    excluded_low_confidence_count: int = 0
    duplicate_count: int = 0
    save_failed_count: int = 0
    # 补充：真正写入数据库的新公告数量（日报中的"新公告数量"以此为准）
    inserted_count: int = 0

    def as_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(frozen=True)
class MonitorFailure:
    url: str
    stage: FailureStage
    error: str

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class DailyAnnouncement:
    """日报中展示的新公告（只放确定性字段）。"""

    project_name: str
    announcement_type: str
    publish_time: datetime
    region: str | None
    source_url: str
    record_id: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "project_name": self.project_name,
            "announcement_type": self.announcement_type,
            "publish_time": self.publish_time.isoformat(),
            "region": self.region,
            "source_url": self.source_url,
            "record_id": self.record_id,
        }


@dataclass
class MonitorReport:
    start_time: datetime
    end_time: datetime
    stats: MonitorStats
    failures: list[MonitorFailure] = field(default_factory=list)
    announcements: list[DailyAnnouncement] = field(default_factory=list)
    pending_reasons: list[str] = field(default_factory=list)
    report_path: str | None = None
    ai_used: bool = False
    ai_error: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "stats": self.stats.as_dict(),
            "failures": [item.as_dict() for item in self.failures],
            "announcements": [item.as_dict() for item in self.announcements],
            "pending_reasons": list(self.pending_reasons),
            "report_path": self.report_path,
            "ai_used": self.ai_used,
            "ai_error": self.ai_error,
        }


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


async def run_daily_monitor(
    *,
    now: datetime | None = None,
    client: DeepSeekClient | None = None,
    extractor: ExtractionService | None = None,
    repository: TenderRepository | None = None,
    settings: Settings | None = None,
    use_ai: bool = True,
    ai_renderer: Callable[..., Awaitable[str]] | None = None,
    output_path: Path | None = None,
) -> MonitorReport:
    """执行一次每日监控。

    :param now: 结束时间（测试可注入）；默认取当前业务时区时间
    :param use_ai: 是否调用模型压缩简报文字（失败自动降级）
    :param ai_renderer: 可注入的异步文字生成函数
    """
    settings = settings or get_settings()
    tz = settings.timezone
    current = now or get_current_time(tz)
    if current.tzinfo is None:
        raise ValueError("now 必须带时区")
    window = get_last_24_hours_range(current, tz)

    repository = repository or TenderRepository()
    extractor = extractor or get_extraction_service()
    owns_client = client is None
    client = client or DeepSeekClient(settings=settings)

    stats = MonitorStats()
    failures: list[MonitorFailure] = []
    announcements: list[DailyAnnouncement] = []
    pending_reasons: list[str] = []

    try:
        # --- 1~3. Query + Search ----------------------------------------
        queries = build_daily_monitor_queries()
        stats.query_count = len(queries)
        search_results = await client.search_many([query.text for query in queries])
        stats.search_url_count = sum(len(result.items) for result in search_results)
        logger.info(
            "每日监控开始：窗口 %s ~ %s，Query %d，Search URL %d",
            window.start.isoformat(),
            window.end.isoformat(),
            stats.query_count,
            stats.search_url_count,
        )

        # --- 4. 批内 URL 去重 -------------------------------------------
        candidates: dict[str, tuple[str, str]] = {}
        for search_result in search_results:
            for item in search_result.items:
                try:
                    key = normalize_source_url(item.url)
                except ValueError:
                    continue
                if key not in candidates:
                    candidates[key] = (item.url, item.title)
        stats.unique_url_count = len(candidates)

        # --- 5. 跳过库内已有 -------------------------------------------
        pending: list[tuple[str, str]] = []
        for url, title in candidates.values():
            if repository.exists_by_url(url):
                stats.skipped_existing_count += 1
                continue
            pending.append((url, title))
        logger.info(
            "批内去重 %d，跳过库内已有 %d，待抓取 %d",
            stats.unique_url_count,
            stats.skipped_existing_count,
            len(pending),
        )

        # --- 6. Fetch ---------------------------------------------------
        fetch_results = await client.fetch_many([url for url, _ in pending])

        # --- 7~9. 提取 → 过滤 → 入库 ------------------------------------
        for (url, title), fetched in zip(pending, fetch_results, strict=True):
            if fetched.status == "error" or not fetched.content.strip():
                stats.fetch_failed_count += 1
                failures.append(
                    MonitorFailure(url, "fetch", fetched.error or "正文为空")
                )
                logger.warning("Fetch 失败，跳过：%s", url)
                continue
            stats.fetch_success_count += 1

            try:
                record = await extractor.extract_tender_record(
                    fetched.content, fetched.url, (fetched.title or title) or None
                )
            except ConfigurationError:
                raise
            except Exception as exc:
                stats.extraction_failed_count += 1
                failures.append(
                    MonitorFailure(url, "extraction", f"{type(exc).__name__}: {exc}")
                )
                logger.warning("提取失败，跳过：%s", url)
                continue
            stats.extraction_success_count += 1

            decision = evaluate_announcement(record, fetched.content, window, tz)
            if decision.status == "pending":
                stats.pending_verification_count += 1
                pending_reasons.append(f"{url}：{decision.reason}")
                continue
            if decision.status == "excluded_old":
                stats.excluded_old_count += 1
                continue
            if decision.status == "excluded_future":
                stats.excluded_future_count += 1
                failures.append(MonitorFailure(url, "filter", decision.reason or "未来时间"))
                continue
            if decision.status == "excluded_type":
                stats.excluded_announcement_type_count += 1
                continue
            if decision.status == "excluded_low_confidence":
                stats.excluded_low_confidence_count += 1
                continue

            assert decision.status == "included" and decision.publish_time is not None
            stats.included_count += 1
            try:
                save_result = repository.save_record(record)
            except Exception as exc:
                stats.save_failed_count += 1
                failures.append(
                    MonitorFailure(url, "save", f"{type(exc).__name__}: {exc}")
                )
                logger.warning("入库失败：%s", url)
                continue

            if save_result.outcome is SaveOutcome.INSERTED:
                stats.inserted_count += 1
                announcements.append(
                    DailyAnnouncement(
                        project_name=record.project_name,
                        announcement_type=record.announcement_type.value,
                        publish_time=decision.publish_time,
                        region=record.region,
                        source_url=str(record.source_url),
                        record_id=save_result.record_id,
                    )
                )
            else:
                stats.duplicate_count += 1
    finally:
        if owns_client:
            await client.aclose()

    # --- 10. 日报 ------------------------------------------------------
    markdown = render_daily_markdown(window, stats, announcements)
    ai_used = False
    ai_error: str | None = None
    if use_ai:
        renderer = ai_renderer or _render_ai_summary
        try:
            summary = _truncate(await renderer(window, stats, announcements), AI_SUMMARY_CHAR_LIMIT)
            if summary:
                markdown = _inject_ai_summary(markdown, summary)
                ai_used = True
        except ConfigurationError:
            raise
        except Exception as exc:
            ai_error = f"{type(exc).__name__}: {exc}"
            logger.warning("日报 AI 文字生成失败，输出基础简报：%s", ai_error)

    target = _resolve_report_path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(markdown, encoding="utf-8", newline="\n")

    report = MonitorReport(
        start_time=window.start,
        end_time=window.end,
        stats=stats,
        failures=failures,
        announcements=announcements,
        pending_reasons=pending_reasons,
        report_path=str(target),
        ai_used=ai_used,
        ai_error=ai_error,
    )
    logger.info(
        "每日监控完成：新增 %d，待核实 %d，旧公告 %d，未来 %d，失败 %d，简报 %s",
        stats.inserted_count,
        stats.pending_verification_count,
        stats.excluded_old_count,
        stats.excluded_future_count,
        len(failures),
        target,
    )
    return report


# ---------------------------------------------------------------------------
# 日报渲染
# ---------------------------------------------------------------------------


def render_daily_markdown(
    window: TimeRange,
    stats: MonitorStats,
    announcements: list[DailyAnnouncement],
) -> str:
    """确定性日报：所有数字与列表均来自 Python 统计。"""
    lines: list[str] = []
    lines.append("# ESG 招投标每日监控简报")
    lines.append("")
    lines.append(
        f"- 监控时间窗（Asia/Shanghai）：{window.start.strftime('%Y-%m-%d %H:%M:%S')} "
        f"~ {window.end.strftime('%Y-%m-%d %H:%M:%S')}"
    )
    lines.append(f"- 本次发现新公告：**{stats.inserted_count}** 条")
    lines.append("")
    lines.append("## 一、新公告")
    lines.append("")
    if not announcements:
        lines.append("过去24小时未发现符合条件的新公告。")
    else:
        lines.append("| # | 项目名称 | 公告类型 | 发布时间 | 地区 | 来源 URL |")
        lines.append("|---:|---|---|---|---|---|")
        for index, item in enumerate(announcements, start=1):
            name = _md_cell(item.project_name)
            region = _md_cell(item.region or "—")
            url = item.source_url
            lines.append(
                f"| {index} | {name} | {item.announcement_type} | "
                f"{item.publish_time.strftime('%Y-%m-%d %H:%M')} | {region} | "
                f"<{url}> |"
            )
    lines.append("")

    lines.append("## 二、待核实")
    lines.append("")
    if stats.pending_verification_count:
        lines.append(
            f"共 **{stats.pending_verification_count}** 条公告的发布时间无法确认到时分秒"
            "（仅有日期或正文未标明发布时间），未计入正式新公告数，需人工核实。"
        )
    else:
        lines.append("无。")
    lines.append("")

    lines.append("## 三、窗口内排除与其他情况")
    lines.append("")
    lines.append(
        f"- 早于 24 小时窗口被排除：{stats.excluded_old_count} 条\n"
        f"- 发布时间晚于当前时间被排除：{stats.excluded_future_count} 条\n"
        f"- 公告类型为「其他」或更正公告被排除：{stats.excluded_announcement_type_count} 条\n"
        f"- 置信度低于 {MIN_CONFIDENCE} 被排除：{stats.excluded_low_confidence_count} 条\n"
        f"- 数据库已有 URL 跳过：{stats.skipped_existing_count} 条\n"
        f"- 入库时判定重复：{stats.duplicate_count} 条\n"
        f"- Fetch 失败：{stats.fetch_failed_count} 条\n"
        f"- 提取失败：{stats.extraction_failed_count} 条"
    )
    lines.append("")
    lines.append("> 本简报只统计公开网络可检索信息，非全量；金额未在日报中展示，"
                 "未披露金额不做任何推算。")
    lines.append("")
    return "\n".join(lines)


def _md_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ").strip()


def _truncate(text: str, limit: int) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _inject_ai_summary(markdown: str, summary: str) -> str:
    section = f"## 摘要（由模型基于本次统计生成）\n\n> {summary}\n\n"
    marker = "## 一、新公告"
    if marker in markdown:
        return markdown.replace(marker, section + marker, 1)
    return markdown + "\n" + section


async def _render_ai_summary(
    window: TimeRange,
    stats: MonitorStats,
    announcements: list[DailyAnnouncement],
) -> str:
    """可选的模型摘要；失败时由主流程降级为确定性简报。"""
    import json

    from openai import AsyncOpenAI

    settings = get_settings()
    missing = [
        name
        for name, value in (
            ("SILICONFLOW_API_KEY", settings.siliconflow_api_key),
            ("SILICONFLOW_BASE_URL", settings.siliconflow_base_url),
            ("DEEPSEEK_MODEL", settings.deepseek_model),
        )
        if not value
    ]
    if missing:
        raise ConfigurationError("日报摘要缺少必要配置：" + "、".join(missing))

    payload = {
        "start_time": window.start.isoformat(),
        "end_time": window.end.isoformat(),
        "new_count": stats.inserted_count,
        "pending_count": stats.pending_verification_count,
        "announcements": [item.as_dict() for item in announcements],
    }
    prompt = (
        "你是 ESG 招投标情报助理。请根据给定的确定性统计 JSON，用不超过 200 个中文字符"
        "写一段简报摘要。规则：\n"
        "1. 数字只能取自 JSON，不得修改、补充或推测；\n"
        "2. 不得编造公告内容、金额或趋势；\n"
        "3. 金额未披露就不要提及金额；\n"
        "4. 若无新公告，明确写「过去24小时未发现符合条件的新公告」；\n"
        "5. 只输出摘要正文，不要标题、不要列表、不要 JSON。"
    )
    assert settings.siliconflow_api_key is not None  # 已校验
    client = AsyncOpenAI(
        api_key=settings.siliconflow_api_key.get_secret_value(),
        base_url=str(settings.siliconflow_base_url),
    )
    try:
        response = await client.chat.completions.create(
            model=settings.deepseek_model,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
            ],
            temperature=0.0,
            max_tokens=400,
            timeout=settings.request_timeout_seconds,
        )
    except Exception as exc:
        raise RuntimeError(f"日报摘要生成失败（{type(exc).__name__}）") from exc
    if not getattr(response, "choices", None):
        raise RuntimeError("日报摘要生成失败：模型未返回 choices")
    text = (response.choices[0].message.content or "").strip()
    if not text:
        raise RuntimeError("日报摘要生成失败：模型返回为空")
    return text


def _resolve_report_path(output_path: Path | None) -> Path:
    return Path(output_path) if output_path else OUTPUT_DIR / REPORT_FILENAME


__all__ = [
    "AI_SUMMARY_CHAR_LIMIT",
    "AnnouncementDecision",
    "DailyAnnouncement",
    "MonitorFailure",
    "MonitorReport",
    "MonitorStats",
    "REPORT_FILENAME",
    "evaluate_announcement",
    "extract_publish_datetime",
    "render_daily_markdown",
    "resolve_publish_time",
    "run_daily_monitor",
]
