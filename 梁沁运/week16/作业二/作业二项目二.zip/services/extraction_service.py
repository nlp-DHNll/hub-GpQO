"""结构化提取服务：网页正文 → SiliconFlow 模型 → Pydantic 校验 → TenderRecord。

调用方式沿用项目一已验证的 SiliconFlow OpenAI 兼容接口：

    AsyncOpenAI(api_key=SILICONFLOW_API_KEY, base_url=SILICONFLOW_BASE_URL)
    await client.chat.completions.create(model=DEEPSEEK_MODEL, messages=[...], ...)

设计要点：

- 配置只从 ``config.settings`` 读取。
- 提示词来自 ``prompts/extraction_prompt.txt``，正文作为**用户消息中的数据处理**，
  不拼进 system prompt，降低"正文内指令注入"的影响。
- 模型返回的 JSON 先做容错抽取（去代码围栏 / 截取首个 JSON 对象），
  再交给 ``TenderRecord`` 做类型与业务约束校验。
- ``source_url`` / ``source_title`` 由调用方提供，**不信任模型返回的值**。
- 任何异常信息只包含错误类型与简短描述，绝不包含 API Key。
"""

from __future__ import annotations

import json
import logging
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

from openai import AsyncOpenAI
from pydantic import ValidationError

from config.settings import PROJECT_ROOT, ConfigurationError, Settings, get_settings
from models.tender import TenderRecord

logger = logging.getLogger(__name__)

PROMPT_PATH: Path = PROJECT_ROOT / "prompts" / "extraction_prompt.txt"

# 控制正文长度，避免超出模型上下文；过长时保留开头与结尾
DEFAULT_MAX_CONTENT_CHARS: int = 24_000
_CONTENT_HEAD_RATIO = 0.7

DEFAULT_TEMPERATURE: float = 0.0
DEFAULT_MAX_TOKENS: int = 2_000

_CODE_FENCE_PATTERN = re.compile(r"^```[a-zA-Z0-9_-]*\s*|\s*```$")


class ExtractionError(RuntimeError):
    """结构化提取失败的基类。消息中不包含 API Key。"""


class ModelCallError(ExtractionError):
    """模型调用失败（网络、鉴权、限流等）。"""


class JSONParseError(ExtractionError):
    """模型输出无法解析为 JSON 对象。"""


class RecordValidationError(ExtractionError):
    """模型输出不符合 TenderRecord 的字段或业务约束。"""

    def __init__(self, message: str, field_errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.field_errors = field_errors or []


# ---------------------------------------------------------------------------
# 提示词
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def load_extraction_prompt(path: Path = PROMPT_PATH) -> str:
    """读取提取提示词；缺失时抛出清晰异常。"""
    if not path.exists():
        raise ConfigurationError(
            f"缺少提取提示词文件：{path}。请确认 prompts/extraction_prompt.txt 存在。"
        )
    prompt = path.read_text(encoding="utf-8").strip()
    if not prompt:
        raise ConfigurationError(f"提取提示词文件为空：{path}")
    return prompt


# ---------------------------------------------------------------------------
# JSON 解析
# ---------------------------------------------------------------------------


def _strip_code_fence(text: str) -> str:
    stripped = text.strip()
    stripped = _CODE_FENCE_PATTERN.sub("", stripped).strip()
    return stripped


def _extract_json_object(text: str) -> str:
    """从模型输出中截取第一个完整的 JSON 对象（按花括号配对，跳过字符串内部）。"""
    start = text.find("{")
    if start < 0:
        return text
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[start : index + 1]
    return text[start:]


def parse_model_json(raw: str) -> dict[str, Any]:
    """把模型原始输出解析为 dict；失败抛出 ``JSONParseError``。"""
    if not isinstance(raw, str) or not raw.strip():
        raise JSONParseError("模型返回内容为空")

    candidate = _extract_json_object(_strip_code_fence(raw))
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise JSONParseError(
            f"模型输出不是合法 JSON（第 {exc.lineno} 行第 {exc.colno} 列）：{exc.msg}"
        ) from exc

    if not isinstance(data, dict):
        raise JSONParseError(f"模型输出 JSON 顶层必须是对象，实际为 {type(data).__name__}")
    return data


# ---------------------------------------------------------------------------
# 正文裁剪
# ---------------------------------------------------------------------------


def truncate_content(content: str, max_chars: int = DEFAULT_MAX_CONTENT_CHARS) -> str:
    """超长正文保留开头与结尾，并在中间插入说明标记。"""
    if max_chars <= 0:
        raise ValueError("max_chars 必须为正整数")
    if len(content) <= max_chars:
        return content
    head_len = int(max_chars * _CONTENT_HEAD_RATIO)
    tail_len = max_chars - head_len
    marker = f"\n\n……（正文过长，中间已省略 {len(content) - max_chars} 字符）……\n\n"
    return content[:head_len] + marker + content[-tail_len:]


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------


class ExtractionService:
    """调用 SiliconFlow 模型把网页正文转换为 ``TenderRecord``。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: AsyncOpenAI | None = None,
        prompt: str | None = None,
        temperature: float = DEFAULT_TEMPERATURE,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        max_content_chars: int = DEFAULT_MAX_CONTENT_CHARS,
    ) -> None:
        self._settings = settings or get_settings()
        self._client = client
        self._prompt = prompt
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._max_content_chars = max_content_chars

    # --- 配置与客户端 --------------------------------------------------

    def _require_settings(self) -> None:
        missing = [
            name
            for name, value in (
                ("SILICONFLOW_API_KEY", self._settings.siliconflow_api_key),
                ("SILICONFLOW_BASE_URL", self._settings.siliconflow_base_url),
                ("DEEPSEEK_MODEL", self._settings.deepseek_model),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "结构化提取缺少必要配置：" + "、".join(missing) + "。"
            )

    def _get_client(self) -> AsyncOpenAI:
        if self._client is not None:
            return self._client
        assert self._settings.siliconflow_api_key is not None  # 已校验
        return AsyncOpenAI(
            api_key=self._settings.siliconflow_api_key.get_secret_value(),
            base_url=str(self._settings.siliconflow_base_url),
        )

    # --- 公开入口 ------------------------------------------------------

    async def extract_tender_record(
        self,
        content: str,
        source_url: str,
        source_title: str | None = None,
    ) -> TenderRecord:
        """从网页正文中提取一条 ``TenderRecord``。

        :raises ConfigurationError: 缺少配置或提示词
        :raises ModelCallError: 模型调用失败
        :raises JSONParseError: 模型输出不是 JSON 对象
        :raises RecordValidationError: 数据不符合字段/业务约束
        """
        if not isinstance(content, str) or not content.strip():
            raise ValueError("网页正文为空，无法提取")

        self._require_settings()
        prompt = self._prompt if self._prompt is not None else load_extraction_prompt()
        model = self._settings.deepseek_model
        assert model is not None  # 已校验

        body = truncate_content(content.strip(), self._max_content_chars)

        messages: list[dict[str, str]] = [
            {"role": "system", "content": prompt},
            {
                "role": "user",
                "content": (
                    "<source_url>\n"
                    f"{source_url}\n"
                    "</source_url>\n"
                    "<source_title>\n"
                    f"{(source_title or '').strip() or '（无）'}\n"
                    "</source_title>\n"
                    "<page_content>\n"
                    f"{body}\n"
                    "</page_content>\n\n"
                    "请按系统提示词的规则抽取招投标记录，只输出 JSON 对象。"
                ),
            },
        ]

        client = self._get_client()
        logger.info(
            "提取开始：url=%s，正文 %d 字符（送入模型 %d），模型 %s",
            source_url,
            len(content),
            len(body),
            model,
        )
        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                timeout=self._settings.request_timeout_seconds,
            )
        except Exception as exc:  # openai 异常种类多，统一包装
            logger.error("模型调用失败：%s", type(exc).__name__)
            raise ModelCallError(
                "模型调用失败"
                f"（{type(exc).__name__}）：{_sanitize_message(str(exc), self._settings)}"
            ) from exc

        if not getattr(response, "choices", None):
            raise ModelCallError("模型返回结果为空（没有 choices）")
        raw = response.choices[0].message.content or ""

        data = parse_model_json(raw)
        record = self.build_record(data, source_url=source_url, source_title=source_title)
        logger.info(
            "提取完成：type=%s industry=%s confidence=%.2f",
            record.announcement_type.value,
            record.industry.value,
            record.confidence,
        )
        return record

    # --- 数据组装与校验 ------------------------------------------------

    def build_record(
        self,
        data: dict[str, Any],
        *,
        source_url: str,
        source_title: str | None = None,
    ) -> TenderRecord:
        """把模型返回的 dict 转成 ``TenderRecord``。

        ``source_url`` 以调用方提供的为准，不使用模型返回的值；
        ``source_title`` 同理，模型返回该字段时忽略。
        """
        payload = dict(data)
        payload["source_url"] = source_url
        payload["source_title"] = source_title

        # 模型输出中不应出现、且不被使用的字段
        for key in ("source_text", "raw", "url"):
            payload.pop(key, None)

        try:
            return TenderRecord.model_validate(payload)
        except ValidationError as exc:
            field_errors = [
                f"{'.'.join(str(part) for part in error['loc']) or '<root>'}: "
                f"{error['msg']}"
                for error in exc.errors()
            ]
            raise RecordValidationError(
                "模型输出不符合招投标记录约束：" + "；".join(field_errors),
                field_errors=field_errors,
            ) from exc


def _safe_excerpt(text: str, limit: int = 200) -> str:
    """错误摘要：压缩空白并截断，避免冗长。"""
    return re.sub(r"\s+", " ", text).strip()[:limit]


def _sanitize_message(text: str, settings: Settings, limit: int = 200) -> str:
    """错误摘要 + 兜底脱敏：即使第三方异常回显了 Key，也会被替换为 ***。"""
    secret = settings.siliconflow_api_key
    if secret is not None:
        raw = secret.get_secret_value()
        if raw and raw in text:
            text = text.replace(raw, "***")
    return _safe_excerpt(text, limit)


_default_service: ExtractionService | None = None


def get_extraction_service() -> ExtractionService:
    """进程内复用的默认提取服务。"""
    global _default_service
    if _default_service is None:
        _default_service = ExtractionService()
    return _default_service


async def extract_tender_record(
    content: str,
    source_url: str,
    source_title: str | None = None,
    *,
    service: ExtractionService | None = None,
) -> TenderRecord:
    """便捷函数：使用默认服务从网页正文提取 ``TenderRecord``。"""
    return await (service or get_extraction_service()).extract_tender_record(
        content, source_url, source_title
    )


__all__ = [
    "DEFAULT_MAX_CONTENT_CHARS",
    "ExtractionError",
    "ExtractionService",
    "JSONParseError",
    "ModelCallError",
    "PROMPT_PATH",
    "RecordValidationError",
    "extract_tender_record",
    "get_extraction_service",
    "load_extraction_prompt",
    "parse_model_json",
    "truncate_content",
]
