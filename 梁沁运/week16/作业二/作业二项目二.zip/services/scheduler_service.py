"""APScheduler 3.x 定时调度（单实例）。

只负责"按时触发每日监控"，不承载任何业务逻辑：

- 时区：``settings.app_timezone``（默认 ``Asia/Shanghai``）
- 触发：每天 ``settings.monitor_hour:monitor_minute``（默认 09:00）
- 单实例：``max_instances=1``、``coalesce=True``，
  错过执行时允许在 ``MISFIRE_GRACE_SECONDS`` 内补跑一次
- 任务异常只记录日志，**不向上抛出**，保证调度器持续运行
- 进程内只允许一个调度器实例（``start_scheduler()`` 幂等）
"""

from __future__ import annotations

import logging
from time import perf_counter
from typing import Any, Awaitable, Callable
from zoneinfo import ZoneInfo

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from config.settings import Settings, get_settings
from services.monitor_service import MonitorReport, run_daily_monitor

logger = logging.getLogger(__name__)

JOB_ID = "daily_esg_monitor"
JOB_NAME = "每日 ESG 公告监控"
MISFIRE_GRACE_SECONDS = 3_600  # 错过触发后 1 小时内仍补跑

JobRunner = Callable[[], Awaitable[MonitorReport]]


class MonitorScheduler:
    """封装 AsyncIOScheduler，保证进程内单实例。"""

    def __init__(
        self,
        settings: Settings | None = None,
        job_runner: JobRunner | None = None,
    ) -> None:
        self._settings = settings or get_settings()
        self._job_runner: JobRunner = job_runner or _default_job_runner
        self._scheduler: AsyncIOScheduler | None = None

    # --- 属性 ----------------------------------------------------------

    @property
    def settings(self) -> Settings:
        return self._settings

    @property
    def scheduler(self) -> AsyncIOScheduler:
        if self._scheduler is None:
            self._scheduler = self._build_scheduler()
        return self._scheduler

    @property
    def is_running(self) -> bool:
        return self._scheduler is not None and bool(self._scheduler.running)

    @property
    def timezone(self) -> ZoneInfo:
        return ZoneInfo(self._settings.app_timezone)

    # --- 构建 ----------------------------------------------------------

    def _build_scheduler(self) -> AsyncIOScheduler:
        scheduler = AsyncIOScheduler(timezone=self.timezone)
        scheduler.add_job(
            self.execute_job,
            trigger=CronTrigger(
                hour=self._settings.monitor_hour,
                minute=self._settings.monitor_minute,
                timezone=self.timezone,
            ),
            id=JOB_ID,
            name=JOB_NAME,
            max_instances=1,
            coalesce=True,
            misfire_grace_time=MISFIRE_GRACE_SECONDS,
            replace_existing=True,
        )
        return scheduler

    # --- 生命周期 ------------------------------------------------------

    def start(self) -> "MonitorScheduler":
        """启动调度器；重复调用不会创建第二个调度器或重复注册任务。"""
        if self.is_running:
            logger.info("调度器已在运行，忽略重复启动")
            return self
        scheduler = self.scheduler
        scheduler.start()
        hour = self._settings.monitor_hour
        minute = self._settings.monitor_minute
        logger.info(
            "调度器已启动：任务「%s」每天 %02d:%02d（%s）执行，错过补跑窗口 %d 秒",
            JOB_NAME,
            hour,
            minute,
            self._settings.app_timezone,
            MISFIRE_GRACE_SECONDS,
        )
        return self

    def shutdown(self) -> None:
        """关闭调度器；未启动时调用是安全的。"""
        if self._scheduler is None:
            logger.info("调度器尚未创建，无需关闭")
            return
        if self._scheduler.running:
            self._scheduler.shutdown(wait=False)
            logger.info("调度器已关闭")
        else:
            logger.info("调度器未在运行，跳过关闭")
        self._scheduler = None

    # --- 任务执行 ------------------------------------------------------

    async def execute_job(self) -> None:
        """定时任务本体：执行每日监控并记录开始/结束/耗时/异常。

        异常只记录，不向上抛出，避免调度器因单次失败退出。
        """
        started = perf_counter()
        logger.info("每日监控任务开始")
        try:
            report = await self._job_runner()
            elapsed = perf_counter() - started
            logger.info(
                "每日监控任务完成：新增 %d 条，待核实 %d 条，耗时 %.1f 秒",
                report.stats.inserted_count,
                report.stats.pending_verification_count,
                elapsed,
            )
        except Exception:
            elapsed = perf_counter() - started
            logger.exception("每日监控任务失败，耗时 %.1f 秒", elapsed)
        finally:
            logger.debug("每日监控任务结束（总耗时 %.2f 秒）", perf_counter() - started)

    def get_jobs(self) -> list[Any]:
        return list(self.scheduler.get_jobs())


# ---------------------------------------------------------------------------
# 默认任务与模块级单例
# ---------------------------------------------------------------------------


async def _default_job_runner() -> MonitorReport:
    return await run_daily_monitor(use_ai=True)


_scheduler_singleton: MonitorScheduler | None = None


def start_scheduler(
    settings: Settings | None = None,
    job_runner: JobRunner | None = None,
) -> MonitorScheduler:
    """启动进程内唯一调度器（幂等）。"""
    global _scheduler_singleton
    if _scheduler_singleton is None:
        _scheduler_singleton = MonitorScheduler(settings=settings, job_runner=job_runner)
    elif job_runner is not None and _scheduler_singleton._job_runner is not job_runner:
        logger.warning("调度器已存在，忽略新的 job_runner 注入")
    return _scheduler_singleton.start()


def shutdown_scheduler() -> None:
    """关闭并释放进程内调度器。"""
    global _scheduler_singleton
    if _scheduler_singleton is None:
        logger.info("调度器尚未启动")
        return
    _scheduler_singleton.shutdown()
    _scheduler_singleton = None


def get_scheduler() -> MonitorScheduler | None:
    return _scheduler_singleton


__all__ = [
    "JOB_ID",
    "JOB_NAME",
    "MISFIRE_GRACE_SECONDS",
    "MonitorScheduler",
    "get_scheduler",
    "shutdown_scheduler",
    "start_scheduler",
]
