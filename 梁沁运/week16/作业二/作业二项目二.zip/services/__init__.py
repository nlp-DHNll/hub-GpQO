"""外部服务封装包。

- ``deepseek_client``：DeepSeek Search / Fetch
- ``extraction_service``：SiliconFlow 结构化提取

后续的任务编排逻辑放在 ``historical_service`` / ``monitoring_service`` 中。
"""

from services.deepseek_client import (
    DeepSeekClient,
    DeepSeekError,
    FetchError,
    FetchResult,
    SearchError,
    SearchResult,
    SearchResultItem,
)
from services.collection_service import (
    CollectionFailure,
    CollectionReport,
    CollectionStats,
    run_historical_collection,
)
from services.monitor_service import (
    DailyAnnouncement,
    MonitorFailure,
    MonitorReport,
    MonitorStats,
    run_daily_monitor,
)
from services.extraction_service import (
    ExtractionError,
    ExtractionService,
    JSONParseError,
    ModelCallError,
    RecordValidationError,
    extract_tender_record,
    get_extraction_service,
)

__all__ = [
    "CollectionFailure",
    "CollectionReport",
    "CollectionStats",
    "DailyAnnouncement",
    "DeepSeekClient",
    "DeepSeekError",
    "ExtractionError",
    "ExtractionService",
    "FetchError",
    "FetchResult",
    "JSONParseError",
    "ModelCallError",
    "MonitorFailure",
    "MonitorReport",
    "MonitorStats",
    "RecordValidationError",
    "SearchError",
    "SearchResult",
    "SearchResultItem",
    "extract_tender_record",
    "get_extraction_service",
    "run_daily_monitor",
    "run_historical_collection",
]
