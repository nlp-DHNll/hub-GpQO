"""日期与时间窗口计算（业务规则见 CLAUDE.md 第五节）。

- 任务 A：历史报告期 = 运行日期往前推 **两年**（结束日为运行当天）。
- 任务 B：每日监控窗口 = 运行时刻往前 **24 小时**。

所有计算都基于项目配置的业务时区（默认 ``Asia/Shanghai``），
不写死任何年份/日期；时间对象一律带时区。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta, tzinfo
from zoneinfo import ZoneInfo

from config.settings import get_settings

logger = logging.getLogger(__name__)

# 业务规则常量（CLAUDE.md 第五节第 1、2 条）
HISTORICAL_LOOKBACK_YEARS: int = 2
DAILY_LOOKBACK_HOURS: int = 24


@dataclass(frozen=True)
class DateRange:
    """闭区间的日期范围（含起止日）。"""

    start: date
    end: date

    def __post_init__(self) -> None:
        if self.start > self.end:
            raise ValueError(f"日期范围非法：start={self.start} 晚于 end={self.end}")

    @property
    def years(self) -> list[int]:
        """范围内涉及的全部年份（升序），供 Query 生成使用。"""
        return list(range(self.start.year, self.end.year + 1))

    def contains(self, value: date) -> bool:
        return self.start <= value <= self.end

    def describe(self) -> str:
        return f"{self.start.isoformat()} ~ {self.end.isoformat()}"


@dataclass(frozen=True)
class TimeRange:
    """带时区的闭区间时间范围。"""

    start: datetime
    end: datetime

    def __post_init__(self) -> None:
        if self.start.tzinfo is None or self.end.tzinfo is None:
            raise ValueError("TimeRange 的 start/end 必须带时区")
        if self.start > self.end:
            raise ValueError(f"时间范围非法：start={self.start} 晚于 end={self.end}")

    @property
    def duration_hours(self) -> float:
        return (self.end - self.start).total_seconds() / 3600

    def contains(self, value: datetime) -> bool:
        return self.start <= value <= self.end

    def describe(self) -> str:
        return f"{self.start.isoformat()} ~ {self.end.isoformat()}"


def resolve_timezone(timezone: str | tzinfo | None = None) -> tzinfo:
    """解析时区：显式 tzinfo > 显式名称 > 项目配置。"""
    if isinstance(timezone, tzinfo):
        return timezone
    if timezone is None:
        timezone = get_settings().app_timezone
    return ZoneInfo(timezone)


def get_current_time(timezone: str | tzinfo | None = None) -> datetime:
    """当前时间（带业务时区）。"""
    return datetime.now(resolve_timezone(timezone))


def _require_aware(value: datetime) -> datetime:
    if value.tzinfo is None:
        raise ValueError("时间必须是带时区的 datetime，禁止使用不带时区的 datetime")
    return value


def shift_years_back(value: date, years: int) -> date:
    """把日期往前推 N 年；2 月 29 日退化为 2 月 28 日。"""
    if years < 0:
        raise ValueError("years 必须为非负整数")
    try:
        return value.replace(year=value.year - years)
    except ValueError:
        # 闰日：目标年份没有 2 月 29 日
        return value.replace(year=value.year - years, day=28)


def get_historical_date_range(
    now: datetime | None = None,
    timezone: str | tzinfo | None = None,
) -> DateRange:
    """任务 A：运行日期往前推两年的日期范围，结束日为运行当天。"""
    current = _require_aware(now) if now is not None else get_current_time(timezone)
    today = current.date()
    start = shift_years_back(today, HISTORICAL_LOOKBACK_YEARS)
    date_range = DateRange(start=start, end=today)
    logger.debug(
        "历史报告期：%s（时区 %s）", date_range.describe(), current.tzinfo
    )
    return date_range


def get_last_24_hours_range(
    now: datetime | None = None,
    timezone: str | tzinfo | None = None,
) -> TimeRange:
    """任务 B：运行时刻往前 24 小时的时间窗口。"""
    current = _require_aware(now) if now is not None else get_current_time(timezone)
    window = TimeRange(
        start=current - timedelta(hours=DAILY_LOOKBACK_HOURS),
        end=current,
    )
    logger.debug("每日监控窗口：%s（时区 %s）", window.describe(), current.tzinfo)
    return window


__all__ = [
    "DAILY_LOOKBACK_HOURS",
    "HISTORICAL_LOOKBACK_YEARS",
    "DateRange",
    "TimeRange",
    "get_current_time",
    "get_historical_date_range",
    "get_last_24_hours_range",
    "resolve_timezone",
    "shift_years_back",
]
