"""搜索 Query 矩阵构建（任务 A / 任务 B）。

只做确定性的字符串组合，不调用任何 API：

- 任务 A：历史关键词 × 报告期涉及年份（全国范围，不生成省份组合）。
- 任务 B：每日监控关键词（用于最近 24 小时窗口）。

年份一律由 ``scripts.date_utils`` 计算的日期范围推导，不写死。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Final, Literal

from scripts.date_utils import DateRange, get_historical_date_range

logger = logging.getLogger(__name__)

# DeepSeek Search API 对 query 长度的约束（与项目一已验证实现一致）
MAX_QUERY_LENGTH: Final[int] = 128

TaskName = Literal["historical", "daily"]

# 任务 A：历史数据采集关键词
HISTORICAL_KEYWORDS: Final[tuple[str, ...]] = (
    "ESG 招标 中标",
    "双碳 招标 中标公告",
    "可持续发展 项目 中标结果",
    "碳达峰 碳中和 招标 预算 中标金额",
    "绿色低碳 咨询服务 中标 公告",
    "碳核算 碳盘查 碳资产 招标 中标",
)

# 任务 B：每日监控关键词（不追加年份）
DAILY_KEYWORDS: Final[tuple[str, ...]] = (
    "ESG 招标公告",
    "双碳 招标公告",
    "可持续发展 招标公告",
    "碳达峰 碳中和 招标",
    "绿色低碳 采购 招标公告",
)


@dataclass(frozen=True)
class SearchQuery:
    """一条待执行的搜索 Query。

    ``query_id`` 由关键词序号与年份确定性生成，便于日志追踪与结果归属。
    """

    query_id: str
    text: str
    task: TaskName
    keyword: str
    year: int | None = None


def _normalize_text(text: str) -> str:
    """去重键：忽略多余空白与大小写差异。"""
    return " ".join(text.split()).casefold()


def _ensure_query_length(text: str) -> None:
    if not 1 <= len(text) <= MAX_QUERY_LENGTH:
        raise ValueError(f"Query 长度必须在 1～{MAX_QUERY_LENGTH} 字符之间：{text!r}")


def build_historical_queries(
    date_range: DateRange | None = None,
) -> list[SearchQuery]:
    """任务 A：关键词 × 报告期年份 的 Query 矩阵。

    ``date_range`` 为空时自动按运行日期往前推两年计算。
    """
    if date_range is None:
        date_range = get_historical_date_range()

    queries: list[SearchQuery] = []
    seen: set[str] = set()

    for year in date_range.years:
        for index, keyword in enumerate(HISTORICAL_KEYWORDS, start=1):
            text = f"{keyword} {year}"
            _ensure_query_length(text)
            key = _normalize_text(text)
            if key in seen:
                continue
            seen.add(key)
            queries.append(
                SearchQuery(
                    query_id=f"hist-{year}-{index:02d}",
                    text=text,
                    task="historical",
                    keyword=keyword,
                    year=year,
                )
            )

    logger.info(
        "生成历史 Query：%d 条（关键词 %d × 年份 %s）",
        len(queries),
        len(HISTORICAL_KEYWORDS),
        date_range.years,
    )
    return queries


def build_daily_monitor_queries() -> list[SearchQuery]:
    """任务 B：最近 24 小时监控使用的 Query（不追加年份）。"""
    queries: list[SearchQuery] = []
    seen: set[str] = set()

    for index, keyword in enumerate(DAILY_KEYWORDS, start=1):
        _ensure_query_length(keyword)
        key = _normalize_text(keyword)
        if key in seen:
            continue
        seen.add(key)
        queries.append(
            SearchQuery(
                query_id=f"daily-{index:02d}",
                text=keyword,
                task="daily",
                keyword=keyword,
                year=None,
            )
        )

    logger.info("生成每日监控 Query：%d 条", len(queries))
    return queries


__all__ = [
    "DAILY_KEYWORDS",
    "HISTORICAL_KEYWORDS",
    "MAX_QUERY_LENGTH",
    "SearchQuery",
    "build_daily_monitor_queries",
    "build_historical_queries",
]
