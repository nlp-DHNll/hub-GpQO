# ESG Tender Intelligence Agent

ESG 招投标情报系统：历史公告采集与分析报告、每日公告监控、FastAPI 后端、Streamlit 前端、MCP Tools。

> 本系统基于**公开网络可检索信息**，非全量统计。金额严格区分预算金额、最高限价、中标金额与合同金额；
> 未披露金额一律为 `None`，不做推算。

---

## 1. 功能概览

| 功能 | 入口 |
|---|---|
| 历史采集（过去两年） | `run_historical_collection()` / `POST /tasks/history` |
| 历史统计与 Markdown 分析报告 | `generate_historical_analysis_report()` / `POST /tasks/analyze` |
| 每日监控（过去 24 小时，09:00 定时） | `run_daily_monitor()` / `POST /tasks/monitor` |
| 记录查询 / 统计 | `GET /records`、`GET /stats` |
| 报告读取 | `GET /reports/history`、`GET /reports/daily` |
| MCP Tools | `mcp_server/server.py` |

---

## 2. 环境变量

复制 `.env.example` 为 `.env` 并填写：

- `SILICONFLOW_API_KEY` / `SILICONFLOW_BASE_URL` / `DEEPSEEK_MODEL`
- `DEEPSEEK_SEARCH_API_KEY` / `DEEPSEEK_SEARCH_BASE_URL`
- 系统项：`APP_TIMEZONE=Asia/Shanghai`、`DATABASE_URL`、`SEARCH_CONCURRENCY`、`MONITOR_HOUR/MINUTE`

`.env` 已被 `.gitignore` 忽略，**不要提交、不要打印**。
注意：`docker compose config` 会把 env_file 的值展开显示，分享该输出前务必脱敏。

---

## 3. Docker（推荐）

```bash
docker compose up -d --build      # 构建并启动 api + streamlit
docker compose ps                 # 查看状态
docker compose logs -f api        # 跟踪后端日志
docker compose down               # 停止（不删除宿主机 data/ 与 output/）
```

| 服务 | 地址 | 说明 |
|---|---|---|
| api | http://localhost:8000 | FastAPI，健康检查 `/health`，接口文档 `/docs` |
| streamlit | http://localhost:8501 | 中文管理界面 |

持久化：宿主机 `./data` ↔ `/app/data`（SQLite），`./output` ↔ `/app/output`（报告）。

**单实例要求**：API 固定 `--workers 1`，APScheduler 在进程内单例；不要横向扩副本，否则每日监控会重复执行。

### MCP（stdio，按需运行）

```bash
docker compose --profile mcp run --rm -T mcp
```

MCP 客户端配置示例（宿主机本地运行）：

```json
{"command": "python", "args": ["-m", "mcp_server.server"], "cwd": "<项目根目录>"}
```

提供 Tools：`run_historical_collection`、`generate_historical_analysis`、`run_daily_monitor`、
`query_tender_records`、`get_analysis_report`、`get_daily_report`。

---

## 4. 本地运行（不使用 Docker）

```bash
pip install -r requirements.txt

# 后端
uvicorn api.main:app --host 127.0.0.1 --port 8000 --workers 1

# 前端（另开终端）
streamlit run streamlit_app/app.py

# 常驻调度（可选，替代后端进程内的调度器；二者不要同时跑）
python main.py
```

手动执行：

```bash
python main.py --run monitor
python main.py --run history
python main.py --run analyze
```

> 同一台机器上只应有一个调度器实例：要么 `python main.py`，要么 FastAPI 进程，不要两个同时运行。

---

## 5. 测试

```bash
pytest -q
```

---

## 6. 目录结构

```
api/            FastAPI 接口与后台任务
streamlit_app/  Streamlit 前端
mcp_server/     MCP Server（stdio）
services/       业务编排（采集 / 分析 / 监控 / 调度 / 提取）
scripts/        确定性脚本（日期、Query）
db/             SQLite 连接与仓库
models/         Pydantic 数据模型
config/         集中配置
prompts/        提取与分析提示词
data/           SQLite（挂载卷）
output/         报告产物（挂载卷）
```
