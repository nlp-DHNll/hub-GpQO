"""scripts/query_builder.py 的单元测试。"""

from __future__ import annotations

from datetime import date

from scripts.date_utils import DateRange, get_historical_date_range
from scripts.query_builder import (
    DAILY_KEYWORDS,
    HISTORICAL_KEYWORDS,
    MAX_QUERY_LENGTH,
    build_daily_monitor_queries,
    build_historical_queries,
)


def test_historical_queries_cover_every_keyword_and_year() -> None:
    date_range = DateRange(start=date(2024, 11, 26), end=date(2026, 11, 26))
    queries = build_historical_queries(date_range)

    assert len(queries) == len(HISTORICAL_KEYWORDS) * 3
    for keyword in HISTORICAL_KEYWORDS:
        for year in (2024, 2025, 2026):
            assert any(q.keyword == keyword and q.year == year for q in queries)
            assert any(q.text == f"{keyword} {year}" for q in queries)


def test_historical_years_come_from_range() -> None:
    date_range = DateRange(start=date(2020, 1, 1), end=date(2022, 6, 30))
    queries = build_historical_queries(date_range)

    years = {q.year for q in queries}
    assert years == {2020, 2021, 2022}
    assert len(queries) == len(HISTORICAL_KEYWORDS) * 3


def test_historical_queries_have_no_duplicates() -> None:
    queries = build_historical_queries(
        DateRange(start=date(2024, 1, 1), end=date(2026, 12, 31))
    )
    texts = [q.text for q in queries]
    ids = [q.query_id for q in queries]

    assert len(texts) == len(set(texts))
    assert len(ids) == len(set(ids))


def test_historical_queries_within_single_year() -> None:
    queries = build_historical_queries(
        DateRange(start=date(2025, 1, 1), end=date(2025, 12, 31))
    )
    assert len(queries) == len(HISTORICAL_KEYWORDS)
    assert {q.year for q in queries} == {2025}


def test_historical_query_defaults_to_runtime_range() -> None:
    queries = build_historical_queries()
    expected_years = set(get_historical_date_range().years)
    assert {q.year for q in queries} == expected_years
    assert len(queries) == len(HISTORICAL_KEYWORDS) * len(expected_years)


def test_query_ids_are_deterministic() -> None:
    first = build_historical_queries(DateRange(start=date(2024, 1, 1), end=date(2025, 12, 31)))
    second = build_historical_queries(DateRange(start=date(2024, 1, 1), end=date(2025, 12, 31)))
    assert first == second
    assert first[0].query_id == "hist-2024-01"


def test_query_text_length_within_api_limit() -> None:
    for query in build_historical_queries() + build_daily_monitor_queries():
        assert 1 <= len(query.text) <= MAX_QUERY_LENGTH


def test_daily_queries_are_not_year_based() -> None:
    queries = build_daily_monitor_queries()

    assert len(queries) == len(DAILY_KEYWORDS)
    assert [q.text for q in queries] == list(DAILY_KEYWORDS)
    assert all(q.year is None for q in queries)
    assert all(q.task == "daily" for q in queries)
    assert len({q.query_id for q in queries}) == len(queries)
    assert queries[0].query_id == "daily-01"


def test_daily_and_historical_tasks_are_distinguished() -> None:
    assert all(q.task == "historical" for q in build_historical_queries())
    assert all(q.task == "daily" for q in build_daily_monitor_queries())


def test_keywords_match_requirement() -> None:
    assert HISTORICAL_KEYWORDS == (
        "ESG 招标 中标",
        "双碳 招标 中标公告",
        "可持续发展 项目 中标结果",
        "碳达峰 碳中和 招标 预算 中标金额",
        "绿色低碳 咨询服务 中标 公告",
        "碳核算 碳盘查 碳资产 招标 中标",
    )
    assert DAILY_KEYWORDS == (
        "ESG 招标公告",
        "双碳 招标公告",
        "可持续发展 招标公告",
        "碳达峰 碳中和 招标",
        "绿色低碳 采购 招标公告",
    )
