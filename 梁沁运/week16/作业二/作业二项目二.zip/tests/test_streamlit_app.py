"""streamlit_app/app.py 的导入与结构测试（不启动 Streamlit 服务）。"""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

import pytest


def test_streamlit_app_imports_without_side_effects() -> None:
    module = importlib.import_module("streamlit_app.app")
    importlib.reload(module)

    assert callable(module.main)
    assert set(module.PAGES) == {"仪表盘", "历史数据", "每日监控", "手动任务"}
    assert module.API_BASE_URL.startswith("http://") or module.API_BASE_URL.startswith(
        "https://"
    )


def test_default_api_base_url() -> None:
    module = importlib.import_module("streamlit_app.app")
    assert module.API_BASE_URL == "http://127.0.0.1:8000"


def test_api_helpers_raise_clear_error_when_backend_down(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module = importlib.import_module("streamlit_app.app")

    import httpx

    def broken_get(*_args: Any, **_kwargs: Any) -> Any:
        raise httpx.ConnectError("connection refused")

    monkeypatch.setattr(httpx, "get", broken_get)
    with pytest.raises(RuntimeError) as exc_info:
        module.api_get("/health")
    assert "无法连接后端 API" in str(exc_info.value)


def test_error_detail_extracts_json_detail() -> None:
    module = importlib.import_module("streamlit_app.app")
    import httpx

    response = httpx.Response(409, json={"detail": "monitor 任务正在执行"})
    message = module._error_detail(response)
    assert "409" in message
    assert "任务正在执行" in message


def test_streamlit_entrypoint_file_exists() -> None:
    path = Path("streamlit_app/app.py")
    assert path.exists()
    text = path.read_text(encoding="utf-8")
    assert "st.set_page_config" in text
    assert "API_BASE_URL" in text
