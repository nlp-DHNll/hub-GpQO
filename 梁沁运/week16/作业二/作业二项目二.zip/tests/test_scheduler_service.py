"""services/scheduler_service.py 与应用入口 main.py 的单元测试（不调用真实 API）。"""

from __future__ import annotations

import asyncio
import importlib
import logging
from datetime import datetime
from types import SimpleNamespace
from typing import Any

import pytest
import pytest_asyncio

from config.settings import Settings
from services import scheduler_service as scheduler_module
from services.scheduler_service import (
    JOB_ID,
    MISFIRE_GRACE_SECONDS,
    MonitorScheduler,
    start_scheduler,
    shutdown_scheduler,
)


def make_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "app_timezone": "Asia/Shanghai",
        "monitor_hour": 9,
        "monitor_minute": 0,
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


def fake_report() -> SimpleNamespace:
    return SimpleNamespace(
        stats=SimpleNamespace(inserted_count=2, pending_verification_count=1)
    )


@pytest_asyncio.fixture(autouse=True)
async def clean_singleton() -> Any:
    """每个测试前后清空模块级调度器单例（在事件循环内关闭，避免 loop 已关闭）。"""
    shutdown_scheduler()
    yield
    shutdown_scheduler()


# ---------------------------------------------------------------------------
# 1. 时区
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_scheduler_uses_asia_shanghai() -> None:
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())
    scheduler.start()
    try:
        assert str(scheduler.scheduler.timezone) == "Asia/Shanghai"
        assert scheduler.timezone.key == "Asia/Shanghai"

        job = scheduler.get_jobs()[0]
        trigger = job.trigger
        # CronTrigger 的时区与配置一致
        assert str(trigger.timezone) == "Asia/Shanghai"
    finally:
        scheduler.shutdown()


def fake_runner(calls: list[int] | None = None):
    calls = calls if calls is not None else []

    async def runner() -> Any:
        calls.append(1)
        return fake_report()

    return runner


# ---------------------------------------------------------------------------
# 2. 每天 09:00
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_job_scheduled_daily_at_0900() -> None:
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())
    scheduler.start()
    try:
        jobs = scheduler.get_jobs()
        assert len(jobs) == 1
        job = jobs[0]
        assert job.id == JOB_ID

        fields = {field.name: str(field) for field in job.trigger.fields}
        assert fields["hour"] == "9"
        assert fields["minute"] == "0"
        assert fields["day"] == "*"
        assert fields["month"] == "*"

        assert job.max_instances == 1
        assert job.coalesce is True
        assert job.misfire_grace_time == MISFIRE_GRACE_SECONDS
    finally:
        scheduler.shutdown()


@pytest.mark.asyncio
async def test_job_time_follows_settings() -> None:
    scheduler = MonitorScheduler(
        settings=make_settings(monitor_hour=7, monitor_minute=30), job_runner=fake_runner()
    )
    scheduler.start()
    try:
        fields = {field.name: str(field) for field in scheduler.get_jobs()[0].trigger.fields}
        assert fields["hour"] == "7"
        assert fields["minute"] == "30"
    finally:
        scheduler.shutdown()


# ---------------------------------------------------------------------------
# 3. 单实例
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_repeated_start_keeps_single_scheduler() -> None:
    first = start_scheduler(make_settings(), fake_runner())
    second = start_scheduler(make_settings(), fake_runner())

    assert first is second
    assert scheduler_module.get_scheduler() is first
    assert len(first.get_jobs()) == 1

    first.start()  # 再次调用 start 也不应重复注册
    assert len(first.get_jobs()) == 1


@pytest.mark.asyncio
async def test_start_is_idempotent_within_instance() -> None:
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())
    scheduler.start()
    scheduler.start()
    try:
        assert len(scheduler.get_jobs()) == 1
    finally:
        scheduler.shutdown()


# ---------------------------------------------------------------------------
# 4. 关闭
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_shutdown_is_safe_and_releases_singleton() -> None:
    scheduler = start_scheduler(make_settings(), fake_runner())
    assert scheduler.is_running is True

    shutdown_scheduler()
    assert scheduler.is_running is False
    assert scheduler_module.get_scheduler() is None

    shutdown_scheduler()  # 重复关闭不报错


@pytest.mark.asyncio
async def test_shutdown_before_start_is_safe() -> None:
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())
    scheduler.shutdown()  # 尚未 start
    assert scheduler.is_running is False


# ---------------------------------------------------------------------------
# 5. 启动不会自动执行历史采集
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_does_not_run_jobs_immediately() -> None:
    calls: list[str] = []

    async def runner() -> Any:
        calls.append("run")
        return fake_report()

    scheduler = start_scheduler(make_settings(), runner)
    try:
        await asyncio.sleep(0.05)
        assert calls == []                              # 启动瞬间不执行任何任务
        assert [job.id for job in scheduler.get_jobs()] == [JOB_ID]  # 只有监控任务
    finally:
        shutdown_scheduler()


def test_main_import_has_no_side_effects() -> None:
    """导入 main 模块不应启动调度器，也不应执行历史采集/分析。"""
    shutdown_scheduler()
    module = importlib.import_module("main")
    importlib.reload(module)

    assert scheduler_module.get_scheduler() is None
    parser = module.build_parser()
    args = parser.parse_args([])
    assert args.run is None
    args = parser.parse_args(["--run", "monitor"])
    assert args.run == "monitor"
    assert module.MANUAL_CHOICES == ("monitor", "history", "analyze")


# ---------------------------------------------------------------------------
# 6. 任务异常被记录且不影响调度器
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_job_exception_logged_and_scheduler_keeps_running(
    caplog: pytest.LogCaptureFixture,
) -> None:
    async def broken_runner() -> Any:
        raise RuntimeError("monitor exploded")

    caplog.set_level(logging.INFO)
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=broken_runner)
    scheduler.start()
    try:
        await scheduler.execute_job()  # 不应抛出
        assert scheduler.is_running is True
        assert len(scheduler.get_jobs()) == 1
        assert "每日监控任务失败" in caplog.text
        assert "RuntimeError" in caplog.text or "monitor exploded" in caplog.text
    finally:
        scheduler.shutdown()


@pytest.mark.asyncio
async def test_job_success_logs_start_end_and_duration(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.INFO)
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())

    await scheduler.execute_job()

    assert "每日监控任务开始" in caplog.text
    assert "每日监控任务完成" in caplog.text
    assert "耗时" in caplog.text


@pytest.mark.asyncio
async def test_scheduler_start_and_shutdown_are_logged(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.INFO)
    scheduler = MonitorScheduler(settings=make_settings(), job_runner=fake_runner())
    scheduler.start()
    scheduler.shutdown()

    assert "调度器已启动" in caplog.text
    assert "调度器已关闭" in caplog.text
