"""scripts/date_utils.py 的单元测试。"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from scripts.date_utils import (
    DAILY_LOOKBACK_HOURS,
    HISTORICAL_LOOKBACK_YEARS,
    DateRange,
    TimeRange,
    get_current_time,
    get_historical_date_range,
    get_last_24_hours_range,
    shift_years_back,
)

TZ = ZoneInfo("Asia/Shanghai")


def test_historical_range_is_two_years_back() -> None:
    now = datetime(2026, 11, 26, 9, 0, tzinfo=TZ)
    date_range = get_historical_date_range(now)

    assert date_range.start == date(2024, 11, 26)
    assert date_range.end == date(2026, 11, 26)
    assert HISTORICAL_LOOKBACK_YEARS == 2


def test_historical_end_is_run_date() -> None:
    now = datetime(2026, 3, 15, 23, 59, tzinfo=TZ)
    date_range = get_historical_date_range(now)
    assert date_range.end == now.date()


def test_historical_range_is_dynamic_not_hardcoded() -> None:
    """同一函数在不同"当前时间"下应产出不同年份，说明年份未写死。"""
    first = get_historical_date_range(datetime(2030, 5, 1, 8, 0, tzinfo=TZ))
    second = get_historical_date_range(datetime(2033, 5, 1, 8, 0, tzinfo=TZ))

    assert first.start == date(2028, 5, 1)
    assert second.start == date(2031, 5, 1)
    assert first.years == [2028, 2029, 2030]
    assert second.years == [2031, 2032, 2033]


def test_date_utils_source_has_no_hardcoded_year() -> None:
    """源码中不应出现 20xx 这样的具体年份字面量。"""
    source = Path("scripts/date_utils.py").read_text(encoding="utf-8")
    code_only = "\n".join(
        line for line in source.splitlines() if not line.lstrip().startswith("#")
    )
    assert not re.search(r"\b20\d{2}\b", code_only), "date_utils.py 出现写死年份"


def test_historical_range_handles_leap_day() -> None:
    now = datetime(2024, 2, 29, 10, 0, tzinfo=TZ)
    date_range = get_historical_date_range(now)
    assert date_range.start == date(2022, 2, 28)
    assert date_range.end == date(2024, 2, 29)


def test_shift_years_back_regular_and_leap() -> None:
    assert shift_years_back(date(2026, 11, 26), 2) == date(2024, 11, 26)
    assert shift_years_back(date(2024, 2, 29), 1) == date(2023, 2, 28)
    with pytest.raises(ValueError):
        shift_years_back(date(2026, 1, 1), -1)


def test_last_24_hours_window() -> None:
    now = datetime(2026, 11, 26, 9, 0, tzinfo=TZ)
    window = get_last_24_hours_range(now)

    assert window.end == now
    assert window.start == now - timedelta(hours=24)
    assert window.duration_hours == 24.0
    assert DAILY_LOOKBACK_HOURS == 24
    assert window.start.tzinfo is not None and window.end.tzinfo is not None


def test_window_contains_boundaries() -> None:
    now = datetime(2026, 11, 26, 9, 0, tzinfo=TZ)
    window = get_last_24_hours_range(now)
    assert window.contains(now)
    assert window.contains(window.start)
    assert not window.contains(window.start - timedelta(seconds=1))


def test_naive_datetime_rejected() -> None:
    with pytest.raises(ValueError):
        get_historical_date_range(datetime(2026, 11, 26, 9, 0))
    with pytest.raises(ValueError):
        get_last_24_hours_range(datetime(2026, 11, 26, 9, 0))


def test_default_timezone_comes_from_settings() -> None:
    now = get_current_time()
    assert now.tzinfo is not None
    assert now.utcoffset() == timedelta(hours=8)  # Asia/Shanghai
    assert get_historical_date_range().end == now.date()


def test_invalid_ranges_raise() -> None:
    with pytest.raises(ValueError):
        DateRange(start=date(2026, 1, 2), end=date(2026, 1, 1))
    with pytest.raises(ValueError):
        TimeRange(
            start=datetime(2026, 1, 1, 10, 0, tzinfo=TZ),
            end=datetime(2026, 1, 1, 9, 0, tzinfo=TZ),
        )
    with pytest.raises(ValueError):
        TimeRange(
            start=datetime(2026, 1, 1, 10, 0),
            end=datetime(2026, 1, 1, 11, 0),
        )


def test_years_and_contains() -> None:
    date_range = DateRange(start=date(2024, 11, 26), end=date(2026, 1, 5))
    assert date_range.years == [2024, 2025, 2026]
    assert date_range.contains(date(2025, 6, 1))
    assert not date_range.contains(date(2024, 11, 25))
    assert date_range.describe() == "2024-11-26 ~ 2026-01-05"
