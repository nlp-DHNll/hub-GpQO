"""db/database.py 与 db/repository.py 的单元测试（临时数据库，不使用 data/esg_tender.db）。"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import pytest

from db.database import TendersDatabase, normalize_source_url
from db.repository import (
    DuplicateRecordError,
    SaveOutcome,
    TenderRepository,
)
from models.tender import AnnouncementType, Industry, TenderRecord

SOURCE_URL = "http://www.chnenergybidding.com.cn/bidweb//001/001002/001002003/20260623/530792dd-09dc-4910-b6de-2de3e7ea79d1.html"


@pytest.fixture
def repo(tmp_path: Path) -> TenderRepository:
    database = TendersDatabase(path=tmp_path / "data" / "test_tender.db")
    database.initialize()
    return TenderRepository(
        database,
        clock=lambda: datetime(2026, 11, 26, 9, 0),
    )


def make_record(**overrides: Any) -> TenderRecord:
    payload: dict[str, Any] = {
        "project_name": "中国神华ESG治理体系优化及报告编制咨询服务公开招标",
        "announcement_type": "招标公告",
        "publish_date": "2026-06-23",
        "region": "北京市东城区",
        "industry": "ESG 咨询 / 评级 / 报告编制",
        "buyer": "中国神华能源股份有限公司",
        "winning_supplier": None,
        "project_code": "CEZB260105010",
        "budget_amount": None,
        "ceiling_price": None,
        "bid_amount": None,
        "contract_amount": None,
        "amount_currency": "CNY",
        "source_url": SOURCE_URL,
        "source_title": "中国神华ESG治理体系优化及报告编制咨询服务公开招标项目招标公告",
        "summary": "ESG 治理体系优化与报告编制咨询服务",
        "confidence": 0.88,
        "remarks": "正文未披露金额",
    }
    payload.update(overrides)
    return TenderRecord.model_validate(payload)


# ---------------------------------------------------------------------------
# 规范化与初始化
# ---------------------------------------------------------------------------


def test_normalize_source_url_rules() -> None:
    # scheme / host 大小写统一，移除 fragment
    assert (
        normalize_source_url("  HTTP://WWW.Example.COM/Path/A.html#section  ")
        == "http://www.example.com/Path/A.html"
    )
    # 查询参数保留、顺序不变
    assert (
        normalize_source_url("https://example.com/a?b=2&a=1")
        == "https://example.com/a?b=2&a=1"
    )
    # 路径中的重复斜杠不合并
    assert normalize_source_url("https://example.com//a///b") == "https://example.com//a///b"
    # 末尾斜杠不统一
    assert normalize_source_url("https://example.com/a/") == "https://example.com/a/"
    assert normalize_source_url("https://example.com/a") != normalize_source_url(
        "https://example.com/a/"
    )
    with pytest.raises(ValueError):
        normalize_source_url("   ")


def test_database_initialize_creates_file_and_table(tmp_path: Path) -> None:
    path = tmp_path / "nested" / "dir" / "esg.db"
    database = TendersDatabase(path=path)

    info = database.initialize()

    assert path.exists()
    assert info.path == path
    assert info.exists is True
    assert database.table_exists("tender_records")
    assert database.count() == 0


def test_initialize_is_idempotent(tmp_path: Path) -> None:
    database = TendersDatabase(path=tmp_path / "esg.db")
    database.initialize()
    database.initialize()
    assert database.count() == 0


def test_schema_contains_all_record_fields(tmp_path: Path) -> None:
    path = tmp_path / "esg.db"
    database = TendersDatabase(path=path)
    database.initialize()

    with sqlite3.connect(path) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(tender_records)")}

    expected = {
        "id",
        "project_name",
        "announcement_type",
        "publish_date",
        "region",
        "industry",
        "buyer",
        "winning_supplier",
        "project_code",
        "budget_amount",
        "ceiling_price",
        "bid_amount",
        "contract_amount",
        "amount_currency",
        "source_url",
        "normalized_url",
        "source_title",
        "summary",
        "confidence",
        "remarks",
        "created_at",
    }
    assert columns == expected


def test_normalized_url_has_unique_constraint(tmp_path: Path) -> None:
    path = tmp_path / "esg.db"
    database = TendersDatabase(path=path)
    database.initialize()

    with sqlite3.connect(path) as conn:
        indexes = conn.execute("PRAGMA index_list(tender_records)").fetchall()
        unique_indexes = [row for row in indexes if row[2] == 1]
        unique_columns = set()
        for row in unique_indexes:
            for info in conn.execute(f"PRAGMA index_info('{row[1]}')"):
                unique_columns.add(info[2])
    assert "normalized_url" in unique_columns


# ---------------------------------------------------------------------------
# 入库与查询
# ---------------------------------------------------------------------------


def test_save_and_query_by_id(repo: TenderRepository) -> None:
    record = make_record()

    result = repo.save_record(record)

    assert result.outcome is SaveOutcome.INSERTED
    assert result.inserted is True
    assert result.record_id > 0
    assert result.normalized_url == SOURCE_URL

    loaded = repo.get_by_id(result.record_id)
    assert loaded is not None
    assert loaded.project_name == record.project_name
    assert loaded.buyer == record.buyer
    assert loaded.project_code == record.project_code
    assert loaded.source_title == record.source_title
    assert loaded.summary == record.summary
    assert loaded.remarks == record.remarks
    assert loaded.confidence == pytest.approx(record.confidence)
    assert str(loaded.source_url) == SOURCE_URL


def test_query_by_source_url(repo: TenderRepository) -> None:
    repo.save_record(make_record())

    loaded = repo.get_by_source_url(SOURCE_URL)
    assert loaded is not None
    assert loaded.project_code == "CEZB260105010"

    # 规范化后等价的 URL（host 大小写 + fragment + 首尾空格）也能查到
    variant = (
        "HTTP://WWW.CHNENERGYBIDDING.COM.CN"
        + SOURCE_URL.split("chnenergybidding.com.cn", 1)[1]
        + "#top"
    )
    variant = f"  {variant}  "
    assert repo.get_by_source_url(variant) is not None
    assert repo.exists_by_url(variant) is True


def test_missing_record_returns_none(repo: TenderRepository) -> None:
    assert repo.get_by_id(9999) is None
    assert repo.get_by_source_url(SOURCE_URL) is None
    assert repo.exists_by_url(SOURCE_URL) is False


def test_get_detail_by_id_exposes_metadata(repo: TenderRepository) -> None:
    result = repo.save_record(make_record())

    detail = repo.get_detail_by_id(result.record_id)
    assert detail is not None
    assert detail["id"] == result.record_id
    assert detail["normalized_url"] == SOURCE_URL
    assert detail["created_at"] == "2026-11-26T09:00:00"
    assert detail["budget_amount"] is None


def test_list_records_with_pagination(repo: TenderRepository) -> None:
    for index in range(3):
        repo.save_record(
            make_record(
                project_name=f"项目 {index}",
                source_url=f"https://example.com/notice/{index}.html",
                project_code=f"CODE-{index}",
            )
        )

    first_page = repo.list_records(limit=2, offset=0)
    second_page = repo.list_records(limit=2, offset=2)

    assert [item.project_name for item in first_page] == ["项目 0", "项目 1"]
    assert [item.project_name for item in second_page] == ["项目 2"]
    assert repo.count() == 3

    with pytest.raises(ValueError):
        repo.list_records(limit=0)
    with pytest.raises(ValueError):
        repo.list_records(offset=-1)


# ---------------------------------------------------------------------------
# 去重
# ---------------------------------------------------------------------------


def test_duplicate_url_not_inserted_again(repo: TenderRepository) -> None:
    first = repo.save_record(make_record())
    second = repo.save_record(make_record())

    assert first.outcome is SaveOutcome.INSERTED
    assert second.outcome is SaveOutcome.DUPLICATE
    assert second.duplicate is True
    assert second.record_id == first.record_id
    assert repo.count() == 1


def test_duplicate_does_not_overwrite_existing(repo: TenderRepository) -> None:
    result = repo.save_record(make_record(summary="原始摘要", confidence=0.88))
    repo.save_record(make_record(summary="试图覆盖的摘要", confidence=0.1))

    loaded = repo.get_by_id(result.record_id)
    assert loaded is not None
    assert loaded.summary == "原始摘要"
    assert loaded.confidence == pytest.approx(0.88)


def test_url_variants_detected_as_duplicate(repo: TenderRepository) -> None:
    repo.save_record(make_record())

    upper_host = "HTTP://WWW.CHNENERGYBIDDING.COM.CN" + SOURCE_URL.split(
        "chnenergybidding.com.cn", 1
    )[1]
    with_fragment = SOURCE_URL + "#notice-top"
    with_spaces = f"   {SOURCE_URL}   "

    for variant in (upper_host, with_fragment, with_spaces):
        outcome = repo.save_record(make_record(source_url=variant))
        assert outcome.outcome is SaveOutcome.DUPLICATE, variant

    assert repo.count() == 1


def test_query_parameter_difference_is_not_duplicate(repo: TenderRepository) -> None:
    repo.save_record(make_record(source_url="https://example.com/notice?id=1"))
    result = repo.save_record(make_record(source_url="https://example.com/notice?id=2"))

    assert result.outcome is SaveOutcome.INSERTED
    assert repo.count() == 2


def test_same_project_code_different_announcements_both_saved(repo: TenderRepository) -> None:
    tender = make_record(
        announcement_type="招标公告",
        source_url="https://example.com/tender/1.html",
        project_code="CEZB260105010",
    )
    award = make_record(
        announcement_type="中标公告",
        source_url="https://example.com/award/1.html",
        project_code="CEZB260105010",
        winning_supplier="某咨询有限公司",
        bid_amount="2880000",
    )
    correction = make_record(
        announcement_type="更正公告",
        source_url="https://example.com/correction/1.html",
        project_code="CEZB260105010",
    )

    results = repo.save_records([tender, award, correction])

    assert all(item.outcome is SaveOutcome.INSERTED for item in results)
    assert repo.count() == 3

    by_code = repo.find_by_project_code("CEZB260105010")
    assert {item.announcement_type for item in by_code} == {
        AnnouncementType.TENDER,
        AnnouncementType.AWARD,
        AnnouncementType.CORRECTION,
    }


def test_strict_mode_raises_on_duplicate(repo: TenderRepository) -> None:
    first = repo.save_record(make_record())

    with pytest.raises(DuplicateRecordError) as exc_info:
        repo.save_record(make_record(), strict=True)

    assert exc_info.value.existing_id == first.record_id
    assert repo.count() == 1


# ---------------------------------------------------------------------------
# 金额、日期、枚举
# ---------------------------------------------------------------------------


def test_decimal_precision_preserved(repo: TenderRepository) -> None:
    budget = Decimal("3000000.50")
    bid = Decimal("123456789012345.6789012")
    record = make_record(budget_amount=budget, bid_amount=bid)

    result = repo.save_record(record)
    loaded = repo.get_by_id(result.record_id)

    assert loaded is not None
    assert isinstance(loaded.budget_amount, Decimal)
    assert isinstance(loaded.bid_amount, Decimal)
    assert loaded.budget_amount == budget
    assert loaded.bid_amount == bid
    assert str(loaded.budget_amount) == "3000000.50"
    assert str(loaded.bid_amount) == "123456789012345.6789012"
    assert loaded.budget_amount != loaded.bid_amount


def test_amounts_stored_as_text(repo: TenderRepository) -> None:
    result = repo.save_record(make_record(budget_amount="3000000", bid_amount="2880000.25"))

    with repo.database.connect() as conn:
        row = conn.execute(
            "SELECT budget_amount, bid_amount FROM tender_records WHERE id = ?",
            (result.record_id,),
        ).fetchone()

    assert isinstance(row["budget_amount"], str)
    assert isinstance(row["bid_amount"], str)
    assert row["budget_amount"] == "3000000"
    assert row["bid_amount"] == "2880000.25"


def test_none_amounts_stay_none(repo: TenderRepository) -> None:
    result = repo.save_record(make_record())

    loaded = repo.get_by_id(result.record_id)
    assert loaded is not None
    assert loaded.budget_amount is None
    assert loaded.ceiling_price is None
    assert loaded.bid_amount is None
    assert loaded.contract_amount is None

    with repo.database.connect() as conn:
        row = conn.execute(
            "SELECT budget_amount, ceiling_price, bid_amount, contract_amount "
            "FROM tender_records WHERE id = ?",
            (result.record_id,),
        ).fetchone()
    assert row["budget_amount"] is None
    assert row["bid_amount"] is None


def test_budget_and_bid_are_not_confused(repo: TenderRepository) -> None:
    result = repo.save_record(
        make_record(
            budget_amount="3500000",
            ceiling_price="3600000",
            bid_amount="3420000",
            contract_amount="3400000",
        )
    )
    loaded = repo.get_by_id(result.record_id)

    assert loaded is not None
    assert loaded.budget_amount == Decimal("3500000")
    assert loaded.ceiling_price == Decimal("3600000")
    assert loaded.bid_amount == Decimal("3420000")
    assert loaded.contract_amount == Decimal("3400000")


def test_date_and_enum_roundtrip(repo: TenderRepository) -> None:
    result = repo.save_record(
        make_record(
            publish_date="2026-06-23",
            announcement_type="中标公告",
            industry="碳管理",
        )
    )
    loaded = repo.get_by_id(result.record_id)

    assert loaded is not None
    assert loaded.publish_date == date(2026, 6, 23)
    assert isinstance(loaded.publish_date, date)
    assert loaded.announcement_type is AnnouncementType.AWARD
    assert loaded.industry is Industry.CARBON_MANAGEMENT
    assert loaded.amount_currency == "CNY"


def test_null_publish_date_roundtrip(repo: TenderRepository) -> None:
    result = repo.save_record(make_record(publish_date=None))
    loaded = repo.get_by_id(result.record_id)
    assert loaded is not None
    assert loaded.publish_date is None
