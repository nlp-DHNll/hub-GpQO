"""api/main.py 的接口测试（Mock 业务服务，不调用真实 API）。"""

from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

import api.main as api_module
from api.main import app, get_output_dir, get_repository
from db.database import TendersDatabase
from db.repository import TenderRepository
from models.tender import TenderRecord
from services import scheduler_service as scheduler_module


def make_record(index: int, **overrides: Any) -> TenderRecord:
    payload: dict[str, Any] = {
        "project_name": f"ESG 咨询服务项目 {index}",
        "announcement_type": "中标公告",
        "publish_date": "2025-06-01",
        "region": "上海市",
        "industry": "ESG 咨询 / 评级 / 报告编制",
        "buyer": f"某能源股份有限公司 {index}",
        "confidence": 0.8,
        "source_url": f"https://example.com/n/{index}.html",
    }
    payload.update(overrides)
    return TenderRecord.model_validate(payload)


@pytest.fixture
def client(tmp_path: Path) -> Any:
    database = TendersDatabase(path=tmp_path / "api.db")
    database.initialize()
    repo = TenderRepository(database)
    for index in (1, 2, 3):
        repo.save_record(make_record(index))
    repo.save_record(
        make_record(4, announcement_type="招标公告", bid_amount="1200000", industry="碳管理")
    )

    api_module._tasks.clear()
    api_module._running.clear()

    app.dependency_overrides[get_repository] = lambda: repo
    app.dependency_overrides[get_output_dir] = lambda: tmp_path

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()
    api_module._tasks.clear()
    api_module._running.clear()


def fake_outcome() -> SimpleNamespace:
    return SimpleNamespace(
        as_dict=lambda: {
            "stats": {"inserted_count": 1, "pending_verification_count": 0},
            "report_path": "output/x.md",
        }
    )


# ---------------------------------------------------------------------------
# 健康检查与基础接口
# ---------------------------------------------------------------------------


def test_health(client: TestClient) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["timezone"] == "Asia/Shanghai"


def test_records_pagination_and_filters(client: TestClient) -> None:
    response = client.get("/records", params={"limit": 2, "offset": 0})
    body = response.json()
    assert body["total"] == 4
    assert len(body["items"]) == 2

    page2 = client.get("/records", params={"limit": 2, "offset": 2}).json()
    assert len(page2["items"]) == 2
    assert page2["items"][0]["project_name"] != body["items"][0]["project_name"]

    tender = client.get("/records", params={"announcement_type": "招标公告"}).json()
    assert tender["total"] == 1
    assert float(tender["items"][0]["bid_amount"]) == 1_200_000.0

    carbon = client.get("/records", params={"industry": "碳管理"}).json()
    assert carbon["total"] == 1

    keyword = client.get("/records", params={"keyword": "项目 2"}).json()
    assert keyword["total"] == 1

    invalid = client.get("/records", params={"limit": 0})
    assert invalid.status_code == 422


def test_stats(client: TestClient) -> None:
    body = client.get("/stats").json()
    assert body["total"] == 4
    assert body["award_count"] == 3
    assert body["tender_count"] == 1
    assert body["bid_disclosed_count"] == 1
    assert body["region_covered_count"] == 4
    assert body["industries"]["碳管理"] == 1
    assert body["last_monitor"] is None


def test_reports_404_when_missing(client: TestClient) -> None:
    assert client.get("/reports/history").status_code == 404
    assert client.get("/reports/daily").status_code == 404


def test_reports_return_markdown(client: TestClient, tmp_path: Path) -> None:
    (tmp_path / "historical_analysis_report.md").write_text("# 历史报告", encoding="utf-8")
    (tmp_path / "daily_monitor_report.md").write_text("# 日报", encoding="utf-8")

    history = client.get("/reports/history").json()
    daily = client.get("/reports/daily").json()
    assert history["markdown"] == "# 历史报告"
    assert daily["filename"] == "daily_monitor_report.md"


# ---------------------------------------------------------------------------
# 任务
# ---------------------------------------------------------------------------


def test_task_submit_and_status(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_runner() -> Any:
        await asyncio.sleep(0)
        return fake_outcome()

    monkeypatch.setitem(api_module.TASK_RUNNERS, "monitor", fake_runner)

    response = client.post("/tasks/monitor")
    assert response.status_code == 202
    task_id = response.json()["task_id"]

    for _ in range(20):
        state = client.get(f"/tasks/{task_id}").json()
        if state["status"] != "running":
            break
    assert state["status"] == "success"
    assert state["result"]["stats"]["inserted_count"] == 1
    assert state["finished_at"] is not None

    stats_body = client.get("/stats").json()
    assert stats_body["last_monitor"]["task_id"] == task_id


def test_task_failure_is_recorded(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    async def broken_runner() -> Any:
        await asyncio.sleep(0)
        raise RuntimeError("boom")

    monkeypatch.setitem(api_module.TASK_RUNNERS, "history", broken_runner)

    task_id = client.post("/tasks/history").json()["task_id"]
    for _ in range(20):
        state = client.get(f"/tasks/{task_id}").json()
        if state["status"] != "running":
            break
    assert state["status"] == "failed"
    assert "RuntimeError" in state["error"]


def test_duplicate_task_rejected(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    started = asyncio.Event()
    release = asyncio.Event()

    async def slow_runner() -> Any:
        started.set()
        await release.wait()
        return fake_outcome()

    monkeypatch.setitem(api_module.TASK_RUNNERS, "analyze", slow_runner)

    first = client.post("/tasks/analyze")
    assert first.status_code == 202

    second = client.post("/tasks/analyze")
    assert second.status_code == 409
    assert "正在执行" in second.json()["detail"]

    release.set()
    for _ in range(20):
        state = client.get(f"/tasks/{first.json()['task_id']}").json()
        if state["status"] != "running":
            break
    # 任务结束后可以再次提交
    assert client.post("/tasks/analyze").status_code == 202


def test_unknown_task_returns_404(client: TestClient) -> None:
    assert client.get("/tasks/not-exist").status_code == 404


def test_task_list(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_runner() -> Any:
        return fake_outcome()

    monkeypatch.setitem(api_module.TASK_RUNNERS, "monitor", fake_runner)
    client.post("/tasks/monitor")
    for _ in range(20):
        if not any(t["status"] == "running" for t in client.get("/tasks").json()["items"]):
            break
    items = client.get("/tasks").json()["items"]
    assert items and items[0]["task_type"] == "monitor"


# ---------------------------------------------------------------------------
# 调度器生命周期
# ---------------------------------------------------------------------------


def test_lifespan_starts_and_stops_scheduler(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []

    class FakeScheduler:
        is_running = True

    def fake_start(*_args: Any, **_kwargs: Any) -> FakeScheduler:
        calls.append("start")
        return FakeScheduler()

    def fake_shutdown() -> None:
        calls.append("shutdown")

    monkeypatch.setattr(api_module, "start_scheduler", fake_start)
    monkeypatch.setattr(api_module, "shutdown_scheduler", fake_shutdown)

    with TestClient(app):
        assert calls == ["start"]
    assert calls == ["start", "shutdown"]


def test_existing_scheduler_module_untouched_after_client(tmp_path: Path) -> None:
    """接口测试结束后不应残留调度器单例。"""
    assert scheduler_module.get_scheduler() is None
