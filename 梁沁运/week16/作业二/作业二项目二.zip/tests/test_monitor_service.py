"""services/monitor_service.py 的单元测试（Mock Search/Fetch/Extraction，不调用真实 API）。"""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import httpx
import pytest
from pydantic import SecretStr

from config.settings import Settings
from db.database import TendersDatabase
from db.repository import TenderRepository
from models.tender import TenderRecord
from scripts.date_utils import TimeRange, get_last_24_hours_range
from scripts.query_builder import DAILY_KEYWORDS
from services.extraction_service import RecordValidationError
from services.monitor_service import (
    AI_SUMMARY_CHAR_LIMIT,
    MonitorStats,
    evaluate_announcement,
    extract_publish_datetime,
    render_daily_markdown,
    resolve_publish_time,
    run_daily_monitor,
)

TZ = ZoneInfo("Asia/Shanghai")
NOW = datetime(2026, 11, 26, 9, 0, 0, tzinfo=TZ)
WINDOW = get_last_24_hours_range(NOW, TZ)
TEST_KEY = "test-search-key-not-real"
SEARCH_BASE = "https://api.deepseek.com/v1/tools"
FIRST_QUERY = DAILY_KEYWORDS[0]


def make_settings() -> Settings:
    return Settings(
        _env_file=None,
        deepseek_search_api_key=SecretStr(TEST_KEY),
        deepseek_search_base_url=SEARCH_BASE,
        search_concurrency=3,
        request_timeout_seconds=5.0,
    )


def content_with_time(stamp: str, *, date_only: bool = False) -> str:
    """构造含"发布时间"的正文。"""
    if date_only:
        return f"某公告\n发布时间：{stamp}\n正文内容。"
    return f"某公告\n发布时间：{stamp} 阅读次数：10\n正文内容。"


def make_record(
    url: str,
    *,
    publish_date: str | None,
    announcement_type: str = "招标公告",
    confidence: float = 0.8,
    project_name: str = "某 ESG 咨询服务项目",
    region: str | None = "上海市",
    **overrides: Any,
) -> TenderRecord:
    payload: dict[str, Any] = {
        "project_name": project_name,
        "announcement_type": announcement_type,
        "publish_date": publish_date,
        "region": region,
        "industry": "ESG 咨询 / 评级 / 报告编制",
        "buyer": "某能源股份有限公司",
        "project_code": f"CODE-{abs(hash(url)) % 10000}",
        "budget_amount": None,
        "ceiling_price": None,
        "bid_amount": None,
        "contract_amount": None,
        "confidence": confidence,
        "source_url": url,
        "source_title": "页面标题",
    }
    payload.update(overrides)
    return TenderRecord.model_validate(payload)


class MockApi:
    def __init__(
        self,
        search_map: dict[str, list[tuple[str, str]]] | None = None,
        fetch_map: dict[str, str] | None = None,
        failing_fetch: set[str] | None = None,
    ) -> None:
        self.search_map = search_map or {}
        self.fetch_map = fetch_map or {}
        self.failing_fetch = failing_fetch or set()
        self.search_calls: list[str] = []
        self.fetch_calls: list[str] = []

    async def __call__(self, request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/tools/search"):
            query = json.loads(request.content)["query"]
            self.search_calls.append(query)
            results = [
                {"url": url, "title": title}
                for url, title in self.search_map.get(query, [])
            ]
            return httpx.Response(200, json={"results": results})

        url = json.loads(request.content)["url"]
        self.fetch_calls.append(url)
        if url in self.failing_fetch:
            return httpx.Response(500, text="server error")
        return httpx.Response(
            200,
            json={
                "content": self.fetch_map.get(url, content_with_time("2026-11-25 10:00:00")),
                "title": "页面标题",
            },
        )


class FakeExtractor:
    def __init__(
        self,
        records: dict[str, TenderRecord] | None = None,
        failing_urls: set[str] | None = None,
    ) -> None:
        self.records = records or {}
        self.failing_urls = failing_urls or set()
        self.calls: list[str] = []

    async def extract_tender_record(
        self, content: str, source_url: str, source_title: str | None = None
    ) -> TenderRecord:
        self.calls.append(source_url)
        if source_url in self.failing_urls:
            raise RecordValidationError("模型输出不符合招投标记录约束")
        if source_url in self.records:
            return self.records[source_url]
        return make_record(source_url, publish_date="2026-11-25")


@pytest.fixture
def repo(tmp_path: Path) -> TenderRepository:
    database = TendersDatabase(path=tmp_path / "monitor.db")
    database.initialize()
    return TenderRepository(database)


async def run(
    mock: MockApi,
    repo: TenderRepository,
    extractor: FakeExtractor | None = None,
    *,
    output_path: Path,
    **kwargs: Any,
):
    http_client = httpx.AsyncClient(transport=httpx.MockTransport(mock))
    client = make_client(http_client)
    try:
        return await run_daily_monitor(
            now=NOW,
            client=client,
            extractor=extractor or FakeExtractor(),
            repository=repo,
            settings=make_settings(),
            output_path=output_path,
            use_ai=kwargs.pop("use_ai", False),
            **kwargs,
        )
    finally:
        await http_client.aclose()


def make_client(http_client: httpx.AsyncClient) -> Any:
    from services.deepseek_client import DeepSeekClient

    return DeepSeekClient(
        settings=make_settings(),
        client=http_client,
        max_attempts=1,
        retry_backoff_seconds=0.0,
    )


# ---------------------------------------------------------------------------
# 时间解析与判定（纯函数）
# ---------------------------------------------------------------------------


def test_extract_publish_datetime_patterns() -> None:
    assert str(extract_publish_datetime("【发布时间：2026-06-23 08:51:29】")) == "2026-06-23 08:51:29"
    assert str(extract_publish_datetime("发布日期：2026年11月25日 10:30")) == "2026-11-25 10:30:00"
    assert str(extract_publish_datetime("2026-11-25 08:00 公告")) == "2026-11-25 08:00:00"
    assert extract_publish_datetime("发布时间：2026-11-25") is None  # 只有日期
    assert extract_publish_datetime("没有时间") is None


def test_resolve_publish_time_cases() -> None:
    stamp = content_with_time("2026-11-25 10:00:00")
    dt, reason = resolve_publish_time(date(2026, 11, 25), stamp, TZ)
    assert dt == datetime(2026, 11, 25, 10, 0, tzinfo=TZ)
    assert reason is None

    dt, reason = resolve_publish_time(date(2026, 11, 25), "发布时间：2026-11-25", TZ)
    assert dt is None and "时分秒" in (reason or "")

    dt, reason = resolve_publish_time(None, stamp, TZ)
    assert dt is None and "缺失" in (reason or "")

    dt, reason = resolve_publish_time(date(2026, 11, 24), stamp, TZ)
    assert dt is None and "不一致" in (reason or "")


def test_evaluate_boundary_start_excluded() -> None:
    record = make_record("https://example.com/a", publish_date="2026-11-25")
    on_start = content_with_time("2026-11-25 09:00:00")  # 恰好等于 start
    decision = evaluate_announcement(record, on_start, WINDOW, TZ)
    assert decision.status == "excluded_old"

    just_after = content_with_time("2026-11-25 09:00:01")
    decision = evaluate_announcement(record, just_after, WINDOW, TZ)
    assert decision.status == "included"
    assert decision.publish_time == datetime(2026, 11, 25, 9, 0, 1, tzinfo=TZ)


def test_evaluate_end_boundary_included() -> None:
    record = make_record("https://example.com/a", publish_date="2026-11-26")
    at_end = content_with_time("2026-11-26 09:00:00")
    assert evaluate_announcement(record, at_end, WINDOW, TZ).status == "included"

    after_end = content_with_time("2026-11-26 09:00:01")
    assert evaluate_announcement(record, after_end, WINDOW, TZ).status == "excluded_future"


def test_evaluate_type_and_confidence_before_time() -> None:
    correction = make_record(
        "https://example.com/c", publish_date="2026-11-25", announcement_type="更正公告"
    )
    assert evaluate_announcement(correction, content_with_time("2026-11-25 10:00:00"), WINDOW, TZ).status == "excluded_type"

    other = make_record("https://example.com/o", publish_date="2026-11-25", announcement_type="其他")
    assert evaluate_announcement(other, content_with_time("2026-11-25 10:00:00"), WINDOW, TZ).status == "excluded_type"

    low = make_record("https://example.com/l", publish_date="2026-11-25", confidence=0.29)
    assert evaluate_announcement(low, content_with_time("2026-11-25 10:00:00"), WINDOW, TZ).status == "excluded_low_confidence"


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_includes_announcement_within_window(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/fresh.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "新公告")]},
        fetch_map={url: content_with_time("2026-11-25 12:30:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    stats = report.stats
    assert stats.query_count == len(DAILY_KEYWORDS)
    assert stats.search_url_count == 1
    assert stats.unique_url_count == 1
    assert stats.fetch_success_count == 1
    assert stats.extraction_success_count == 1
    assert stats.included_count == 1
    assert stats.inserted_count == 1
    assert repo.count() == 1
    assert len(report.announcements) == 1
    assert report.announcements[0].source_url == url


@pytest.mark.asyncio
async def test_run_excludes_old_announcement(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/old.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "旧公告")]},
        fetch_map={url: content_with_time("2026-11-24 08:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-24")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.excluded_old_count == 1
    assert report.stats.included_count == 0
    assert report.stats.inserted_count == 0
    assert repo.count() == 0


@pytest.mark.asyncio
async def test_run_excludes_future_announcement_and_records_anomaly(
    repo: TenderRepository, tmp_path: Path
) -> None:
    url = "https://example.com/future.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "未来公告")]},
        fetch_map={url: content_with_time("2026-11-26 10:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-26")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.excluded_future_count == 1
    assert report.stats.inserted_count == 0
    assert report.failures[0].stage == "filter"
    assert "晚于当前时间" in report.failures[0].error


@pytest.mark.asyncio
async def test_date_only_goes_to_pending(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/date-only.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "仅日期")]},
        fetch_map={url: content_with_time("2026-11-25", date_only=True)},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.pending_verification_count == 1
    assert report.stats.inserted_count == 0
    assert repo.count() == 0
    assert report.pending_reasons
    assert "过去24小时未发现符合条件的新公告" in (tmp_path / "daily.md").read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_missing_publish_date_goes_to_pending(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/no-date.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "无日期")]},
        fetch_map={url: content_with_time("2026-11-25 10:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date=None)})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.pending_verification_count == 1
    assert "缺失" in report.pending_reasons[0]


@pytest.mark.asyncio
async def test_correction_and_other_excluded(repo: TenderRepository, tmp_path: Path) -> None:
    correction = "https://example.com/correction.html"
    other = "https://example.com/other.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(correction, "更正"), (other, "其他")]},
        fetch_map={
            correction: content_with_time("2026-11-25 10:00:00"),
            other: content_with_time("2026-11-25 10:00:00"),
        },
    )
    extractor = FakeExtractor(
        {
            correction: make_record(correction, publish_date="2026-11-25", announcement_type="更正公告"),
            other: make_record(other, publish_date="2026-11-25", announcement_type="其他", industry="其他"),
        }
    )

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.excluded_announcement_type_count == 2
    assert report.stats.inserted_count == 0


@pytest.mark.asyncio
async def test_low_confidence_excluded(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/low.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "低置信度")]},
        fetch_map={url: content_with_time("2026-11-25 10:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25", confidence=0.1)})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.excluded_low_confidence_count == 1
    assert report.stats.inserted_count == 0


@pytest.mark.asyncio
async def test_existing_url_skipped_without_fetch(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/existing.html"
    existing = make_record(url, publish_date="2026-11-25")
    repo.save_record(existing)
    mock = MockApi(search_map={FIRST_QUERY: [(url, "已存在")]})

    report = await run(mock, repo, output_path=tmp_path / "daily.md")

    assert report.stats.skipped_existing_count == 1
    assert mock.fetch_calls == []
    assert repo.count() == 1


@pytest.mark.asyncio
async def test_duplicate_url_across_queries_fetched_once(
    repo: TenderRepository, tmp_path: Path
) -> None:
    url = "https://example.com/dup.html"
    mock = MockApi(
        search_map={
            FIRST_QUERY: [(url, "公告")],
            DAILY_KEYWORDS[1]: [(url, "公告（重复）")],
        },
        fetch_map={url: content_with_time("2026-11-25 11:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.search_url_count == 2
    assert report.stats.unique_url_count == 1
    assert mock.fetch_calls == [url]
    assert report.stats.inserted_count == 1


@pytest.mark.asyncio
async def test_fetch_failure_isolated(repo: TenderRepository, tmp_path: Path) -> None:
    bad = "https://example.com/bad.html"
    good = "https://example.com/good.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(bad, "坏"), (good, "好")]},
        fetch_map={good: content_with_time("2026-11-25 10:00:00")},
        failing_fetch={bad},
    )
    extractor = FakeExtractor({good: make_record(good, publish_date="2026-11-25")})

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.fetch_failed_count == 1
    assert report.stats.inserted_count == 1
    assert report.failures[0].stage == "fetch"
    assert repo.count() == 1


@pytest.mark.asyncio
async def test_extraction_failure_isolated(repo: TenderRepository, tmp_path: Path) -> None:
    bad = "https://example.com/bad-extract.html"
    good = "https://example.com/good-extract.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(bad, "坏"), (good, "好")]},
        fetch_map={
            bad: content_with_time("2026-11-25 10:00:00"),
            good: content_with_time("2026-11-25 10:00:00"),
        },
    )
    extractor = FakeExtractor(
        {good: make_record(good, publish_date="2026-11-25")}, failing_urls={bad}
    )

    report = await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert report.stats.extraction_failed_count == 1
    assert report.stats.inserted_count == 1
    assert any(f.stage == "extraction" for f in report.failures)


@pytest.mark.asyncio
async def test_no_announcements_still_generates_report(
    repo: TenderRepository, tmp_path: Path
) -> None:
    mock = MockApi()
    target = tmp_path / "empty.md"

    report = await run(mock, repo, output_path=target)

    assert report.stats.query_count == len(DAILY_KEYWORDS)
    assert report.stats.search_url_count == 0
    assert target.exists()
    text = target.read_text(encoding="utf-8")
    assert "过去24小时未发现符合条件的新公告" in text
    assert "监控时间窗" in text


@pytest.mark.asyncio
async def test_ai_failure_falls_back_to_base_report(repo: TenderRepository, tmp_path: Path) -> None:
    url = "https://example.com/ai.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "公告")]},
        fetch_map={url: content_with_time("2026-11-25 10:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25")})

    async def failing_renderer(window: TimeRange, stats: MonitorStats, announcements: list[Any]) -> str:
        raise RuntimeError("model down")

    target = tmp_path / "ai.md"
    report = await run(
        mock, repo, extractor, output_path=target, use_ai=True, ai_renderer=failing_renderer
    )

    assert report.ai_used is False
    assert report.ai_error and "RuntimeError" in report.ai_error
    text = target.read_text(encoding="utf-8")
    assert "## 一、新公告" in text
    assert url in text


@pytest.mark.asyncio
async def test_ai_summary_is_truncated(repo: TenderRepository, tmp_path: Path) -> None:
    async def long_renderer(window: TimeRange, stats: MonitorStats, announcements: list[Any]) -> str:
        return "字" * 500

    report = await run(
        mock := MockApi(),
        repo,
        output_path=tmp_path / "long.md",
        use_ai=True,
        ai_renderer=long_renderer,
    )

    assert report.ai_used is True
    text = (tmp_path / "long.md").read_text(encoding="utf-8")
    summary_line = next(line for line in text.splitlines() if line.startswith("> 字"))
    assert len(summary_line) - 2 <= AI_SUMMARY_CHAR_LIMIT


@pytest.mark.asyncio
async def test_existing_records_not_modified(repo: TenderRepository, tmp_path: Path) -> None:
    history_url = "https://example.com/history.html"
    history = make_record(history_url, publish_date="2025-01-01", project_name="历史项目", confidence=0.9)
    result = repo.save_record(history)

    url = "https://example.com/new.html"
    mock = MockApi(
        search_map={FIRST_QUERY: [(url, "新公告")]},
        fetch_map={url: content_with_time("2026-11-25 10:00:00")},
    )
    extractor = FakeExtractor({url: make_record(url, publish_date="2026-11-25")})

    await run(mock, repo, extractor, output_path=tmp_path / "daily.md")

    assert repo.count() == 2
    stored = repo.get_by_id(result.record_id)
    assert stored is not None
    assert stored.project_name == "历史项目"
    assert stored.publish_date == date(2025, 1, 1)
    assert stored.confidence == pytest.approx(0.9)


@pytest.mark.asyncio
async def test_stats_are_consistent(repo: TenderRepository, tmp_path: Path) -> None:
    urls = {
        "fresh": "https://example.com/fresh.html",
        "old": "https://example.com/old.html",
        "pending": "https://example.com/pending.html",
        "correction": "https://example.com/correction.html",
        "low": "https://example.com/low.html",
        "failed": "https://example.com/fetch-fail.html",
    }
    mock = MockApi(
        search_map={
            FIRST_QUERY: [
                (urls["fresh"], "新"),
                (urls["old"], "旧"),
                (urls["pending"], "待核实"),
                (urls["correction"], "更正"),
                (urls["low"], "低"),
                (urls["failed"], "失败"),
            ]
        },
        fetch_map={
            urls["fresh"]: content_with_time("2026-11-25 10:00:00"),
            urls["old"]: content_with_time("2026-11-20 10:00:00"),
            urls["pending"]: content_with_time("2026-11-25", date_only=True),
            urls["correction"]: content_with_time("2026-11-25 10:00:00"),
            urls["low"]: content_with_time("2026-11-25 10:00:00"),
        },
        failing_fetch={urls["failed"]},
    )
    extractor = FakeExtractor(
        {
            urls["fresh"]: make_record(urls["fresh"], publish_date="2026-11-25"),
            urls["old"]: make_record(urls["old"], publish_date="2026-11-20"),
            urls["pending"]: make_record(urls["pending"], publish_date="2026-11-25"),
            urls["correction"]: make_record(
                urls["correction"], publish_date="2026-11-25", announcement_type="更正公告"
            ),
            urls["low"]: make_record(urls["low"], publish_date="2026-11-25", confidence=0.2),
        }
    )

    report = await run(mock, repo, extractor, output_path=tmp_path / "stats.md")
    stats = report.stats

    assert stats.search_url_count == 6
    assert stats.unique_url_count == 6
    assert stats.fetch_success_count == 5
    assert stats.fetch_failed_count == 1
    assert stats.extraction_success_count == 5
    assert stats.extraction_failed_count == 0
    assert stats.included_count == 1
    assert stats.inserted_count == 1
    assert stats.excluded_old_count == 1
    assert stats.excluded_future_count == 0
    assert stats.pending_verification_count == 1
    assert stats.excluded_announcement_type_count == 1
    assert stats.excluded_low_confidence_count == 1
    assert stats.skipped_existing_count == 0
    assert stats.duplicate_count == 0
    assert stats.save_failed_count == 0
    assert len(report.failures) == 1
    assert repo.count() == 1


def test_report_does_not_show_amounts() -> None:
    stats = MonitorStats(inserted_count=0)
    markdown = render_daily_markdown(WINDOW, stats, [])
    assert "中标金额" not in markdown
    assert "预算" not in markdown
