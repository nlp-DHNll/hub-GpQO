"""services/analytics_service.py 的单元测试（不调用真实模型，不污染正式数据库）。"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import pytest
from pydantic import ValidationError

from db.database import TendersDatabase
from db.repository import TenderRepository
from models.tender import TenderRecord
from services.analytics_service import (
    AIAnalysisError,
    analyze_records,
    compute_bid_amount_stats,
    compute_disclosed_counts,
    compute_distribution,
    filter_records,
    generate_historical_analysis_report,
    is_valid_source_url,
    render_base_markdown,
)

TZ = ZoneInfo("Asia/Shanghai")
GENERATED_AT = datetime(2026, 11, 26, 9, 0, tzinfo=TZ)


def make_record(index: int = 0, **overrides: Any) -> TenderRecord:
    payload: dict[str, Any] = {
        "project_name": f"ESG 咨询服务项目 {index}",
        "announcement_type": "中标公告",
        "publish_date": "2025-06-01",
        "region": "上海市",
        "industry": "ESG 咨询 / 评级 / 报告编制",
        "buyer": "某能源股份有限公司",
        "winning_supplier": "某咨询有限公司",
        "project_code": f"CODE-{index}",
        "confidence": 0.8,
        "source_url": f"https://example.com/notice/{index}.html",
    }
    payload.update(overrides)
    return TenderRecord.model_validate(payload)


@pytest.fixture
def repo(tmp_path: Path) -> TenderRepository:
    database = TendersDatabase(path=tmp_path / "analytics.db")
    database.initialize()
    return TenderRepository(database)


# ---------------------------------------------------------------------------
# 过滤规则
# ---------------------------------------------------------------------------


def test_low_confidence_excluded() -> None:
    records = [
        make_record(1, confidence=0.9),
        make_record(2, confidence=0.29),
        make_record(3, confidence=0.3),  # 边界：恰好 0.3 应纳入
    ]
    included, stats = filter_records(records)

    assert stats.excluded_low_confidence == 1
    assert stats.included_count == 2
    assert {item.project_name for item in included} == {"ESG 咨询服务项目 1", "ESG 咨询服务项目 3"}


def test_other_announcement_type_excluded() -> None:
    records = [
        make_record(1),
        make_record(2, announcement_type="其他", industry="其他"),
    ]
    included, stats = filter_records(records)

    assert stats.excluded_other_type == 1
    assert stats.included_count == 1


def test_invalid_url_excluded() -> None:
    records = [make_record(1)]
    # TenderRecord 已强制 AnyHttpUrl，因此直接验证 URL 判定函数与顺序过滤的组合逻辑
    assert is_valid_source_url(records[0].source_url)
    assert not is_valid_source_url("")
    assert not is_valid_source_url(None)
    assert not is_valid_source_url("ftp://example.com/a")

    class FakeRecord:
        source_url = "not-a-url"
        announcement_type = make_record(1).announcement_type
        confidence = 0.9

    class FakeRecord2:
        source_url = "https://ok.example.com/a"
        announcement_type = make_record(1).announcement_type
        confidence = 0.9

    included, stats = filter_records([FakeRecord(), FakeRecord2()])  # type: ignore[list-item]
    assert stats.excluded_invalid_url == 1
    assert stats.included_count == 1
    assert isinstance(included[0], FakeRecord2)


def test_exclusions_not_double_counted() -> None:
    """同时不满足多个条件的记录只被计入顺序过滤中的第一类。"""
    records = [
        make_record(1),  # 纳入
        make_record(2, announcement_type="其他", confidence=0.1),  # 先命中"其他类型"
        make_record(3, confidence=0.1),  # 只命中低置信度
        make_record(4, announcement_type="其他"),  # 先命中"其他类型"
    ]
    included, stats = filter_records(records)

    assert stats.excluded_other_type == 2
    assert stats.excluded_low_confidence == 1
    assert stats.included_count == 1
    assert stats.excluded_total == 3
    assert stats.raw_count == stats.included_count + stats.excluded_total
    assert stats.is_consistent() is True


@pytest.mark.asyncio
async def test_excluded_records_are_not_deleted_from_db(repo: TenderRepository) -> None:
    repo.save_record(make_record(1, confidence=0.1))
    repo.save_record(make_record(2, announcement_type="其他"))
    repo.save_record(make_record(3))

    outcome = await generate_historical_analysis_report(
        repository=repo, use_ai=False, output_path=Path(repo.database.path).parent / "r.md"
    )

    assert outcome.result.filters.raw_count == 3
    assert outcome.result.filters.included_count == 1
    assert repo.count() == 3  # 数据库原始记录未被删除或修改
    stored = repo.get_by_source_url("https://example.com/notice/1.html")
    assert stored is not None and stored.confidence == pytest.approx(0.1)


# ---------------------------------------------------------------------------
# 金额统计
# ---------------------------------------------------------------------------


def test_only_bid_amount_counts_toward_award_statistics() -> None:
    records = [
        make_record(1, budget_amount="5000000", ceiling_price="4800000", bid_amount="1200000"),
        make_record(2, budget_amount="3000000", contract_amount="2900000"),  # 无 bid_amount
        make_record(3, ceiling_price="900000", contract_amount="880000"),  # 无 bid_amount
    ]
    stats = compute_bid_amount_stats(records)

    assert stats.sample_count == 1
    assert stats.total == Decimal("1200000")
    assert stats.max_amount == Decimal("1200000")
    assert stats.min_amount == Decimal("1200000")
    assert stats.undisclosed_count == 2


def test_budget_amount_not_used_when_bid_missing() -> None:
    stats = compute_bid_amount_stats([make_record(1, budget_amount="9999999")])
    assert stats.sample_count == 0
    assert stats.total is None
    assert stats.undisclosed_count == 1


def test_decimal_amounts_are_exact() -> None:
    records = [
        make_record(1, bid_amount="0.1"),
        make_record(2, bid_amount="0.2"),
        make_record(3, bid_amount="1234567.89"),
    ]
    stats = compute_bid_amount_stats(records)

    assert stats.total == Decimal("1234568.19")  # float 会得到 1234568.1900000002
    assert isinstance(stats.total, Decimal)
    assert stats.average == Decimal("411522.73")
    # 排序后 [0.1, 0.2, 1234567.89] 的中位数为 0.2
    assert stats.median == Decimal("0.20")


def test_negative_bid_amount_excluded_as_invalid() -> None:
    # TenderRecord 本身拒绝负金额；这里用 model_copy 构造"库中被外部改坏"的数据，
    # 验证统计层不会把负数悄悄算进金额。
    broken = make_record(1).model_copy(update={"bid_amount": Decimal("-1")})
    stats = compute_bid_amount_stats([broken, make_record(2, bid_amount="100")])
    assert stats.sample_count == 1
    assert stats.invalid_count == 1


@pytest.mark.parametrize(
    ("amount", "expected_bucket"),
    [
        ("0", "100万元以下"),
        ("999999.99", "100万元以下"),
        ("1000000", "100万–500万元"),          # 边界：100 万整属于第二档
        ("4999999.99", "100万–500万元"),
        ("5000000", "500万–1000万元"),         # 边界：500 万整
        ("9999999.99", "500万–1000万元"),
        ("10000000", "1000万–5000万元"),       # 边界：1000 万整
        ("49999999.99", "1000万–5000万元"),
        ("50000000", "5000万–1亿元"),          # 边界：5000 万整
        ("99999999.99", "5000万–1亿元"),
        ("100000000", "1亿元及以上"),          # 边界：1 亿整
        ("500000000", "1亿元及以上"),
    ],
)
def test_amount_bucket_boundaries(amount: str, expected_bucket: str) -> None:
    stats = compute_bid_amount_stats([make_record(1, bid_amount=amount)])
    counts = {bucket.label: bucket.count for bucket in stats.buckets}
    assert counts[expected_bucket] == 1
    assert sum(counts.values()) == 1


def test_buckets_cover_all_valid_samples() -> None:
    records = [
        make_record(1, bid_amount="50000"),
        make_record(2, bid_amount="2000000"),
        make_record(3, bid_amount="30000000"),
        make_record(4, bid_amount="200000000"),
    ]
    stats = compute_bid_amount_stats(records)
    counts = {bucket.label: bucket.count for bucket in stats.buckets}
    assert counts == {
        "100万元以下": 1,
        "100万–500万元": 1,
        "500万–1000万元": 0,
        "1000万–5000万元": 1,
        "5000万–1亿元": 0,
        "1亿元及以上": 1,
    }
    assert sum(counts.values()) == stats.sample_count


def test_disclosed_amounts_are_independent() -> None:
    records = [
        make_record(1, budget_amount="100", bid_amount="200"),
        make_record(2, ceiling_price="300"),
        make_record(3, contract_amount="400", bid_amount="500"),
    ]
    disclosed = compute_disclosed_counts(records)
    assert disclosed.budget_amount == 1
    assert disclosed.ceiling_price == 1
    assert disclosed.bid_amount == 2
    assert disclosed.contract_amount == 1


# ---------------------------------------------------------------------------
# 分布统计
# ---------------------------------------------------------------------------


def test_industry_and_announcement_distribution() -> None:
    records = [
        make_record(1, industry="ESG 咨询 / 评级 / 报告编制"),
        make_record(2, industry="ESG 咨询 / 评级 / 报告编制"),
        make_record(3, industry="碳管理", announcement_type="招标公告"),
        make_record(4, industry="水务与水环境", announcement_type="采购公告"),
    ]
    announcement_items, industry_items = compute_distribution(records)

    announcement = {item.label: item for item in announcement_items}
    industry = {item.label: item for item in industry_items}

    assert announcement["中标公告"].count == 2
    assert announcement["中标公告"].ratio == Decimal("50.00")
    assert announcement["招标公告"].ratio == Decimal("25.00")
    assert announcement["更正公告"].count == 0
    assert announcement["更正公告"].ratio == Decimal("0.00")

    assert industry["ESG 咨询 / 评级 / 报告编制"].count == 2
    assert industry["ESG 咨询 / 评级 / 报告编制"].ratio == Decimal("50.00")
    assert len(industry_items) == 11  # 与 Industry 枚举一致


def test_ratio_rounding_two_decimals() -> None:
    records = [make_record(i) for i in range(3)]
    _, industry_items = compute_distribution(records)
    esg = next(item for item in industry_items if item.label == "ESG 咨询 / 评级 / 报告编制")
    assert esg.ratio == Decimal("100.00")

    records = [make_record(1), make_record(2), make_record(3, industry="碳管理")]
    _, industry_items = compute_distribution(records)
    esg = next(item for item in industry_items if item.label == "ESG 咨询 / 评级 / 报告编制")
    assert esg.ratio == Decimal("66.67")


# ---------------------------------------------------------------------------
# 结果与报告
# ---------------------------------------------------------------------------


def test_analyze_records_basic_fields() -> None:
    records = [
        make_record(1, publish_date="2024-03-01", region="北京市", industry="ESG 咨询 / 评级 / 报告编制"),
        make_record(2, publish_date="2026-01-15", region=None, announcement_type="招标公告", industry="碳管理"),
        make_record(3, publish_date=None, region="", announcement_type="采购公告", industry="碳管理"),
        make_record(4, announcement_type="中标公告", region="广州市"),
    ]
    result = analyze_records(records, generated_at=GENERATED_AT)

    basic = result.basic
    assert basic["included_count"] == 4
    # make_record 默认 announcement_type="中标公告"：记录 1、4 为中标公告
    assert basic["award_count"] == 2
    assert basic["tender_count"] == 1
    assert basic["procurement_count"] == 1
    assert basic["correction_count"] == 0
    assert basic["earliest_publish_date"] == "2024-03-01"
    assert basic["latest_publish_date"] == "2026-01-15"
    assert result.region_covered_count == 2


def test_render_base_markdown_contains_all_sections() -> None:
    records = [
        make_record(1, bid_amount="1200000"),
        make_record(2, bid_amount="3000000"),
        make_record(3, announcement_type="招标公告", industry="碳管理", budget_amount="5000000"),
    ]
    result = analyze_records(records, generated_at=GENERATED_AT)
    markdown = render_base_markdown(result)

    for heading in (
        "## 一、数据质量与过滤情况",
        "## 二、基础统计",
        "## 三、公告类型分布",
        "## 四、ESG 细分行业分布",
        "## 五、中标金额统计",
        "## 六、金额字段披露情况",
        "## 七、数据局限性与结论",
    ):
        assert heading in markdown

    assert "本报告基于公开网络可检索信息，非全量统计" in markdown
    assert "4200000" in markdown                     # 中标金额总额
    assert "有效中标金额样本：**2** 条" in markdown
    assert "不做行业金额规律" in markdown            # 样本 < 3 的措辞
    assert "| budget_amount | 1 | 预算金额 |" in markdown
    assert "5000000" not in markdown                 # 预算金额不得出现在中标金额数字里


def test_markdown_renders_from_result_values_only() -> None:
    result = analyze_records(
        [make_record(1, industry="碳管理", bid_amount="1234567.89")],
        generated_at=GENERATED_AT,
    )
    markdown = render_base_markdown(result)

    assert "1234567.89" in markdown
    assert "123.46" in markdown                       # 万元换算，两位小数
    assert f"| 碳管理 | 1 | 100.00% |" in markdown


def test_empty_records_report() -> None:
    result = analyze_records([], generated_at=GENERATED_AT)
    assert result.filters.raw_count == 0
    assert result.filters.included_count == 0

    markdown = render_base_markdown(result)
    assert "正式统计纳入记录数为 0" in markdown
    assert "本报告基于公开网络可检索信息，非全量统计" in markdown


@pytest.mark.asyncio
async def test_generate_report_writes_file(repo: TenderRepository, tmp_path: Path) -> None:
    repo.save_record(make_record(1, bid_amount="1200000"))
    target = tmp_path / "out" / "report.md"

    outcome = await generate_historical_analysis_report(
        repository=repo, use_ai=False, output_path=target
    )

    assert target.exists()
    assert outcome.report_path == target
    assert outcome.ai_used is False
    assert outcome.ai_error is None
    assert "# ESG 招投标历史数据分析报告" in target.read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_model_failure_falls_back_to_base_report(repo: TenderRepository, tmp_path: Path) -> None:
    repo.save_record(make_record(1, bid_amount="1200000"))
    target = tmp_path / "report.md"

    async def failing_renderer(result: Any) -> str:
        raise AIAnalysisError("分析文字生成失败（RuntimeError）")

    outcome = await generate_historical_analysis_report(
        repository=repo, use_ai=True, output_path=target, ai_renderer=failing_renderer
    )

    assert outcome.ai_used is False
    assert outcome.ai_error is not None and "AIAnalysisError" in outcome.ai_error
    markdown = target.read_text(encoding="utf-8")
    assert "## 五、中标金额统计" in markdown
    assert "1200000" in markdown


@pytest.mark.asyncio
async def test_model_success_injects_analysis(repo: TenderRepository, tmp_path: Path) -> None:
    repo.save_record(make_record(1, bid_amount="1200000"))
    target = tmp_path / "report.md"

    async def fake_renderer(result: Any) -> str:
        return "### 分析\n\n本次纳入 1 条记录。"

    outcome = await generate_historical_analysis_report(
        repository=repo, use_ai=True, output_path=target, ai_renderer=fake_renderer
    )

    assert outcome.ai_used is True
    markdown = target.read_text(encoding="utf-8")
    assert "本次纳入 1 条记录。" in markdown
    # AI 文字插入到局限性章节之前，统计章节仍完整
    assert markdown.index("本次纳入 1 条记录。") < markdown.index("## 七、数据局限性与结论")


def test_ai_headings_are_demoted_to_keep_report_structure() -> None:
    from services.analytics_service import _inject_ai_section

    base = "## 六、金额字段披露情况\n\n## 七、数据局限性与结论\n"
    ai_text = "# 模型标题\n\n## 一、数据概况\n\n正文\n\n### 小点\n"
    output = _inject_ai_section(base, ai_text)

    assert "\n### 模型标题\n" in output
    assert "\n#### 一、数据概况\n" in output
    assert "\n##### 小点\n" in output
    # 报告主章节层级保持不变，且出现次数不变
    assert output.count("\n## 七、数据局限性与结论") == 1
    assert output.index("### 分析（由模型基于上述统计生成）") < output.index(
        "## 七、数据局限性与结论"
    )
