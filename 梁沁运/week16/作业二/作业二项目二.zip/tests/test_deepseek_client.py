"""services/deepseek_client.py 的单元测试（全部使用 MockTransport，不调用真实 API）。"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import httpx
import pytest
from pydantic import SecretStr

from config.settings import ConfigurationError, Settings
from services.deepseek_client import (
    DeepSeekClient,
    FetchError,
    SearchError,
    is_fetchable_url,
    normalize_url,
    strip_url_fragment,
)

TEST_KEY = "test-key-not-a-real-secret"
SEARCH_BASE = "https://api.deepseek.com/v1/tools"
SEARCH_URL = f"{SEARCH_BASE}/search"
FETCH_URL = "https://api.deepseek.com/v1/tools/fetch"


# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------


def make_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "deepseek_search_api_key": SecretStr(TEST_KEY),
        "deepseek_search_base_url": SEARCH_BASE,
        "search_concurrency": 3,
        "request_timeout_seconds": 5.0,
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


def make_client(
    handler: Any,
    *,
    settings: Settings | None = None,
    max_attempts: int = 2,
) -> tuple[DeepSeekClient, httpx.AsyncClient]:
    transport = httpx.MockTransport(handler)
    http_client = httpx.AsyncClient(transport=transport)
    client = DeepSeekClient(
        settings=settings or make_settings(),
        client=http_client,
        max_attempts=max_attempts,
        retry_backoff_seconds=0.0,
    )
    return client, http_client


def search_payload(results: list[dict[str, Any]]) -> dict[str, Any]:
    return {"results": results}




# ---------------------------------------------------------------------------
# URL 工具
# ---------------------------------------------------------------------------


def test_url_helpers() -> None:
    assert normalize_url("HTTPS://WWW.Example.COM/a/#frag") == "https://www.example.com/a"
    assert strip_url_fragment("https://example.com/a?x=1#section") == "https://example.com/a?x=1"
    assert is_fetchable_url("https://example.com/a")
    assert not is_fetchable_url("ftp://example.com/a")
    assert not is_fetchable_url("not-a-url")
    assert not is_fetchable_url("https://" + "a" * 9000)


# ---------------------------------------------------------------------------
# Search：请求格式
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_request_format_matches_project_one() -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(
            200,
            json=search_payload(
                [
                    {
                        "title": "某市双碳招标公告",
                        "url": "https://example.com/a#1",
                        "snippet": "预算 100 万元",
                        "summary": "摘要",
                        "content": "",
                        "site_name": "中国政府采购网",
                        "date": "2026-11-20",
                        "authority": 3,
                        "rerank_score": 0.87,
                    }
                ]
            ),
        )

    client, http_client = make_client(handler)
    try:
        result = await client.search("ESG 招标 中标 2026")
    finally:
        await http_client.aclose()

    assert len(seen) == 1
    request = seen[0]
    assert request.method == "POST"
    assert str(request.url) == SEARCH_URL
    assert request.headers["authorization"] == f"Bearer {TEST_KEY}"
    assert request.headers["content-type"] == "application/json"
    assert json.loads(request.content) == {
        "query": "ESG 招标 中标 2026",
        "count": 10,
        "need_content": False,
    }

    assert result.status == "success"
    assert result.query == "ESG 招标 中标 2026"
    assert result.attempts == 1
    assert result.raw_response is not None
    item = result.items[0]
    assert item.title == "某市双碳招标公告"
    assert item.url == "https://example.com/a"  # 片段已被剥离
    assert item.snippet == "预算 100 万元"
    assert item.site_name == "中国政府采购网"
    assert item.date == "2026-11-20"
    assert item.authority == 3
    assert item.rerank_score == pytest.approx(0.87)
    assert item.raw["url"] == "https://example.com/a#1"


@pytest.mark.asyncio
async def test_search_freshness_not_sent_by_default() -> None:
    bodies: list[dict[str, Any]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content))
        return httpx.Response(200, json=search_payload([]))

    client, http_client = make_client(handler)
    try:
        await client.search("ESG 招标公告")
        await client.search("ESG 招标公告", freshness="d1")
    finally:
        await http_client.aclose()

    assert "freshness" not in bodies[0]
    assert bodies[1]["freshness"] == "d1"


@pytest.mark.asyncio
async def test_search_drops_items_without_url_and_deduplicates() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json=search_payload(
                [
                    {"title": "无 URL", "snippet": "x"},
                    {"url": "https://example.com/a", "title": "A"},
                    {"url": "https://example.com/a#2", "title": "A 重复"},
                    {"url": "", "title": "空 URL"},
                    "not-a-dict",
                ]
            ),
        )

    client, http_client = make_client(handler)
    try:
        result = await client.search("q")
    finally:
        await http_client.aclose()

    assert [item.title for item in result.items] == ["A"]
    assert result.status == "success"


@pytest.mark.asyncio
async def test_search_empty_results_status_empty() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=search_payload([]))

    client, http_client = make_client(handler)
    try:
        result = await client.search("q")
    finally:
        await http_client.aclose()

    assert result.status == "empty"
    assert result.items == []


@pytest.mark.asyncio
async def test_search_invalid_query_rejected_without_request() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
        nonlocal calls
        calls += 1
        return httpx.Response(200, json=search_payload([]))

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError):
            await client.search("   ")
        with pytest.raises(SearchError):
            await client.search("x" * 129)
        with pytest.raises(ValueError):
            await client.search("ok", count=0)
    finally:
        await http_client.aclose()
    assert calls == 0


# ---------------------------------------------------------------------------
# Search：异常处理
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_http_400_not_retried() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(400, text="bad request")

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    assert calls == 1
    assert "HTTP 400" in str(exc_info.value)
    assert exc_info.value.attempts == 1


@pytest.mark.asyncio
async def test_search_retries_on_500_then_succeeds() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            return httpx.Response(500, text="server error")
        return httpx.Response(200, json=search_payload([{"url": "https://example.com/x"}]))

    client, http_client = make_client(handler)
    try:
        result = await client.search("q")
    finally:
        await http_client.aclose()

    assert calls == 2
    assert result.attempts == 2
    assert result.status == "success"


@pytest.mark.asyncio
async def test_search_timeout_retried_then_raises() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        raise httpx.ReadTimeout("timeout", request=request)

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    assert calls == 2
    assert "超时" in str(exc_info.value)
    assert exc_info.value.attempts == 2


@pytest.mark.asyncio
async def test_search_connection_error_handled() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    client, http_client = make_client(handler, max_attempts=1)
    try:
        with pytest.raises(SearchError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    assert "网络请求异常" in str(exc_info.value)


@pytest.mark.asyncio
async def test_search_invalid_json_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="<html>not json</html>")

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    assert "不是合法 JSON" in str(exc_info.value)


@pytest.mark.asyncio
async def test_search_missing_results_field_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"data": []})

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError):
            await client.search("q")
    finally:
        await http_client.aclose()


# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fetch_request_format_matches_project_one() -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(
            200, json={"content": "# 标题\n\n正文 Markdown", "title": "公告标题"}
        )

    client, http_client = make_client(handler)
    try:
        result = await client.fetch("https://example.com/notice?x=1")
    finally:
        await http_client.aclose()

    assert len(seen) == 1
    request = seen[0]
    assert request.method == "POST"
    assert str(request.url) == FETCH_URL
    assert request.headers["authorization"] == f"Bearer {TEST_KEY}"
    assert json.loads(request.content) == {"url": "https://example.com/notice?x=1"}

    assert result.status == "success"
    assert result.title == "公告标题"
    assert result.content == "# 标题\n\n正文 Markdown"
    assert result.attempts == 1


@pytest.mark.asyncio
async def test_fetch_empty_content_marked_empty() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"content": "   ", "title": "空页"})

    client, http_client = make_client(handler)
    try:
        result = await client.fetch("https://example.com/empty")
    finally:
        await http_client.aclose()

    assert result.status == "empty"
    assert result.error == "正文为空"


@pytest.mark.asyncio
async def test_fetch_invalid_url_rejected_without_request() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
        nonlocal calls
        calls += 1
        return httpx.Response(200, json={"content": "x"})

    client, http_client = make_client(handler)
    try:
        with pytest.raises(FetchError):
            await client.fetch("file:///etc/passwd")
    finally:
        await http_client.aclose()
    assert calls == 0


@pytest.mark.asyncio
async def test_fetch_404_not_retried() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(404, text="not found")

    client, http_client = make_client(handler)
    try:
        with pytest.raises(FetchError) as exc_info:
            await client.fetch("https://example.com/missing")
    finally:
        await http_client.aclose()

    assert calls == 1
    assert "HTTP 404" in str(exc_info.value)


@pytest.mark.asyncio
async def test_fetch_retries_on_408_then_succeeds() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            return httpx.Response(408, text="timeout")
        return httpx.Response(200, json={"content": "ok"})

    client, http_client = make_client(handler)
    try:
        result = await client.fetch("https://example.com/slow")
    finally:
        await http_client.aclose()

    assert calls == 2
    assert result.content == "ok"


@pytest.mark.asyncio
async def test_fetch_missing_content_field_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"title": "无正文"})

    client, http_client = make_client(handler)
    try:
        with pytest.raises(FetchError):
            await client.fetch("https://example.com/x")
    finally:
        await http_client.aclose()


# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_missing_config_raises_configuration_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
        return httpx.Response(200, json=search_payload([]))

    settings = make_settings(deepseek_search_api_key=None, deepseek_search_base_url=None)
    client, http_client = make_client(handler, settings=settings)
    try:
        with pytest.raises(ConfigurationError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    message = str(exc_info.value)
    assert "DEEPSEEK_SEARCH_API_KEY" in message
    assert TEST_KEY not in message


@pytest.mark.asyncio
async def test_fetch_missing_key_raises_configuration_error() -> None:
    settings = make_settings(deepseek_search_api_key=None)

    def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
        return httpx.Response(200, json={"content": "x"})

    client, http_client = make_client(handler, settings=settings)
    try:
        with pytest.raises(ConfigurationError):
            await client.fetch("https://example.com/x")
    finally:
        await http_client.aclose()


# ---------------------------------------------------------------------------
# 密钥安全
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_api_key_not_logged_on_success(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.DEBUG)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=search_payload([{"url": "https://example.com/a"}]))

    client, http_client = make_client(handler)
    try:
        await client.search("q")
    finally:
        await http_client.aclose()

    assert TEST_KEY not in caplog.text


@pytest.mark.asyncio
async def test_api_key_not_in_error_messages(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.DEBUG)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="internal error")

    client, http_client = make_client(handler)
    try:
        with pytest.raises(SearchError) as exc_info:
            await client.search("q")
    finally:
        await http_client.aclose()

    assert TEST_KEY not in str(exc_info.value)
    assert TEST_KEY not in caplog.text


# ---------------------------------------------------------------------------
# 并发控制
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_many_respects_concurrency_limit() -> None:
    state = {"current": 0, "max": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        state["current"] += 1
        state["max"] = max(state["max"], state["current"])
        await asyncio.sleep(0.02)
        state["current"] -= 1
        return httpx.Response(200, json=search_payload([]))

    client, http_client = make_client(handler, settings=make_settings(search_concurrency=3))
    try:
        results = await client.search_many([f"q{i}" for i in range(9)])
    finally:
        await http_client.aclose()

    assert len(results) == 9
    assert state["max"] == 3, f"并发峰值 {state['max']} 超过配置上限"
    assert client.concurrency == 3


@pytest.mark.asyncio
async def test_concurrency_limit_comes_from_settings() -> None:
    state = {"current": 0, "max": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        state["current"] += 1
        state["max"] = max(state["max"], state["current"])
        await asyncio.sleep(0.02)
        state["current"] -= 1
        return httpx.Response(200, json={"content": "x"})

    client, http_client = make_client(handler, settings=make_settings(search_concurrency=1))
    try:
        await client.fetch_many([f"https://example.com/{i}" for i in range(5)])
    finally:
        await http_client.aclose()

    assert state["max"] == 1
    assert client.concurrency == 1


@pytest.mark.asyncio
async def test_search_many_isolates_single_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["query"] == "bad":
            return httpx.Response(400, text="bad query")
        return httpx.Response(200, json=search_payload([{"url": "https://example.com/ok"}]))

    client, http_client = make_client(handler)
    try:
        results = await client.search_many(["ok1", "bad", "ok2"])
    finally:
        await http_client.aclose()

    statuses = [item.status for item in results]
    assert statuses == ["success", "error", "success"]
    assert results[1].error is not None
    assert "HTTP 400" in results[1].error


@pytest.mark.asyncio
async def test_fetch_many_isolates_single_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["url"].endswith("/bad"):
            return httpx.Response(500, text="boom")
        return httpx.Response(200, json={"content": "ok", "title": "t"})

    client, http_client = make_client(handler, max_attempts=1)
    try:
        results = await client.fetch_many(
            ["https://example.com/good", "https://example.com/bad"]
        )
    finally:
        await http_client.aclose()

    assert results[0].status == "success"
    assert results[1].status == "error"
    assert results[1].url == "https://example.com/bad"


@pytest.mark.asyncio
async def test_client_context_manager_closes_owned_client() -> None:
    async with DeepSeekClient(settings=make_settings()) as client:
        assert client.concurrency == 3
        # 自建客户端在退出时关闭，不应抛异常
