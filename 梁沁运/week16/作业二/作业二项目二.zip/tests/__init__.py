"""单元测试包。"""

import sys
from pathlib import Path

# 保证从项目根目录导入 config / scripts / services
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
