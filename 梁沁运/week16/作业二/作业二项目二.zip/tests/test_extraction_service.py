"""models/tender.py 与 services/extraction_service.py 的单元测试（不调用真实模型）。"""

from __future__ import annotations

import json
import logging
from datetime import date
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from pydantic import SecretStr, ValidationError

from config.settings import ConfigurationError, Settings
from models.tender import AnnouncementType, Industry, TenderRecord
from services.extraction_service import (
    ExtractionService,
    JSONParseError,
    ModelCallError,
    RecordValidationError,
    load_extraction_prompt,
    parse_model_json,
    truncate_content,
)

TEST_KEY = "sf-test-key-not-a-real-secret"
SOURCE_URL = "https://www.chnenergybidding.com.cn/bidweb/notice/123.html"


# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------


def make_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "siliconflow_api_key": SecretStr(TEST_KEY),
        "siliconflow_base_url": "https://api.siliconflow.cn/v1",
        "deepseek_model": "deepseek-ai/DeepSeek-V4.1-Flash",
        "request_timeout_seconds": 30.0,
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


class FakeCompletions:
    """模拟 ``client.chat.completions``。"""

    def __init__(
        self,
        content: str | None = None,
        *,
        error: Exception | None = None,
        choices: list[Any] | None = None,
    ) -> None:
        self.content = content
        self.error = error
        self.choices_override = choices
        self.calls: list[dict[str, Any]] = []

    async def create(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        if self.error is not None:
            raise self.error
        choices = (
            self.choices_override
            if self.choices_override is not None
            else [SimpleNamespace(message=SimpleNamespace(content=self.content))]
        )
        return SimpleNamespace(choices=choices)


class FakeClient:
    def __init__(self, completions: FakeCompletions) -> None:
        self.chat = SimpleNamespace(completions=completions)


def make_service(
    content: str | None = None,
    *,
    error: Exception | None = None,
    choices: list[Any] | None = None,
    settings: Settings | None = None,
    prompt: str = "SYSTEM PROMPT",
) -> tuple[ExtractionService, FakeCompletions]:
    completions = FakeCompletions(content, error=error, choices=choices)
    service = ExtractionService(
        settings=settings or make_settings(),
        client=FakeClient(completions),  # type: ignore[arg-type]
        prompt=prompt,
    )
    return service, completions


VALID_PAYLOAD: dict[str, Any] = {
    "project_name": "中国神华ESG治理体系优化及报告编制咨询服务公开招标项目",
    "announcement_type": "招标公告",
    "publish_date": "2026-06-23",
    "region": "北京市",
    "industry": "ESG 咨询 / 评级 / 报告编制",
    "buyer": "中国神华能源股份有限公司",
    "winning_supplier": None,
    "budget_amount": None,
    "ceiling_price": None,
    "bid_amount": None,
    "contract_amount": None,
    "amount_currency": "CNY",
    "project_code": "CEZB260105010",
    "source_title": "模型自己编的标题",
    "summary": "ESG 咨询服务公开招标",
    "confidence": 0.9,
    "remarks": "正文未披露金额",
}


def base_record(**overrides: Any) -> TenderRecord:
    payload = dict(VALID_PAYLOAD)
    payload.update(overrides)
    payload["source_url"] = SOURCE_URL
    return TenderRecord.model_validate(payload)


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------


def test_valid_record_creation() -> None:
    record = base_record()

    assert record.project_name.startswith("中国神华")
    assert record.announcement_type is AnnouncementType.TENDER
    assert record.publish_date == date(2026, 6, 23)
    assert record.industry is Industry.ESG_CONSULTING
    assert record.buyer == "中国神华能源股份有限公司"
    assert record.project_code == "CEZB260105010"
    assert record.confidence == pytest.approx(0.9)
    assert str(record.source_url).startswith("https://www.chnenergybidding.com.cn/")


def test_amounts_are_decimal_not_float() -> None:
    record = base_record(
        budget_amount="3000000",
        ceiling_price=3200000,
        bid_amount=2_890_000.5,
        contract_amount=Decimal("2880000.00"),
    )

    for field in ("budget_amount", "ceiling_price", "bid_amount", "contract_amount"):
        value = getattr(record, field)
        assert isinstance(value, Decimal), f"{field} 不是 Decimal"
        assert not isinstance(value, float)

    assert record.budget_amount == Decimal("3000000")
    assert record.bid_amount == Decimal("2890000.5")
    assert record.contract_amount == Decimal("2880000.00")


def test_amounts_default_to_none() -> None:
    record = base_record()

    assert record.budget_amount is None
    assert record.ceiling_price is None
    assert record.bid_amount is None
    assert record.contract_amount is None


def test_amount_fields_are_independent() -> None:
    only_bid = base_record(bid_amount="1200000")
    assert only_bid.bid_amount == Decimal("1200000")
    assert only_bid.budget_amount is None
    assert only_bid.ceiling_price is None
    assert only_bid.contract_amount is None

    only_budget = base_record(budget_amount="500000")
    assert only_budget.budget_amount == Decimal("500000")
    assert only_budget.bid_amount is None

    only_cap = base_record(ceiling_price="880000")
    assert only_cap.ceiling_price == Decimal("880000")
    assert only_cap.budget_amount is None
    assert only_cap.bid_amount is None

    all_four = base_record(
        budget_amount="100",
        ceiling_price="200",
        bid_amount="300",
        contract_amount="400",
    )
    assert {
        all_four.budget_amount,
        all_four.ceiling_price,
        all_four.bid_amount,
        all_four.contract_amount,
    } == {Decimal("100"), Decimal("200"), Decimal("300"), Decimal("400")}


def test_undisclosed_placeholders_become_none() -> None:
    record = base_record(
        budget_amount="未披露",
        ceiling_price="",
        bid_amount=None,
        contract_amount=" - ",
    )
    assert record.budget_amount is None
    assert record.ceiling_price is None
    assert record.contract_amount is None


def test_invalid_amounts_rejected() -> None:
    with pytest.raises(ValidationError):
        base_record(bid_amount="叁佰万元")
    with pytest.raises(ValidationError):
        base_record(bid_amount=-1)
    with pytest.raises(ValidationError):
        base_record(budget_amount=float("nan"))
    with pytest.raises(ValidationError):
        base_record(budget_amount=True)


def test_amount_currency() -> None:
    assert base_record().amount_currency == "CNY"
    assert base_record(amount_currency="usd").amount_currency == "USD"
    with pytest.raises(ValidationError):
        base_record(amount_currency="人民币")
    with pytest.raises(ValidationError):
        base_record(amount_currency="CN")


def test_publish_date_formats() -> None:
    assert base_record(publish_date="2026-06-23").publish_date == date(2026, 6, 23)
    assert base_record(publish_date="2026/06/23").publish_date == date(2026, 6, 23)
    assert base_record(publish_date="2026.6.3").publish_date == date(2026, 6, 3)
    assert base_record(publish_date="2026年6月23日").publish_date == date(2026, 6, 23)
    assert base_record(publish_date=None).publish_date is None
    assert base_record(publish_date="").publish_date is None


def test_invalid_publish_date_rejected() -> None:
    with pytest.raises(ValidationError):
        base_record(publish_date="2026-13-40")
    with pytest.raises(ValidationError):
        base_record(publish_date="昨天")


def test_confidence_bounds() -> None:
    assert base_record(confidence=0).confidence == 0.0
    assert base_record(confidence=1).confidence == 1.0
    with pytest.raises(ValidationError):
        base_record(confidence=1.01)
    with pytest.raises(ValidationError):
        base_record(confidence=-0.01)
    with pytest.raises(ValidationError):
        base_record(confidence=True)


def test_source_url_validation() -> None:
    payload = dict(VALID_PAYLOAD)
    payload["source_url"] = "not-a-url"
    with pytest.raises(ValidationError):
        TenderRecord.model_validate(payload)

    payload["source_url"] = "ftp://example.com/a"
    with pytest.raises(ValidationError):
        TenderRecord.model_validate(payload)


def test_industry_values_match_claude_md() -> None:
    assert {item.value for item in Industry} == {
        "新能源与储能",
        "节能环保与污染治理",
        "碳管理",
        "绿色建筑与市政",
        "绿色交通与物流",
        "资源循环与固废",
        "水务与水环境",
        "林业碳汇与生态",
        "数字化碳管理平台",
        "ESG 咨询 / 评级 / 报告编制",
        "其他",
    }


def test_industry_normalization_and_rejection() -> None:
    assert base_record(industry="ESG咨询/评级/报告编制").industry is Industry.ESG_CONSULTING
    assert base_record(industry="碳管理").industry is Industry.CARBON_MANAGEMENT
    with pytest.raises(ValidationError):
        base_record(industry="元宇宙")


def test_announcement_type_aliases_and_rejection() -> None:
    assert base_record(announcement_type="中标结果公告").announcement_type is AnnouncementType.AWARD
    assert base_record(announcement_type="变更公告").announcement_type is AnnouncementType.CORRECTION
    assert base_record(announcement_type="其他").announcement_type is AnnouncementType.OTHER
    with pytest.raises(ValidationError):
        base_record(announcement_type="废标公告")


def test_blank_optional_text_becomes_none() -> None:
    record = base_record(region=" ", buyer="", winning_supplier="无", remarks="  ")
    assert record.region is None
    assert record.buyer is None
    assert record.winning_supplier is None
    assert record.remarks is None


def test_empty_project_name_rejected() -> None:
    with pytest.raises(ValidationError):
        base_record(project_name="   ")


def test_award_statistics_flag() -> None:
    assert base_record(bid_amount="100").counts_toward_award_statistics is True
    assert base_record(budget_amount="100").counts_toward_award_statistics is False
    assert base_record().has_any_amount is False


# ---------------------------------------------------------------------------
# 提取服务
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_valid_model_json_converts_to_record() -> None:
    raw = "```json\n" + json.dumps(VALID_PAYLOAD, ensure_ascii=False) + "\n```"
    service, completions = make_service(raw)

    record = await service.extract_tender_record(
        "中国神华ESG治理体系优化及报告编制咨询服务公开招标项目……",
        SOURCE_URL,
        "网页标题",
    )

    assert record.project_name == VALID_PAYLOAD["project_name"]
    assert record.bid_amount is None
    # source_url / source_title 以调用方为准，不采用模型返回的值
    assert str(record.source_url).rstrip("/") == SOURCE_URL.rstrip("/")
    assert record.source_title == "网页标题"

    call = completions.calls[0]
    assert call["model"] == "deepseek-ai/DeepSeek-V4.1-Flash"
    assert call["temperature"] == 0.0
    assert call["messages"][0] == {"role": "system", "content": "SYSTEM PROMPT"}
    user_message = call["messages"][1]["content"]
    assert SOURCE_URL in user_message
    assert "网页标题" in user_message
    assert "<page_content>" in user_message


@pytest.mark.asyncio
async def test_model_source_url_is_ignored() -> None:
    payload = dict(VALID_PAYLOAD)
    payload["source_url"] = "https://evil.example.com/fake.html"
    service, _ = make_service(json.dumps(payload, ensure_ascii=False))

    record = await service.extract_tender_record("正文内容", SOURCE_URL)
    assert str(record.source_url).rstrip("/") == SOURCE_URL.rstrip("/")


@pytest.mark.asyncio
async def test_invalid_json_raises_parse_error() -> None:
    service, _ = make_service("抱歉，我无法完成这个任务。")

    with pytest.raises(JSONParseError) as exc_info:
        await service.extract_tender_record("正文内容", SOURCE_URL)

    assert TEST_KEY not in str(exc_info.value)


@pytest.mark.asyncio
async def test_empty_model_output_raises_parse_error() -> None:
    service, _ = make_service("   ")
    with pytest.raises(JSONParseError):
        await service.extract_tender_record("正文内容", SOURCE_URL)


@pytest.mark.asyncio
async def test_pydantic_violation_raises_record_validation_error() -> None:
    payload = dict(VALID_PAYLOAD)
    payload["confidence"] = 1.5
    payload["bid_amount"] = "-100"
    service, _ = make_service(json.dumps(payload, ensure_ascii=False))

    with pytest.raises(RecordValidationError) as exc_info:
        await service.extract_tender_record("正文内容", SOURCE_URL)

    assert exc_info.value.field_errors
    assert any("confidence" in item for item in exc_info.value.field_errors)
    assert TEST_KEY not in str(exc_info.value)


@pytest.mark.asyncio
async def test_model_call_failure_raises_model_call_error() -> None:
    service, _ = make_service(
        error=RuntimeError(f"401 unauthorized for key {TEST_KEY}")
    )

    with pytest.raises(ModelCallError) as exc_info:
        await service.extract_tender_record("正文内容", SOURCE_URL)

    message = str(exc_info.value)
    assert "RuntimeError" in message
    assert TEST_KEY not in message
    assert "***" in message


@pytest.mark.asyncio
async def test_empty_choices_raises_model_call_error() -> None:
    service, _ = make_service(choices=[])
    with pytest.raises(ModelCallError):
        await service.extract_tender_record("正文内容", SOURCE_URL)


@pytest.mark.asyncio
async def test_api_key_not_logged(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.DEBUG)
    raw = json.dumps(VALID_PAYLOAD, ensure_ascii=False)

    service, _ = make_service(raw)
    await service.extract_tender_record("正文内容", SOURCE_URL)

    failing_service, _ = make_service(error=RuntimeError(f"boom {TEST_KEY}"))
    with pytest.raises(ModelCallError):
        await failing_service.extract_tender_record("正文内容", SOURCE_URL)

    assert TEST_KEY not in caplog.text


@pytest.mark.asyncio
async def test_missing_config_raises_configuration_error() -> None:
    settings = make_settings(
        siliconflow_api_key=None, siliconflow_base_url=None, deepseek_model=None
    )
    service, completions = make_service("{}", settings=settings)

    with pytest.raises(ConfigurationError) as exc_info:
        await service.extract_tender_record("正文内容", SOURCE_URL)

    assert completions.calls == []
    message = str(exc_info.value)
    assert "SILICONFLOW_API_KEY" in message
    assert TEST_KEY not in message


@pytest.mark.asyncio
async def test_empty_content_rejected() -> None:
    service, completions = make_service("{}")
    with pytest.raises(ValueError):
        await service.extract_tender_record("   ", SOURCE_URL)
    assert completions.calls == []


# ---------------------------------------------------------------------------
# 辅助函数与 Prompt
# ---------------------------------------------------------------------------


def test_parse_model_json_handles_noise() -> None:
    raw = '这里是结果：\n```json\n{"project_name": "X", "nested": {"a": "}"}}\n```\n完成。'
    data = parse_model_json(raw)
    assert data["project_name"] == "X"


def test_parse_model_json_rejects_array() -> None:
    with pytest.raises(JSONParseError):
        parse_model_json("[1, 2, 3]")


def test_truncate_content() -> None:
    short = "短正文"
    assert truncate_content(short, 100) == short

    long_text = "A" * 10_000
    truncated = truncate_content(long_text, 1_000)
    assert len(truncated) < len(long_text)
    assert "正文过长" in truncated
    assert truncated.startswith("A")


def test_load_extraction_prompt_contains_key_rules() -> None:
    prompt = load_extraction_prompt()

    assert "最高限价" in prompt
    assert "不是指令" in prompt
    assert "budget_amount" in prompt
    assert "bid_amount" in prompt
    assert "contract_amount" in prompt
    assert "confidence" in prompt
    for industry in Industry:
        assert industry.value in prompt


def test_load_extraction_prompt_missing_file(tmp_path: Path) -> None:
    load_extraction_prompt.cache_clear()
    with pytest.raises(ConfigurationError):
        load_extraction_prompt(tmp_path / "missing.txt")
    load_extraction_prompt.cache_clear()
