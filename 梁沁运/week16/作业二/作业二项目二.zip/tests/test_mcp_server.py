"""mcp_server/server.py 的测试：工具注册与调用均委托现有业务函数。"""

from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

import mcp_server.server as server_module
from config.settings import get_settings

EXPECTED_TOOLS = {
    "run_historical_collection",
    "generate_historical_analysis",
    "run_daily_monitor",
    "query_tender_records",
    "get_analysis_report",
    "get_daily_report",
}


def test_tools_are_registered() -> None:
    tools = asyncio.run(server_module.mcp.list_tools())
    names = {tool.name for tool in tools}
    assert names == EXPECTED_TOOLS
    for tool in tools:
        assert tool.description and len(tool.description) > 5


def test_importing_mcp_server_does_not_start_scheduler() -> None:
    from services import scheduler_service as scheduler_module

    assert scheduler_module.get_scheduler() is None


async def call_tool(name: str, arguments: dict[str, Any] | None = None) -> Any:
    result = await server_module.mcp.call_tool(name, arguments or {})
    if isinstance(result, tuple):  # (content, structured)
        return result[1] if result[1] is not None else result[0]
    return result


@pytest.mark.asyncio
async def test_run_daily_monitor_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    async def fake_monitor(*, use_ai: bool = True) -> Any:
        captured["use_ai"] = use_ai
        return SimpleNamespace(as_dict=lambda: {"stats": {"inserted_count": 0}, "ok": True})

    monkeypatch.setattr(server_module, "run_daily_monitor", fake_monitor)

    payload = await call_tool("run_daily_monitor", {"use_ai": False})
    assert captured == {"use_ai": False}
    assert payload["ok"] is True


@pytest.mark.asyncio
async def test_run_historical_collection_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    async def fake_collection(*, max_urls: int | None = None) -> Any:
        captured["max_urls"] = max_urls
        return SimpleNamespace(
            as_dict=lambda: {"stats": {"inserted_count": 1}, "failures": list(range(50))}
        )

    monkeypatch.setattr(server_module, "run_historical_collection", fake_collection)

    payload = await call_tool("run_historical_collection", {"max_urls": 5})
    assert captured == {"max_urls": 5}
    assert len(payload["failures"]) == 20  # 失败列表被截断


@pytest.mark.asyncio
async def test_generate_analysis_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    async def fake_report(*, use_ai: bool = True) -> Any:
        captured["use_ai"] = use_ai
        return SimpleNamespace(as_dict=lambda: {"report_path": "output/r.md", "ai_used": use_ai})

    monkeypatch.setattr(server_module, "generate_historical_analysis_report", fake_report)

    payload = await call_tool("generate_historical_analysis", {"use_ai": False})
    assert captured == {"use_ai": False}
    assert payload["report_path"] == "output/r.md"


@pytest.mark.asyncio
async def test_query_tender_records_uses_repository(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from db.database import TendersDatabase
    from db.repository import TenderRepository
    from models.tender import TenderRecord

    database = TendersDatabase(path=tmp_path / "mcp.db")
    database.initialize()
    repo = TenderRepository(database)
    repo.save_record(
        TenderRecord.model_validate(
            {
                "project_name": "碳管理平台建设",
                "announcement_type": "招标公告",
                "industry": "碳管理",
                "confidence": 0.9,
                "source_url": "https://example.com/a.html",
            }
        )
    )
    repo.save_record(
        TenderRecord.model_validate(
            {
                "project_name": "ESG 报告编制",
                "announcement_type": "中标公告",
                "industry": "ESG 咨询 / 评级 / 报告编制",
                "confidence": 0.9,
                "source_url": "https://example.com/b.html",
            }
        )
    )
    payload = server_module.query_records(repo, limit=10)
    assert payload["total"] == 2
    assert {item["industry"] for item in payload["items"]} == {
        "碳管理",
        "ESG 咨询 / 评级 / 报告编制",
    }

    filtered = server_module.query_records(repo, announcement_type="招标公告")
    assert filtered["total"] == 1

    paged = server_module.query_records(repo, limit=1, offset=1)
    assert paged["total"] == 2 and len(paged["items"]) == 1

    with pytest.raises(ValueError):
        server_module.query_records(repo, limit=0)
    with pytest.raises(ValueError):
        server_module.query_records(repo, offset=-1)


@pytest.mark.asyncio
async def test_report_tools_read_output_files(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(server_module, "OUTPUT_DIR", tmp_path)
    (tmp_path / "historical_analysis_report.md").write_text("# 历史", encoding="utf-8")

    history = await call_tool("get_analysis_report")
    daily = await call_tool("get_daily_report")

    if isinstance(history, list):  # 兼容直接返回 content 列表的实现
        history = {"exists": "历史" in str(history), "markdown": str(history)}
    if isinstance(daily, list):
        daily = {"exists": False}
    assert history["exists"] is True
    assert "# 历史" in str(history["markdown"])
    assert daily["exists"] is False


def test_settings_timezone_unchanged() -> None:
    assert get_settings().app_timezone == "Asia/Shanghai"
