"""services/collection_service.py 的单元测试（Mock Search/Fetch/Extraction，不调用真实 API）。"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Any

import httpx
import pytest
from pydantic import SecretStr

from config.settings import ConfigurationError, Settings
from db.database import TendersDatabase
from db.repository import TenderRepository
from models.tender import TenderRecord
from scripts.date_utils import DateRange
from scripts.query_builder import HISTORICAL_KEYWORDS
from services.collection_service import run_historical_collection
from services.deepseek_client import DeepSeekClient
from services.extraction_service import RecordValidationError

TEST_KEY = "test-search-key-not-real"
SEARCH_BASE = "https://api.deepseek.com/v1/tools"
DATE_RANGE = DateRange(start=date(2025, 1, 1), end=date(2025, 12, 31))
QUERY_TEXTS = [f"{keyword} 2025" for keyword in HISTORICAL_KEYWORDS]


# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------


def make_settings() -> Settings:
    return Settings(
        _env_file=None,
        deepseek_search_api_key=SecretStr(TEST_KEY),
        deepseek_search_base_url=SEARCH_BASE,
        search_concurrency=3,
        request_timeout_seconds=5.0,
    )


class MockApi:
    """同时模拟 Search 与 Fetch 的 MockTransport 处理器。"""

    def __init__(
        self,
        search_map: dict[str, list[tuple[str, str]]] | None = None,
        fetch_map: dict[str, str] | None = None,
        failing_fetch: set[str] | None = None,
        empty_fetch: set[str] | None = None,
    ) -> None:
        self.search_map = search_map or {}
        self.fetch_map = fetch_map or {}
        self.failing_fetch = failing_fetch or set()
        self.empty_fetch = empty_fetch or set()
        self.search_calls: list[str] = []
        self.fetch_calls: list[str] = []

    async def __call__(self, request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/tools/search"):
            query = json.loads(request.content)["query"]
            self.search_calls.append(query)
            results = [
                {"url": url, "title": title}
                for url, title in self.search_map.get(query, [])
            ]
            return httpx.Response(200, json={"results": results})

        url = json.loads(request.content)["url"]
        self.fetch_calls.append(url)
        if url in self.failing_fetch:
            return httpx.Response(500, text="server error")
        if url in self.empty_fetch:
            return httpx.Response(200, json={"content": "   ", "title": "空页"})
        return httpx.Response(
            200,
            json={"content": self.fetch_map.get(url, f"{url} 的正文"), "title": "页面标题"},
        )


class FakeExtractor:
    """模拟 ExtractionService，可按 URL 制造失败。"""

    def __init__(self, failing_urls: set[str] | None = None) -> None:
        self.failing_urls = failing_urls or set()
        self.calls: list[tuple[str, str | None, str]] = []

    async def extract_tender_record(
        self, content: str, source_url: str, source_title: str | None = None
    ) -> TenderRecord:
        self.calls.append((source_url, source_title, content))
        if source_url in self.failing_urls:
            raise RecordValidationError("模型输出不符合招投标记录约束：confidence: 超出范围")
        return make_record(source_url=source_url, source_title=source_title)


def make_record(source_url: str, source_title: str | None = None, **overrides: Any) -> TenderRecord:
    payload: dict[str, Any] = {
        "project_name": "某 ESG 咨询服务项目",
        "announcement_type": "招标公告",
        "publish_date": "2025-06-01",
        "industry": "ESG 咨询 / 评级 / 报告编制",
        "buyer": "某能源股份有限公司",
        "project_code": "CEZB-TEST-001",
        "confidence": 0.8,
        "source_url": source_url,
        "source_title": source_title,
    }
    payload.update(overrides)
    return TenderRecord.model_validate(payload)


@pytest.fixture
def repo(tmp_path: Path) -> TenderRepository:
    database = TendersDatabase(path=tmp_path / "data" / "collection.db")
    database.initialize()
    return TenderRepository(database)


async def run(
    mock: MockApi,
    repo: TenderRepository,
    extractor: FakeExtractor | None = None,
    **kwargs: Any,
):
    http_client = httpx.AsyncClient(transport=httpx.MockTransport(mock))
    client = DeepSeekClient(
        settings=make_settings(),
        client=http_client,
        max_attempts=1,
        retry_backoff_seconds=0.0,
    )
    try:
        return await run_historical_collection(
            date_range=DATE_RANGE,
            client=client,
            extractor=extractor or FakeExtractor(),
            repository=repo,
            settings=make_settings(),
            **kwargs,
        )
    finally:
        await http_client.aclose()


# ---------------------------------------------------------------------------
# 正常流程
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_flow_search_fetch_extract_save(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/a.html", "公告 A"),
                ("https://example.com/b.html", "公告 B"),
            ]
        }
    )

    report = await run(mock, repo)

    stats = report.stats
    assert stats.query_count == len(HISTORICAL_KEYWORDS)
    assert stats.search_url_count == 2
    assert stats.unique_url_count == 2
    assert stats.skipped_existing_count == 0
    assert stats.fetch_success_count == 2
    assert stats.fetch_failed_count == 0
    assert stats.extraction_success_count == 2
    assert stats.extraction_failed_count == 0
    assert stats.inserted_count == 2
    assert stats.duplicate_count == 0
    assert stats.save_failed_count == 0

    assert repo.count() == 2
    assert len(report.inserted_record_ids) == 2
    stored = repo.get_by_source_url("https://example.com/a.html")
    assert stored is not None
    assert stored.source_title == "页面标题"
    assert report.failures == []
    assert len(mock.search_calls) == len(HISTORICAL_KEYWORDS)
    assert mock.fetch_calls == ["https://example.com/a.html", "https://example.com/b.html"]


@pytest.mark.asyncio
async def test_same_url_across_queries_fetched_once(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [("https://example.com/a.html", "公告 A")],
            QUERY_TEXTS[1]: [
                ("https://example.com/a.html", "公告 A（重复）"),
                ("https://example.com/c.html", "公告 C"),
            ],
        }
    )

    report = await run(mock, repo)

    assert report.stats.search_url_count == 3
    assert report.stats.unique_url_count == 2
    assert report.stats.inserted_count == 2
    assert mock.fetch_calls == ["https://example.com/a.html", "https://example.com/c.html"]


@pytest.mark.asyncio
async def test_existing_url_is_not_fetched(repo: TenderRepository) -> None:
    existing = make_record(source_url="https://example.com/a.html")
    repo.save_record(existing)
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/a.html", "已存在"),
                ("https://example.com/new.html", "新公告"),
            ]
        }
    )

    report = await run(mock, repo)

    assert report.stats.skipped_existing_count == 1
    assert report.stats.inserted_count == 1
    assert mock.fetch_calls == ["https://example.com/new.html"]
    assert repo.count() == 2


# ---------------------------------------------------------------------------
# 异常隔离
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fetch_failure_does_not_stop_run(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/bad.html", "坏页面"),
                ("https://example.com/good.html", "好页面"),
            ]
        },
        failing_fetch={"https://example.com/bad.html"},
    )

    report = await run(mock, repo)

    stats = report.stats
    assert stats.fetch_failed_count == 1
    assert stats.fetch_success_count == 1
    assert stats.extraction_success_count == 1
    assert stats.inserted_count == 1
    assert len(report.failures) == 1
    assert report.failures[0].stage == "fetch"
    assert report.failures[0].url == "https://example.com/bad.html"
    assert repo.count() == 1


@pytest.mark.asyncio
async def test_empty_fetch_content_counts_as_fetch_failure(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={QUERY_TEXTS[0]: [("https://example.com/empty.html", "空页面")]},
        empty_fetch={"https://example.com/empty.html"},
    )

    report = await run(mock, repo)

    assert report.stats.fetch_failed_count == 1
    assert report.failures[0].error == "正文为空"
    assert repo.count() == 0


@pytest.mark.asyncio
async def test_extraction_failure_does_not_stop_run(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/bad.html", "提取失败"),
                ("https://example.com/good.html", "提取成功"),
            ]
        }
    )
    extractor = FakeExtractor(failing_urls={"https://example.com/bad.html"})

    report = await run(mock, repo, extractor=extractor)

    stats = report.stats
    assert stats.fetch_success_count == 2
    assert stats.extraction_failed_count == 1
    assert stats.extraction_success_count == 1
    assert stats.inserted_count == 1
    assert report.failures[0].stage == "extraction"
    assert "RecordValidationError" in report.failures[0].error
    assert repo.count() == 1


@pytest.mark.asyncio
async def test_configuration_error_is_not_swallowed(repo: TenderRepository) -> None:
    class BrokenExtractor(FakeExtractor):
        async def extract_tender_record(self, content, source_url, source_title=None):
            raise ConfigurationError("结构化提取缺少必要配置：SILICONFLOW_API_KEY。")

    mock = MockApi(search_map={QUERY_TEXTS[0]: [("https://example.com/a.html", "A")]})

    with pytest.raises(ConfigurationError):
        await run(mock, repo, extractor=BrokenExtractor())


# ---------------------------------------------------------------------------
# 入库统计
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_duplicate_at_save_is_counted(repo: TenderRepository, monkeypatch: pytest.MonkeyPatch) -> None:
    repo.save_record(make_record(source_url="https://example.com/a.html"))
    # 模拟"检查时不存在、入库时已存在"的竞争情形
    monkeypatch.setattr(repo, "exists_by_url", lambda url: False)

    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/a.html", "已存在"),
                ("https://example.com/new.html", "新公告"),
            ]
        }
    )

    report = await run(mock, repo)

    assert report.stats.skipped_existing_count == 0
    assert report.stats.extraction_success_count == 2
    assert report.stats.inserted_count == 1
    assert report.stats.duplicate_count == 1
    assert repo.count() == 2


# ---------------------------------------------------------------------------
# 边界情况
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_empty_search_results_finish_normally(repo: TenderRepository) -> None:
    mock = MockApi(search_map={})

    report = await run(mock, repo)

    assert report.stats.query_count == len(HISTORICAL_KEYWORDS)
    assert report.stats.search_url_count == 0
    assert report.stats.unique_url_count == 0
    assert report.stats.fetch_success_count == 0
    assert report.stats.inserted_count == 0
    assert report.failures == []
    assert mock.fetch_calls == []
    assert repo.count() == 0
    assert len(mock.search_calls) == len(HISTORICAL_KEYWORDS)


@pytest.mark.asyncio
async def test_max_urls_limits_processed_urls(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={
            QUERY_TEXTS[0]: [
                ("https://example.com/1.html", "1"),
                ("https://example.com/2.html", "2"),
                ("https://example.com/3.html", "3"),
            ]
        }
    )

    report = await run(mock, repo, max_urls=2)

    assert report.stats.unique_url_count == 3
    assert len(mock.fetch_calls) == 2
    assert report.stats.inserted_count == 2

    with pytest.raises(ValueError):
        await run(mock, repo, max_urls=0)


@pytest.mark.asyncio
async def test_report_serializes_to_json(repo: TenderRepository) -> None:
    mock = MockApi(
        search_map={QUERY_TEXTS[0]: [("https://example.com/a.html", "A")]},
        failing_fetch={"https://example.com/b.html"},
    )
    mock.search_map[QUERY_TEXTS[1]] = [("https://example.com/b.html", "B")]

    report = await run(mock, repo)
    payload = json.loads(json.dumps(report.as_dict(), ensure_ascii=False))

    assert payload["date_range"] == "2025-01-01 ~ 2025-12-31"
    assert payload["stats"]["query_count"] == len(HISTORICAL_KEYWORDS)
    assert payload["stats"]["fetch_failed_count"] == 1
    assert payload["failures"][0]["stage"] == "fetch"
    assert payload["duration_seconds"] >= 0
    assert "started_at" in payload and "finished_at" in payload
