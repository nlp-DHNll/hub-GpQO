"""项目配置模块。

所有外部 API 配置集中在这里管理，具体值从项目根目录的 `.env` 读取。
本模块在导入时不会强制要求任何 API Key 存在；只有显式调用
`get_settings().require_ready()` 或 `validate_required_settings()` 时
才会检查必填配置，并给出清晰的中文提示。
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Final

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parent.parent
ENV_FILE: Final[Path] = PROJECT_ROOT / ".env"
OUTPUT_DIR: Final[Path] = PROJECT_ROOT / "output"

# 必填环境变量。具体 API 地址和模型 ID 必须以服务商官方文档为准。
REQUIRED_ENV_VARS: Final[tuple[str, ...]] = (
    "SILICONFLOW_API_KEY",
    "SILICONFLOW_BASE_URL",
    "DEEPSEEK_MODEL",
    "DEEPSEEK_SEARCH_API_KEY",
    "DEEPSEEK_SEARCH_BASE_URL",
    "JINA_API_KEY",
    "BGE_RERANKER_MODEL",
)

# 工作流中由 CLAUDE.md 固定的约束，不作为环境变量暴露。
MAX_SEARCH_CONCURRENCY: Final[int] = 3
RERANK_TOP_K_MIN: Final[int] = 3
RERANK_TOP_K_MAX: Final[int] = 5
DEFAULT_REQUEST_TIMEOUT_SECONDS: Final[float] = 30.0


class ConfigurationError(RuntimeError):
    """必填配置缺失时抛出的异常。"""


def _read_env(name: str) -> str | None:
    """读取环境变量，去除首尾空白；空字符串视为未配置。"""
    value = os.getenv(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


@dataclass(frozen=True)
class Settings:
    """集中管理的运行配置。"""

    # 硅基流动：Planner / Writer（DeepSeek）与 Reranker（BGE）
    siliconflow_api_key: str | None = None
    siliconflow_base_url: str | None = None
    deepseek_model: str | None = None
    bge_reranker_model: str | None = None

    # DeepSeek Web Search
    deepseek_search_api_key: str | None = None
    deepseek_search_base_url: str | None = None

    # Jina Reader
    jina_api_key: str | None = None

    # 本地路径与流程参数
    output_dir: Path = OUTPUT_DIR
    search_concurrency: int = MAX_SEARCH_CONCURRENCY
    request_timeout_seconds: float = DEFAULT_REQUEST_TIMEOUT_SECONDS
    rerank_top_k_min: int = RERANK_TOP_K_MIN
    rerank_top_k_max: int = RERANK_TOP_K_MAX

    def missing_required(self) -> list[str]:
        """返回缺失的必填环境变量名列表。"""
        checks = {
            "SILICONFLOW_API_KEY": self.siliconflow_api_key,
            "SILICONFLOW_BASE_URL": self.siliconflow_base_url,
            "DEEPSEEK_MODEL": self.deepseek_model,
            "DEEPSEEK_SEARCH_API_KEY": self.deepseek_search_api_key,
            "DEEPSEEK_SEARCH_BASE_URL": self.deepseek_search_base_url,
            "JINA_API_KEY": self.jina_api_key,
            "BGE_RERANKER_MODEL": self.bge_reranker_model,
        }
        return [name for name in REQUIRED_ENV_VARS if not checks[name]]

    def require_ready(self) -> None:
        """检查必填配置；缺失时抛出带提示的 ConfigurationError。"""
        missing = self.missing_required()
        if not missing:
            return

        message = (
            "缺少必要的 API 配置：\n"
            + "\n".join(f"  - {name}" for name in missing)
            + f"\n\n请将 {ENV_FILE.name}.example 复制为 {ENV_FILE.name}，"
            "并按服务商官方文档填写上述变量。\n"
            f"配置文件位置：{ENV_FILE}\n"
            "注意：.env 包含密钥，不要提交到代码仓库。"
        )
        logger.error(message)
        raise ConfigurationError(message)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """加载 `.env` 并返回配置对象（结果会被缓存）。"""
    load_dotenv(dotenv_path=ENV_FILE, override=False)
    if not ENV_FILE.exists():
        logger.info("未找到 %s，当前仅使用系统环境变量。", ENV_FILE)

    return Settings(
        siliconflow_api_key=_read_env("SILICONFLOW_API_KEY"),
        siliconflow_base_url=_read_env("SILICONFLOW_BASE_URL"),
        deepseek_model=_read_env("DEEPSEEK_MODEL"),
        bge_reranker_model=_read_env("BGE_RERANKER_MODEL"),
        deepseek_search_api_key=_read_env("DEEPSEEK_SEARCH_API_KEY"),
        deepseek_search_base_url=_read_env("DEEPSEEK_SEARCH_BASE_URL"),
        jina_api_key=_read_env("JINA_API_KEY"),
    )


def validate_required_settings(settings: Settings | None = None) -> None:
    """显式校验必填配置，供正式运行前调用。"""
    (settings or get_settings()).require_ready()
