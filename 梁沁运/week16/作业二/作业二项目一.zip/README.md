# ESG Monthly Report Agent

一个用于生成企业 ESG 月报的 Agent 课程作业项目，以中国神华为案例。

工作流：

```text
Planner → Researcher → Reader → Reranker → Writer
```

- **Planner**：将用户需求拆解为 2～5 个具体搜索 Query。
- **Researcher**：调用 DeepSeek Web Search 获取真实搜索结果。
- **Reader**：调用 Jina Reader 获取网页 Markdown 正文。
- **Reranker**：调用 BGE Reranker 进行相关性排序，保留 Top 3～5 材料。
- **Writer**：调用 DeepSeek 生成结构完整、来源可追溯的 Markdown 月报。

确定性工作（格式校验、并发控制、去重、排序、文件保存等）由 Python Script 完成。

## 当前开发进度

已完成：

- 基础工程搭建：目录结构、配置模块、依赖清单、项目入口。
- `config/settings.py`：集中读取 `.env`，按需校验必填配置。
- `main.py`：项目入口（当前仅做启动检查）。

尚未开始：

- Planner、Researcher、Reader、Reranker、Writer 五个业务节点。
- 搜索、网页读取、重排等服务模块。
- 报告校验脚本与业务测试。
- 真实 API 联调。

## 运行环境

使用 PyCharm 当前已配置的 Miniconda3 base 环境，不要新建 Conda 环境。

- 解释器：`C:\Apps\Miniconda3\python.exe`
- Python：3.12.8

所需依赖已安装。如需在新环境复现：

```bash
pip install -r requirements.txt
```

## 配置

复制环境变量示例并按服务商官方文档填写：

```bash
copy .env.example .env
```

`.env` 包含密钥，已被 `.gitignore` 忽略，不要提交。

API 地址和模型 ID 以服务商实际文档为准，不要使用猜测值。

## 运行

在项目根目录执行：

```bash
C:\Apps\Miniconda3\python.exe main.py
```

或在 PyCharm 中直接运行 `main.py`。

当前输出：

```text
ESG Monthly Report Agent
Project initialization successful.
```

## 目录结构

```text
ESG Monthly Report Agent/
├── CLAUDE.md
├── main.py
├── config/          # 配置
├── agents/          # 五个业务节点（待实现）
├── services/        # 外部 API 服务封装（待实现）
├── scripts/         # 确定性校验脚本（待实现）
├── prompts/         # 提示词
├── output/          # 生成的报告
└── tests/           # 测试
```

## Docker 运行

项目一是**一次性命令行任务**（生成一份月报后退出），因此 Compose 只含一个 `app` 服务，不使用常驻模式。

```bash
docker compose config --quiet          # 校验配置（不输出变量值）
docker compose build                   # 构建镜像
docker compose run --rm app --help     # 查看 CLI 参数（不调用 API）
docker compose run --rm app --company 中国神华 --month 2026-10   # 生成月报（会调用真实 API）
```

说明：

- 密钥来自项目根目录 `.env`（`env_file`），不进镜像；`.env` 不会被修改。
- 报告输出目录：宿主机 `./output` ↔ 容器 `/app/output`，生成的文件直接落在宿主机。
- 容器内工作目录为 `/app`，可通过 `docker compose run --rm -T app ...` 以非交互方式在脚本中使用。
- 未配置 `restart`：任务跑完即退出，适合手动或外部调度（如宿主 cron）触发。
