"""Researcher 节点：按 SearchPlan 并发调用 DeepSeek Search API。

只负责检索和保留原始结果，不做网页正文抓取、摘要改写或相关性排序。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Literal
from urllib.parse import urlsplit, urlunsplit

import httpx
from pydantic import BaseModel, Field

from agents.planner import SearchPlan, SearchQuery
from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

# DeepSeek Search API 约束
SEARCH_RESULT_COUNT = 10
MAX_QUERY_LENGTH = 128

# 并发与重试
SEARCH_CONCURRENCY = 3
MAX_ATTEMPTS = 2
RETRY_BACKOFF_SECONDS = 0.5
ERROR_BODY_PREVIEW = 300

QueryStatus = Literal["success", "empty", "error"]


class ResearcherError(RuntimeError):
    """Researcher 运行失败。"""


class SearchResultItem(BaseModel):
    """单条搜索结果：保留 API 原始字段和原始 JSON。"""

    title: str = ""
    url: str
    snippet: str = ""
    summary: str = ""
    content: str = ""
    site_name: str | None = None
    site_icon: str | None = None
    date: str | None = None
    authority: int | None = None
    rerank_score: float | None = None
    source_query_ids: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class QuerySearchResult(BaseModel):
    """单条 Query 的执行记录。"""

    query_id: str
    topic: str
    search_query: str
    time_range: str
    status: QueryStatus
    results: list[SearchResultItem] = Field(default_factory=list)
    error: str | None = None
    raw_response: dict[str, Any] | None = None
    attempts: int = 0


class ResearchResult(BaseModel):
    """整个 Researcher 节点的输出。"""

    company: str
    report_month: str
    query_results: list[QuerySearchResult] = Field(default_factory=list)
    results: list[SearchResultItem] = Field(default_factory=list)


def build_search_endpoint(base_url: str) -> str:
    """兼容多种 Base URL 写法，返回完整 Search API Endpoint。"""
    base = base_url.strip().rstrip("/")
    if not base:
        raise ResearcherError("DEEPSEEK_SEARCH_BASE_URL 不能为空")
    if base.endswith("/v1/tools/search"):
        return base
    if base.endswith("/v1/tools"):
        return f"{base}/search"
    if base.endswith("/v1"):
        return f"{base}/tools/search"
    return f"{base}/v1/tools/search"


def normalize_url(url: str) -> str:
    """URL 去重用的规范化：忽略协议/域名大小写、片段和末尾斜杠。"""
    value = url.strip()
    parts = urlsplit(value)
    if not parts.scheme and not parts.netloc:
        return value.lower().rstrip("/")
    path = parts.path.rstrip("/") or "/"
    return urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), path, parts.query, "")
    )


def strip_url_fragment(url: str) -> str:
    """去掉 URL 片段（如搜索结果附带的 #1），便于后续 Reader 直接抓取。"""
    parts = urlsplit(url.strip())
    if not parts.scheme and not parts.netloc:
        return url.strip()
    return urlunsplit((parts.scheme, parts.netloc, parts.path, parts.query, ""))


def _as_text(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _as_optional_text(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _as_optional_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _as_optional_float(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _extract_item(raw: Any, query_id: str) -> SearchResultItem | None:
    """从单条原始结果中提取字段；无有效 URL 的结果会被丢弃。"""
    if not isinstance(raw, dict):
        return None

    url = raw.get("url")
    if not isinstance(url, str) or not url.strip():
        return None

    return SearchResultItem(
        title=_as_text(raw.get("title")),
        url=strip_url_fragment(url),
        snippet=_as_text(raw.get("snippet")),
        summary=_as_text(raw.get("summary")),
        content=_as_text(raw.get("content")),
        site_name=_as_optional_text(raw.get("site_name")),
        site_icon=_as_optional_text(raw.get("site_icon")),
        date=_as_optional_text(raw.get("date")),
        authority=_as_optional_int(raw.get("authority")),
        rerank_score=_as_optional_float(raw.get("rerank_score")),
        source_query_ids=[query_id],
        raw=dict(raw),
    )


def _deduplicate_results(
    query_results: list[QuerySearchResult],
) -> list[SearchResultItem]:
    """跨 Query 按 URL 去重，并合并来源 Query 编号。"""
    merged: dict[str, SearchResultItem] = {}

    for query_result in query_results:
        for item in query_result.results:
            key = normalize_url(item.url)
            if key not in merged:
                merged[key] = item.model_copy(deep=True)
                continue

            existing = merged[key]
            for query_id in item.source_query_ids:
                if query_id not in existing.source_query_ids:
                    existing.source_query_ids.append(query_id)
            if not existing.title and item.title:
                existing.title = item.title
            if not existing.snippet and item.snippet:
                existing.snippet = item.snippet
            if not existing.summary and item.summary:
                existing.summary = item.summary

    return list(merged.values())


class Researcher:
    """按 SearchPlan 执行搜索。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        max_attempts: int = MAX_ATTEMPTS,
        retry_backoff_seconds: float = RETRY_BACKOFF_SECONDS,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts 必须至少为 1")
        self._settings = settings or get_settings()
        self._client = client
        self._max_attempts = max_attempts
        self._retry_backoff_seconds = max(0.0, retry_backoff_seconds)
        self._timeout = self._settings.request_timeout_seconds

    def _require_settings(self) -> None:
        """Search API 使用独立的 DeepSeek 官方 Key，不能复用 SiliconFlow Key。"""
        missing = [
            name
            for name, value in (
                ("DEEPSEEK_SEARCH_API_KEY", self._settings.deepseek_search_api_key),
                ("DEEPSEEK_SEARCH_BASE_URL", self._settings.deepseek_search_base_url),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "Researcher 缺少必要配置："
                + "、".join(missing)
                + "。请配置 DeepSeek 官方 Search API 的 Key 和地址，"
                "不要复用 SILICONFLOW_API_KEY。"
            )

    async def research(self, plan: SearchPlan) -> ResearchResult:
        """并发执行计划中的每条 Query，单条失败不影响其他 Query。"""
        self._require_settings()
        assert self._settings.deepseek_search_base_url is not None  # 已校验

        endpoint = build_search_endpoint(self._settings.deepseek_search_base_url)
        concurrency = max(1, self._settings.search_concurrency)
        semaphore = asyncio.Semaphore(concurrency)

        owns_client = self._client is None
        client = self._client or httpx.AsyncClient()
        logger.info(
            "Researcher 开始：%d 条 Query，并发上限 %d，端点 %s",
            len(plan.queries),
            concurrency,
            endpoint,
        )

        async def run_one(query: SearchQuery) -> QuerySearchResult:
            async with semaphore:
                try:
                    return await self._search_query(client, endpoint, query)
                except Exception as exc:  # 保证异常被记录，不中断其他 Query
                    logger.exception("Query %s 出现未预期异常", query.query_id)
                    return self._error_result(query, f"未预期错误：{exc}", attempts=0)

        try:
            outcomes = await asyncio.gather(
                *(run_one(query) for query in plan.queries),
                return_exceptions=True,
            )
        finally:
            if owns_client:
                await client.aclose()

        query_results: list[QuerySearchResult] = []
        for query, outcome in zip(plan.queries, outcomes):
            if isinstance(outcome, BaseException):
                logger.error("Query %s 执行失败：%s", query.query_id, outcome)
                query_results.append(
                    self._error_result(query, f"未预期错误：{outcome}", attempts=0)
                )
            else:
                query_results.append(outcome)

        deduplicated = _deduplicate_results(query_results)
        success = sum(1 for item in query_results if item.status == "success")
        empty = sum(1 for item in query_results if item.status == "empty")
        failed = sum(1 for item in query_results if item.status == "error")
        logger.info(
            "Researcher 完成：成功 %d，空结果 %d，失败 %d，去重后 %d 条结果",
            success,
            empty,
            failed,
            len(deduplicated),
        )

        return ResearchResult(
            company=plan.company,
            report_month=plan.report_month,
            query_results=query_results,
            results=deduplicated,
        )

    async def _search_query(
        self,
        client: httpx.AsyncClient,
        endpoint: str,
        query: SearchQuery,
    ) -> QuerySearchResult:
        if not 1 <= len(query.search_query) <= MAX_QUERY_LENGTH:
            return self._error_result(
                query,
                f"search_query 长度必须在 1～{MAX_QUERY_LENGTH} 字符之间",
                attempts=0,
            )

        payload = {
            "query": query.search_query,
            "count": SEARCH_RESULT_COUNT,
            "need_content": False,
        }
        last_error = "未知错误"

        for attempt in range(1, self._max_attempts + 1):
            try:
                response = await client.post(
                    endpoint,
                    headers={
                        "Authorization": f"Bearer {self._settings.deepseek_search_api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                    timeout=self._timeout,
                )
            except httpx.TimeoutException:
                last_error = f"请求超时（{self._timeout} 秒）"
                logger.warning("Query %s 第 %d 次请求超时", query.query_id, attempt)
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                return self._error_result(query, last_error, attempts=attempt)
            except httpx.HTTPError as exc:
                last_error = f"HTTP 请求异常：{type(exc).__name__}: {exc}"
                logger.warning("Query %s 第 %d 次请求异常：%s", query.query_id, attempt, exc)
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                return self._error_result(query, last_error, attempts=attempt)

            if 200 <= response.status_code < 300:
                return self._parse_success(query, response, attempt)

            body_preview = response.text[:ERROR_BODY_PREVIEW]
            last_error = f"HTTP {response.status_code}：{body_preview}"
            retryable = response.status_code == 429 or 500 <= response.status_code < 600
            if retryable and attempt < self._max_attempts:
                logger.warning(
                    "Query %s 第 %d 次返回 HTTP %d，准备重试",
                    query.query_id,
                    attempt,
                    response.status_code,
                )
                await asyncio.sleep(self._retry_backoff_seconds * attempt)
                continue
            return self._error_result(query, last_error, attempts=attempt)

        return self._error_result(query, last_error, attempts=self._max_attempts)

    def _parse_success(
        self,
        query: SearchQuery,
        response: httpx.Response,
        attempts: int,
    ) -> QuerySearchResult:
        try:
            payload = response.json()
        except ValueError as exc:
            return self._error_result(
                query, f"搜索响应不是合法 JSON：{exc}", attempts=attempts
            )

        if not isinstance(payload, dict):
            return self._error_result(
                query, "搜索响应 JSON 顶层不是对象", attempts=attempts
            )

        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            return self._error_result(
                query, "搜索响应缺少 results 数组", attempts=attempts
            )

        items: list[SearchResultItem] = []
        seen_urls: set[str] = set()
        for raw in raw_results:
            item = _extract_item(raw, query.query_id)
            if item is None:
                continue
            key = normalize_url(item.url)
            if key in seen_urls:
                continue
            seen_urls.add(key)
            items.append(item)

        return QuerySearchResult(
            query_id=query.query_id,
            topic=query.topic,
            search_query=query.search_query,
            time_range=query.time_range,
            status="success" if items else "empty",
            results=items,
            raw_response=payload,
            attempts=attempts,
        )

    @staticmethod
    def _error_result(
        query: SearchQuery,
        message: str,
        attempts: int,
    ) -> QuerySearchResult:
        return QuerySearchResult(
            query_id=query.query_id,
            topic=query.topic,
            search_query=query.search_query,
            time_range=query.time_range,
            status="error",
            results=[],
            error=message,
            attempts=attempts,
        )
