"""Writer 节点：依据 Reranker 精排结果生成中文 Markdown ESG 月报。

使用硅基流动 OpenAI 兼容接口。只负责生成报告，不负责主流程编排或文件保存。
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from string import Template

from openai import AsyncOpenAI
from pydantic import BaseModel, Field

from agents.reranker import RankedPage, RerankResult
from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "writer_prompt.txt"

DEFAULT_MAX_TOKENS = 4096
DEFAULT_TEMPERATURE = 0.3
MAX_CHARS_PER_SOURCE = 8000

REQUIRED_HEADING_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("政策", "ESG 政策、评级、标准及监管动态"),
    ("行业", "行业 ESG 新闻动态与最佳实践"),
    ("自身", "企业自身 ESG 动态、影响及改进建议"),
    ("重点总结", "本月重点总结"),
    ("信息来源", "信息来源"),
)


class WriterError(RuntimeError):
    """Writer 调用或报告生成失败。"""


class ReportSource(BaseModel):
    """报告资料来源。"""

    source_id: str
    title: str
    url: str


class ReportOutput(BaseModel):
    """Writer 输出。"""

    company: str
    report_month: str
    title: str
    markdown: str
    sources: list[ReportSource] = Field(default_factory=list)
    cited_source_ids: list[str] = Field(default_factory=list)


def format_report_month(value: str) -> str:
    """把 2026-10 / 2026年10月 统一为 2026年10月。"""
    match = re.search(r"(?P<year>\d{4})\D{0,4}(?P<month>\d{1,2})", value)
    if match is None:
        return value
    return f"{int(match.group('year'))}年{int(match.group('month'))}月"


def _valid_pages(result: RerankResult) -> list[RankedPage]:
    return [
        page
        for page in result.selected
        if page.url.strip() and page.content.strip()
    ]


def build_source_materials(pages: list[RankedPage]) -> tuple[str, list[ReportSource]]:
    """构造带编号的资料库；只在过长时截断，不改写或摘要。"""
    blocks: list[str] = []
    sources: list[ReportSource] = []
    for index, page in enumerate(pages, start=1):
        source_id = f"S{index}"
        title = page.title.strip() or "未命名网页"
        content = page.content.strip()
        if len(content) > MAX_CHARS_PER_SOURCE:
            content = content[:MAX_CHARS_PER_SOURCE] + "\n\n[资料过长，此处截断]"
        topics = "、".join(page.topic_scores.keys()) or "未标注"
        blocks.append(
            f"[{source_id}] 标题：{title}\n"
            f"URL：{page.url}\n"
            f"相关主题：{topics}\n"
            f"正文：\n{content}"
        )
        sources.append(ReportSource(source_id=source_id, title=title, url=page.url))
    return "\n\n---\n\n".join(blocks), sources


def build_system_prompt(
    company: str,
    report_month_cn: str,
    source_materials: str,
) -> str:
    if not PROMPT_PATH.exists():
        raise WriterError(f"提示词文件不存在：{PROMPT_PATH}")
    template = Template(PROMPT_PATH.read_text(encoding="utf-8"))
    return template.substitute(
        company=company,
        report_month_cn=report_month_cn,
        title_example=f"{company} {report_month_cn} ESG 月报",
        source_materials=source_materials,
    )


def strip_code_fences(markdown: str) -> str:
    """模型偶尔会把整篇报告包在 Markdown 代码块中，这里去掉最外层围栏。"""
    text = markdown.strip()
    match = re.fullmatch(r"```(?:markdown|md)?\s*\n(.*?)\n```", text, re.DOTALL | re.IGNORECASE)
    if match is not None:
        return match.group(1).strip()
    return text


def ensure_title(markdown: str, company: str, report_month_cn: str) -> tuple[str, str]:
    """保证一级标题包含企业名称和报告月份。"""
    lines = markdown.splitlines()
    expected_title = f"{company} {report_month_cn} ESG 月报"
    first_line = lines[0].strip() if lines else ""

    if first_line.startswith("# ") and company in first_line and report_month_cn in first_line:
        return markdown, first_line[2:].strip()

    if first_line.startswith("# "):
        body = "\n".join(lines[1:]).lstrip()
        markdown = f"# {expected_title}\n\n{body}"
    else:
        markdown = f"# {expected_title}\n\n{markdown.lstrip()}"
    return markdown, expected_title


def validate_report_structure(markdown: str) -> None:
    """检查固定板块是否齐全；缺失时给出明确错误。"""
    headings = re.findall(r"^##\s+(.+)$", markdown, re.MULTILINE)
    missing = [
        label
        for keyword, label in REQUIRED_HEADING_KEYWORDS
        if not any(keyword in heading for heading in headings)
    ]
    if missing:
        raise WriterError("报告结构不完整，缺少板块：" + "、".join(missing))


def _empty_report(company: str, report_month: str, report_month_cn: str) -> ReportOutput:
    """没有有效精排资料时生成不含推断内容的说明性报告。"""
    title = f"{company} {report_month_cn} ESG 月报"
    markdown = f"""# {title}

> 本月未收集到有效网页资料。以下板块仅说明资料情况，不包含任何推断或虚构内容。

## 一、ESG 政策、评级、标准及监管动态

资料不足，本月暂无法汇总相关政策、评级或监管动态。

## 二、{company} 所属行业 ESG 新闻动态与最佳实践

资料不足，本月暂无法汇总行业 ESG 新闻或最佳实践。

## 三、{company} 自身 ESG 动态、影响及改进建议

资料不足，本月暂无法分析 {company} 自身的 ESG 动态、影响或提出改进建议。

## 本月重点总结

本月未收集到可用于撰写报告的有效资料。

## 信息来源

无（本月未获取到有效网页资料）。
"""
    return ReportOutput(
        company=company,
        report_month=report_month,
        title=title,
        markdown=markdown,
    )


class Writer:
    """依据 RerankResult 生成 ESG 月报。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: AsyncOpenAI | None = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
    ) -> None:
        if max_tokens < 1:
            raise ValueError("max_tokens 必须至少为 1")
        self._settings = settings or get_settings()
        self._client = client
        self._max_tokens = max_tokens
        self._temperature = temperature

    def _require_settings(self) -> None:
        missing = [
            name
            for name, value in (
                ("SILICONFLOW_API_KEY", self._settings.siliconflow_api_key),
                ("SILICONFLOW_BASE_URL", self._settings.siliconflow_base_url),
                ("DEEPSEEK_MODEL", self._settings.deepseek_model),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "Writer 缺少必要配置：" + "、".join(missing) + "，请检查项目根目录的 .env"
            )

    async def write(self, rerank_result: RerankResult) -> ReportOutput:
        """生成 Markdown 报告；没有有效资料时不调用模型。"""
        company = (rerank_result.company or "").strip()
        report_month = (rerank_result.report_month or "").strip()
        if not company or not report_month:
            raise WriterError("Writer 输入缺少企业名称或报告月份")

        report_month_cn = format_report_month(report_month)
        pages = _valid_pages(rerank_result)

        if not pages:
            logger.info("Writer 输入中没有有效精排资料，生成说明性空报告")
            return _empty_report(company, report_month, report_month_cn)

        self._require_settings()
        assert self._settings.deepseek_model is not None  # 已校验

        source_materials, sources = build_source_materials(pages)
        system_prompt = build_system_prompt(company, report_month_cn, source_materials)
        model = self._settings.deepseek_model
        logger.info("Writer 调用模型 %s，企业=%s，月份=%s，资料 %d 条", model, company, report_month_cn, len(pages))

        client = self._client
        if client is None:
            client = AsyncOpenAI(
                api_key=self._settings.siliconflow_api_key,
                base_url=self._settings.siliconflow_base_url,
            )

        try:
            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": (
                            f"请根据以上资料撰写 {company} {report_month_cn} 的 ESG 月报。"
                            "严格使用固定板块结构，仅依据资料库内容。"
                        ),
                    },
                ],
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                timeout=self._settings.request_timeout_seconds,
            )
        except Exception as exc:
            logger.exception("Writer 模型调用失败")
            raise WriterError(f"Writer 模型调用失败：{exc}") from exc

        if not response.choices:
            raise WriterError("Writer 模型返回结果为空")

        markdown = strip_code_fences(response.choices[0].message.content or "")
        if not markdown.strip():
            raise WriterError("Writer 模型返回的正文为空")

        markdown, title = ensure_title(markdown, company, report_month_cn)
        validate_report_structure(markdown)

        found_ids = sorted(
            {f"S{int(number)}" for number in re.findall(r"\[S(\d+)\]", markdown)},
            key=lambda value: int(value[1:]),
        )
        available_ids = {source.source_id for source in sources}
        cited_ids = [source_id for source_id in found_ids if source_id in available_ids]
        logger.info("Writer 完成：%d 字，引用来源 %d 条", len(markdown), len(cited_ids))

        return ReportOutput(
            company=company,
            report_month=report_month,
            title=title,
            markdown=markdown,
            sources=sources,
            cited_source_ids=cited_ids,
        )
