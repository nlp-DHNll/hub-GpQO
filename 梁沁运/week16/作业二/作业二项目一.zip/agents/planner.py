"""Planner 节点：把用户需求拆解为 2～5 条搜索 Query。

模型调用使用硅基流动的 OpenAI 兼容接口（AsyncOpenAI）。
企业名称、报告月份由 Python 从用户需求中解析，并在 Pydantic 校验中
强制与模型输出比对，避免模型擅自更改。
"""

from __future__ import annotations

import calendar
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from string import Template
from typing import Any

from openai import AsyncOpenAI
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "planner_prompt.txt"

MONTH_PATTERN = re.compile(r"(?P<year>\d{4})\s*年\s*(?P<month>\d{1,2})\s*月")
COMPANY_PATTERN = re.compile(
    r"^(?:(?:请|麻烦|帮我|帮忙|给我|为|针对|关于|生成|制作|撰写|写|一份|一个|的)\s*)*"
    r"(?P<company>.+?)\s*(?=\d{4}\s*年)"
)

MIN_QUERIES = 2
MAX_QUERIES = 5


class PlannerError(RuntimeError):
    """Planner 运行失败。"""


class PlannerValidationError(ValueError):
    """Planner 输出未通过业务校验。"""


class RequestParseError(PlannerError):
    """无法从用户需求中解析企业名称或报告月份。"""


@dataclass(frozen=True)
class ReportRequest:
    """从用户需求中解析出的固定事实。"""

    company: str
    report_month: str  # YYYY-MM
    user_request: str

    @property
    def year(self) -> int:
        return int(self.report_month[:4])

    @property
    def month(self) -> int:
        return int(self.report_month[5:7])

    @property
    def report_month_cn(self) -> str:
        return f"{self.year}年{self.month}月"

    @property
    def time_range(self) -> str:
        last_day = calendar.monthrange(self.year, self.month)[1]
        return f"{self.year}年{self.month}月1日-{self.year}年{self.month}月{last_day}日"


class SearchQuery(BaseModel):
    """单条搜索任务。"""

    query_id: str = Field(description="任务编号，例如 q1")
    topic: str = Field(description="搜索主题")
    search_query: str = Field(description="实际提交给搜索 API 的语句")
    time_range: str = Field(description="搜索时间范围")

    @field_validator("query_id", "topic", "search_query", "time_range")
    @classmethod
    def _must_not_be_blank(cls, value: str, info: Any) -> str:
        value = value.strip()
        if not value:
            raise ValueError(f"{info.field_name} 不能为空")
        return value


class SearchPlan(BaseModel):
    """Planner 的结构化输出。"""

    company: str = Field(description="企业名称")
    report_month: str = Field(description="报告月份，规范化为 YYYY-MM")
    queries: list[SearchQuery] = Field(description="搜索任务列表")

    @field_validator("company")
    @classmethod
    def _company_not_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("company 不能为空")
        return value

    @field_validator("report_month")
    @classmethod
    def _normalize_report_month(cls, value: str) -> str:
        match = re.search(r"(?P<year>\d{4})\D{0,4}(?P<month>\d{1,2})", value)
        if match is None:
            raise ValueError("report_month 必须包含年份和月份，例如 2026-10 或 2026年10月")
        month = int(match.group("month"))
        if not 1 <= month <= 12:
            raise ValueError(f"report_month 的月份不合法：{month}")
        return f"{int(match.group('year')):04d}-{month:02d}"

    @model_validator(mode="after")
    def _check_queries(self) -> SearchPlan:
        count = len(self.queries)
        if not MIN_QUERIES <= count <= MAX_QUERIES:
            raise ValueError(f"Query 数量必须在 {MIN_QUERIES}～{MAX_QUERIES} 条之间，当前为 {count} 条")

        query_ids = [query.query_id for query in self.queries]
        if len(query_ids) != len(set(query_ids)):
            raise ValueError("query_id 不允许重复")

        normalized = [re.sub(r"\s+", "", query.search_query).lower() for query in self.queries]
        if len(normalized) != len(set(normalized)):
            raise ValueError("存在重复的 search_query")

        return self


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", "", value)


def parse_report_request(user_request: str) -> ReportRequest:
    """从用户需求中确定企业名称和报告月份（确定性 Python 解析）。"""
    text = user_request.strip()
    if not text:
        raise RequestParseError("用户需求不能为空")

    month_match = MONTH_PATTERN.search(text)
    if month_match is None:
        raise RequestParseError("无法从用户需求中识别报告月份，请使用“YYYY 年 M 月”的写法")

    year = int(month_match.group("year"))
    month = int(month_match.group("month"))
    if not 1 <= month <= 12:
        raise RequestParseError(f"报告月份不合法：{year}年{month}月")

    company_match = COMPANY_PATTERN.match(text)
    if company_match is None:
        raise RequestParseError("无法从用户需求中识别企业名称")

    company = company_match.group("company").strip()
    company = re.sub(r"(?:的|公司|生成|制作|撰写|写)$", "", company).strip()
    if not company:
        raise RequestParseError("无法从用户需求中识别企业名称")

    return ReportRequest(
        company=company,
        report_month=f"{year:04d}-{month:02d}",
        user_request=text,
    )


def _time_range_covers_month(time_range: str, request: ReportRequest) -> bool:
    compact = _normalize_text(time_range)
    if str(request.year) not in compact:
        return False
    month_tokens = {
        f"{request.month}月",
        f"{request.month:02d}月",
        f"-{request.month:02d}",
        f"/{request.month:02d}",
    }
    return any(token in compact for token in month_tokens)


def validate_plan_against_request(plan: SearchPlan, request: ReportRequest) -> SearchPlan:
    """强制校验模型输出与用户指定事实一致。"""
    errors: list[str] = []

    if _normalize_text(plan.company) != _normalize_text(request.company):
        errors.append(
            f"企业名称被修改：用户指定“{request.company}”，模型输出“{plan.company}”"
        )

    if plan.report_month != request.report_month:
        errors.append(
            f"报告月份被修改：用户指定“{request.report_month}”，模型输出“{plan.report_month}”"
        )

    for query in plan.queries:
        if not _time_range_covers_month(query.time_range, request):
            errors.append(
                f"{query.query_id} 的 time_range 未覆盖报告月份 {request.report_month}："
                f"“{query.time_range}”"
            )

    if errors:
        raise PlannerValidationError("Planner 输出不符合要求：\n" + "\n".join(f"  - {e}" for e in errors))

    return plan


def build_system_prompt(request: ReportRequest) -> str:
    """读取提示词模板并填入固定事实。"""
    if not PROMPT_PATH.exists():
        raise PlannerError(f"提示词文件不存在：{PROMPT_PATH}")

    template = Template(PROMPT_PATH.read_text(encoding="utf-8"))
    return template.substitute(
        company=request.company,
        report_month=request.report_month,
        report_month_cn=request.report_month_cn,
        time_range=request.time_range,
        user_request=request.user_request,
    )


def _extract_json_object(content: str) -> dict[str, Any]:
    """从模型回复中提取 JSON 对象，兼容 Markdown 代码块。"""
    text = content.strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fenced is not None:
        text = fenced.group(1).strip()

    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end <= start:
        raise PlannerError("模型未返回 JSON 对象")

    try:
        data = json.loads(text[start : end + 1])
    except json.JSONDecodeError as exc:
        raise PlannerError(f"模型返回的 JSON 无法解析：{exc}") from exc

    if not isinstance(data, dict):
        raise PlannerError("模型返回的 JSON 顶层必须是对象")
    return data


def _require_planner_settings(settings: Settings) -> None:
    """Planner 只依赖硅基流动的 API Key、Base URL 与模型名称。"""
    missing = [
        name
        for name, value in (
            ("SILICONFLOW_API_KEY", settings.siliconflow_api_key),
            ("SILICONFLOW_BASE_URL", settings.siliconflow_base_url),
            ("DEEPSEEK_MODEL", settings.deepseek_model),
        )
        if not value
    ]
    if missing:
        raise ConfigurationError(
            "Planner 缺少必要配置：" + "、".join(missing) + "，请检查项目根目录的 .env"
        )


class Planner:
    """Planner 节点。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: AsyncOpenAI | None = None,
    ) -> None:
        self._settings = settings or get_settings()
        self._client = client

    async def plan(self, user_request: str) -> SearchPlan:
        """解析需求、调用模型并返回通过校验的 SearchPlan。"""
        request = parse_report_request(user_request)
        _require_planner_settings(self._settings)

        system_prompt = build_system_prompt(request)
        model = self._settings.deepseek_model
        assert model is not None  # 已由 _require_planner_settings 保证
        logger.info("Planner 调用模型 %s，企业=%s，月份=%s", model, request.company, request.report_month)

        client = self._client
        if client is None:
            client = AsyncOpenAI(
                api_key=self._settings.siliconflow_api_key,
                base_url=self._settings.siliconflow_base_url,
            )

        try:
            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_request},
                ],
                temperature=0.2,
                max_tokens=1200,
                timeout=self._settings.request_timeout_seconds,
            )
        except Exception as exc:  # 统一转换为 PlannerError
            logger.exception("Planner 模型调用失败")
            raise PlannerError(f"Planner 模型调用失败：{exc}") from exc

        if not response.choices:
            raise PlannerError("模型返回结果为空")

        content = response.choices[0].message.content or ""
        data = _extract_json_object(content)

        try:
            plan = SearchPlan.model_validate(data)
        except ValidationError as exc:
            logger.error("Planner 输出结构校验失败：%s", exc)
            raise PlannerValidationError(f"Planner 输出结构校验失败：{exc}") from exc

        plan = validate_plan_against_request(plan, request)
        logger.info("Planner 生成 %d 条 Query", len(plan.queries))
        return plan


async def plan_esg_report(user_request: str) -> SearchPlan:
    """便捷入口：使用默认配置运行 Planner。"""
    return await Planner().plan(user_request)
