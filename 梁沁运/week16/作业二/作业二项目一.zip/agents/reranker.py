"""Reranker 节点：用 BGE Reranker 对 Reader 正文做相关性精排。

按 Planner 的各个主题分别评分，再合并结果、去重并选出全局 Top N。
只排序和筛选，不改写或摘要网页正文。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx
from pydantic import BaseModel, Field

from agents.planner import SearchPlan, SearchQuery
from agents.reader import ReaderOutput, ReadResult
from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

# 硅基流动 Reranker：POST /v1/rerank（OpenAI 兼容 Base URL + /rerank）
RERANK_PATH = "/rerank"
DEFAULT_TOP_K = 5
MAX_DOCUMENT_CHARS = 4000
ERROR_BODY_PREVIEW = 300


class RerankerError(RuntimeError):
    """Reranker 调用或结果解析失败。"""


class RankedPage(BaseModel):
    """精排后的单条网页。"""

    url: str
    title: str = ""
    content: str = ""
    kind: str = "page"
    relevance_score: float
    source_query_ids: list[str] = Field(default_factory=list)
    topic_scores: dict[str, float] = Field(default_factory=dict)


class RerankResult(BaseModel):
    """Reranker 输出。"""

    company: str = ""
    report_month: str = ""
    query_context: list[SearchQuery] = Field(default_factory=list)
    selected: list[RankedPage] = Field(default_factory=list)


def build_rerank_endpoint(base_url: str) -> str:
    """由 SiliconFlow Base URL 构造 Reranker Endpoint。"""
    base = base_url.strip().rstrip("/")
    if not base:
        raise RerankerError("SILICONFLOW_BASE_URL 不能为空")
    if base.endswith(RERANK_PATH):
        return base
    return base + RERANK_PATH


def build_document_text(page: ReadResult) -> str:
    """待排序文本：标题 + 正文，不做改写或摘要；仅限制长度以符合接口约束。"""
    parts = [part for part in (page.title.strip(), page.content.strip()) if part]
    text = "\n\n".join(parts)
    if len(text) > MAX_DOCUMENT_CHARS:
        text = text[:MAX_DOCUMENT_CHARS]
    return text


def _parse_scores(payload: Any, document_count: int) -> dict[int, float]:
    """解析 rerank 响应为 {documents 索引: 分数}。"""
    if not isinstance(payload, dict):
        raise RerankerError("Reranker 响应 JSON 顶层不是对象")

    results = payload.get("results")
    if not isinstance(results, list):
        message = payload.get("message")
        raise RerankerError(f"Reranker 响应缺少 results 数组：{message or payload}")

    scores: dict[int, float] = {}
    for item in results:
        if not isinstance(item, dict):
            continue
        index = item.get("index")
        score = item.get("relevance_score")
        if isinstance(index, bool) or not isinstance(index, int):
            continue
        if not 0 <= index < document_count:
            continue
        if isinstance(score, bool) or not isinstance(score, (int, float)):
            continue
        scores[index] = float(score)
    return scores


class Reranker:
    """按主题分别调用 BGE Reranker，再合并选出全局 Top N。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        top_k: int = DEFAULT_TOP_K,
    ) -> None:
        if top_k < 1:
            raise ValueError("top_k 必须至少为 1")
        self._settings = settings or get_settings()
        self._client = client
        self._top_k = top_k
        self._timeout = self._settings.request_timeout_seconds

    def _require_settings(self) -> None:
        missing = [
            name
            for name, value in (
                ("SILICONFLOW_API_KEY", self._settings.siliconflow_api_key),
                ("SILICONFLOW_BASE_URL", self._settings.siliconflow_base_url),
                ("BGE_RERANKER_MODEL", self._settings.bge_reranker_model),
            )
            if not value
        ]
        if missing:
            raise ConfigurationError(
                "Reranker 缺少必要配置：" + "、".join(missing) + "，请检查项目根目录的 .env"
            )

    async def rerank(
        self,
        reader_output: ReaderOutput,
        plan: SearchPlan,
    ) -> RerankResult:
        """执行精排。没有有效网页时直接返回空结果，不调用 API。"""
        pages = self._valid_pages(reader_output.pages)

        if not pages:
            logger.info("Reranker 输入中没有有效网页，返回空结果")
            return RerankResult(
                company=reader_output.company or plan.company,
                report_month=reader_output.report_month or plan.report_month,
                query_context=reader_output.query_context or list(plan.queries),
                selected=[],
            )

        self._require_settings()
        assert self._settings.siliconflow_base_url is not None  # 已校验
        assert self._settings.bge_reranker_model is not None  # 已校验
        endpoint = build_rerank_endpoint(self._settings.siliconflow_base_url)

        topics: list[SearchQuery] = reader_output.query_context or list(plan.queries)
        documents = [build_document_text(page) for page in pages]

        owns_client = self._client is None
        client = self._client or httpx.AsyncClient()
        logger.info("Reranker 开始：%d 个网页，%d 个主题", len(pages), len(topics))

        try:
            outcomes = await asyncio.gather(
                *(
                    self._score_topic(client, endpoint, topic, documents)
                    for topic in topics
                ),
                return_exceptions=True,
            )
        finally:
            if owns_client:
                await client.aclose()

        combined: dict[int, dict[str, float]] = {}
        for topic, outcome in zip(topics, outcomes):
            if isinstance(outcome, BaseException):
                if isinstance(outcome, RerankerError):
                    raise outcome
                raise RerankerError(f"主题 {topic.query_id} 评分失败：{outcome}") from outcome
            scores = outcome
            for index, score in scores.items():
                combined.setdefault(index, {})[topic.query_id] = score

        ranked = self._select_top(pages, combined, topics)
        logger.info("Reranker 完成：输入 %d，保留 %d", len(pages), len(ranked))

        return RerankResult(
            company=reader_output.company or plan.company,
            report_month=reader_output.report_month or plan.report_month,
            query_context=list(topics),
            selected=ranked,
        )

    @staticmethod
    def _valid_pages(pages: list[ReadResult]) -> list[ReadResult]:
        return [
            page
            for page in pages
            if page.status == "success" and page.content.strip() and page.url
        ]

    def _select_top(
        self,
        pages: list[ReadResult],
        combined: dict[int, dict[str, float]],
        topics: list[SearchQuery],
    ) -> list[RankedPage]:
        topic_by_id = {topic.query_id: topic for topic in topics}
        candidates: list[RankedPage] = []
        for index, topic_values in combined.items():
            page = pages[index]
            score = max(topic_values.values())
            candidates.append(
                RankedPage(
                    url=page.url,
                    title=page.title,
                    content=page.content,
                    kind=page.kind,
                    relevance_score=score,
                    source_query_ids=list(page.source_query_ids),
                    topic_scores={
                        topic_by_id[qid].topic if qid in topic_by_id else qid: value
                        for qid, value in topic_values.items()
                    },
                )
            )

        # 同一 URL 在合并后理论上已唯一；额外按 URL 去重，保留更高分。
        unique: dict[str, RankedPage] = {}
        for page in candidates:
            existing = unique.get(page.url)
            if existing is None or page.relevance_score > existing.relevance_score:
                unique[page.url] = page

        ranked = sorted(
            unique.values(),
            key=lambda item: (-item.relevance_score, item.url),
        )
        return ranked[: self._top_k]

    async def _score_topic(
        self,
        client: httpx.AsyncClient,
        endpoint: str,
        topic: SearchQuery,
        documents: list[str],
    ) -> dict[int, float]:
        payload = {
            "model": self._settings.bge_reranker_model,
            "query": topic.topic,
            "documents": documents,
            "return_documents": False,
            "top_n": len(documents),
        }
        try:
            response = await client.post(
                endpoint,
                headers={
                    "Authorization": f"Bearer {self._settings.siliconflow_api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=self._timeout,
            )
        except httpx.HTTPError as exc:
            raise RerankerError(f"Reranker 请求异常：{type(exc).__name__}: {exc}") from exc

        if not 200 <= response.status_code < 300:
            try:
                body = response.json()
            except ValueError:
                body = response.text[:ERROR_BODY_PREVIEW]
            raise RerankerError(f"Reranker API 错误：HTTP {response.status_code}：{body}")

        try:
            response_payload = response.json()
        except ValueError as exc:
            raise RerankerError(f"Reranker 响应不是合法 JSON：{exc}") from exc

        scores = _parse_scores(response_payload, len(documents))
        if not scores:
            raise RerankerError("Reranker 响应中没有有效分数")
        return scores
