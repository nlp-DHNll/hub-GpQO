"""Reader 节点：调用 DeepSeek Fetch API 把网页转换为 Markdown。

只负责读取和保留正文，不做摘要、改写或 ESG 内容分析。
鉴权复用 DEEPSEEK_SEARCH_API_KEY（DeepSeek 官方 Key），与 SiliconFlow、
Jina 配置无关。输入优先使用 Researcher 已跨 Query 去重的结果。
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Literal
from urllib.parse import urlsplit, urlunsplit, urlparse

import httpx
from pydantic import BaseModel, Field

from agents.planner import SearchQuery
from agents.researcher import ResearchResult, SearchResultItem
from config.settings import ConfigurationError, Settings, get_settings

logger = logging.getLogger(__name__)

# DeepSeek 官方 Fetch API（固定地址）
DEEPSEEK_FETCH_API_URL = "https://api.deepseek.com/v1/tools/fetch"

READER_CONCURRENCY = 3
MAX_ATTEMPTS = 2
RETRY_BACKOFF_SECONDS = 0.5
ERROR_BODY_PREVIEW = 300
MAX_URL_LENGTH = 8192

ReadStatus = Literal["success", "empty", "error"]

# 官方文档给出的错误码含义，用于生成清晰错误信息。
HTTP_ERROR_HINTS: dict[int, str] = {
    400: "请求参数错误",
    401: "API Key 缺失或无效",
    402: "账户余额不足",
    403: "安全策略拒绝",
    404: "网页无法获取或无法提取正文",
    408: "请求超时",
    413: "请求体过大",
    429: "请求频率超限",
    500: "服务端内部错误",
    504: "下游请求超时",
}


class ReaderError(RuntimeError):
    """Reader 运行失败。"""


class PageMetadata(BaseModel):
    """Fetch API 返回的可用元数据，原始响应保存在 raw 中。"""

    title: str | None = None
    description: str | None = None
    url_source: str | None = None
    published_time: str | None = None
    usage_tokens: int | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class ReadResult(BaseModel):
    """单个网页的读取结果。"""

    url: str
    title: str = ""
    status: ReadStatus
    content: str = ""
    metadata: PageMetadata = Field(default_factory=PageMetadata)
    error: str | None = None
    attempts: int = 0
    kind: Literal["page", "pdf", "office", "image"] = "page"
    source_query_ids: list[str] = Field(default_factory=list)


class ReaderOutput(BaseModel):
    """Reader 节点的输出，便于下一步 Reranker 使用。"""

    company: str = ""
    report_month: str = ""
    query_context: list[SearchQuery] = Field(default_factory=list)
    pages: list[ReadResult] = Field(default_factory=list)


def normalize_url(url: str) -> str:
    """URL 去重用的规范化：忽略协议/域名大小写、片段和末尾斜杠。"""
    value = url.strip()
    parts = urlsplit(value)
    if not parts.scheme and not parts.netloc:
        return value.lower().rstrip("/")
    path = parts.path.rstrip("/") or "/"
    return urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), path, parts.query, "")
    )


def is_fetchable_url(url: str) -> bool:
    """Fetch API 只接受带 host 的 http/https URL。"""
    if not url or len(url) > MAX_URL_LENGTH:
        return False
    parsed = urlparse(url)
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname)


def detect_content_kind(url: str) -> Literal["page", "pdf", "office", "image"]:
    """根据扩展名标记文件类型，保留原有字段语义。"""
    path = urlsplit(url).path.lower()
    if path.endswith(".pdf"):
        return "pdf"
    if path.endswith((".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx")):
        return "office"
    if path.endswith((".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg")):
        return "image"
    return "page"


def page_to_rerank_input(page: ReadResult) -> dict[str, Any]:
    """提供给 Reranker 的简单输入：正文 + 来源信息，不做任何清理改写。"""
    return {
        "url": page.url,
        "title": page.title,
        "content": page.content,
        "source_query_ids": list(page.source_query_ids),
    }


def _index_query_ids(result: ResearchResult) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = {}
    for item in result.results:
        mapping[normalize_url(item.url)] = list(item.source_query_ids)
    return mapping


def _collect_source_queries(result: ResearchResult) -> list[SearchQuery]:
    """从 Researcher 结果中还原 Query 上下文，供 Reranker 使用。"""
    queries: list[SearchQuery] = []
    seen: set[str] = set()
    for query_result in result.query_results:
        if query_result.query_id in seen:
            continue
        seen.add(query_result.query_id)
        queries.append(
            SearchQuery(
                query_id=query_result.query_id,
                topic=query_result.topic,
                search_query=query_result.search_query,
                time_range=query_result.time_range,
            )
        )
    return queries


class Reader:
    """调用 DeepSeek Fetch API 读取 Researcher 采集到的 URL。"""

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        max_attempts: int = MAX_ATTEMPTS,
        retry_backoff_seconds: float = RETRY_BACKOFF_SECONDS,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts 必须至少为 1")
        self._settings = settings or get_settings()
        self._client = client
        self._max_attempts = max_attempts
        self._retry_backoff_seconds = max(0.0, retry_backoff_seconds)
        self._timeout = self._settings.request_timeout_seconds

    def _require_settings(self) -> None:
        """复用 DeepSeek 官方 Key；不使用 SiliconFlow 或 Jina Key。"""
        if not self._settings.deepseek_search_api_key:
            raise ConfigurationError(
                "Reader 缺少必要配置：DEEPSEEK_SEARCH_API_KEY。"
                "Reader 使用 DeepSeek 官方 Fetch API，请填写 DeepSeek 官方 API Key；"
                "不要使用 SILICONFLOW_API_KEY 或 JINA_API_KEY。"
            )

    async def read(self, research: ResearchResult) -> ReaderOutput:
        """读取 Researcher 去重后的全部 URL，单个失败不影响其他网页。"""
        self._require_settings()

        items = self._deduplicate_items(research.results)
        query_ids_by_url = _index_query_ids(research)
        concurrency = max(1, self._settings.search_concurrency)
        semaphore = asyncio.Semaphore(concurrency)

        owns_client = self._client is None
        client = self._client or httpx.AsyncClient()
        logger.info("Reader 开始：%d 个网页，并发上限 %d", len(items), concurrency)

        async def run_one(item: SearchResultItem) -> ReadResult:
            source_ids = query_ids_by_url.get(normalize_url(item.url), list(item.source_query_ids))
            async with semaphore:
                try:
                    result = await self._read_url(client, item.url)
                except Exception as exc:  # 保证单页异常不中断其他网页
                    logger.exception("网页 %s 出现未预期异常", item.url)
                    result = self._error_result(
                        item.url, f"未预期错误：{exc}", attempts=0
                    )
            result.source_query_ids = source_ids
            if not result.title:
                result.title = item.title
            return result

        try:
            outcomes = await asyncio.gather(
                *(run_one(item) for item in items),
                return_exceptions=True,
            )
        finally:
            if owns_client:
                await client.aclose()

        pages: list[ReadResult] = []
        for item, outcome in zip(items, outcomes):
            if isinstance(outcome, BaseException):
                logger.error("网页 %s 读取失败：%s", item.url, outcome)
                pages.append(
                    self._error_result(
                        item.url,
                        f"未预期错误：{outcome}",
                        attempts=0,
                        title=item.title,
                    )
                )
            else:
                pages.append(outcome)

        success = sum(1 for page in pages if page.status == "success")
        empty = sum(1 for page in pages if page.status == "empty")
        failed = sum(1 for page in pages if page.status == "error")
        logger.info("Reader 完成：成功 %d，空正文 %d，失败 %d", success, empty, failed)

        return ReaderOutput(
            company=research.company,
            report_month=research.report_month,
            query_context=_collect_source_queries(research),
            pages=pages,
        )

    @staticmethod
    def _deduplicate_items(items: list[SearchResultItem]) -> list[SearchResultItem]:
        seen: set[str] = set()
        unique: list[SearchResultItem] = []
        for item in items:
            key = normalize_url(item.url)
            if not key or key in seen:
                continue
            seen.add(key)
            unique.append(item)
        return unique

    async def _read_url(self, client: httpx.AsyncClient, url: str) -> ReadResult:
        if not is_fetchable_url(url):
            return self._error_result(
                url, "URL 不合法：必须是带 host 的 http/https 地址，且不超过 8192 字符", attempts=0
            )

        headers = {
            "Authorization": f"Bearer {self._settings.deepseek_search_api_key}",
            "Content-Type": "application/json",
        }
        payload = {"url": url}
        last_error = "未知错误"

        for attempt in range(1, self._max_attempts + 1):
            try:
                response = await client.post(
                    DEEPSEEK_FETCH_API_URL,
                    headers=headers,
                    json=payload,
                    timeout=self._timeout,
                )
            except httpx.TimeoutException:
                last_error = f"请求超时（{self._timeout} 秒）"
                logger.warning("网页 %s 第 %d 次读取超时", url, attempt)
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                return self._error_result(url, last_error, attempts=attempt)
            except httpx.HTTPError as exc:
                last_error = f"HTTP 请求异常：{type(exc).__name__}: {exc}"
                logger.warning("网页 %s 第 %d 次请求异常：%s", url, attempt, exc)
                if attempt < self._max_attempts:
                    await asyncio.sleep(self._retry_backoff_seconds * attempt)
                    continue
                return self._error_result(url, last_error, attempts=attempt)

            if 200 <= response.status_code < 300:
                return self._parse_success(url, response, attempt)

            hint = HTTP_ERROR_HINTS.get(response.status_code, "未预期的 HTTP 错误")
            last_error = (
                f"HTTP {response.status_code}（{hint}）："
                f"{response.text[:ERROR_BODY_PREVIEW]}"
            )
            # 官方建议：408、429、5xx 等待后重试；其他 4xx（含 402/403/404）不重试。
            retryable = response.status_code == 408 or response.status_code == 429 or (
                500 <= response.status_code < 600
            )
            if retryable and attempt < self._max_attempts:
                logger.warning(
                    "网页 %s 第 %d 次返回 HTTP %d，准备重试",
                    url,
                    attempt,
                    response.status_code,
                )
                await asyncio.sleep(self._retry_backoff_seconds * attempt)
                continue
            return self._error_result(url, last_error, attempts=attempt)

        return self._error_result(url, last_error, attempts=self._max_attempts)

    def _parse_success(
        self,
        url: str,
        response: httpx.Response,
        attempts: int,
    ) -> ReadResult:
        try:
            payload = response.json()
        except ValueError as exc:
            return self._error_result(
                url, f"Fetch 响应不是合法 JSON：{exc}", attempts=attempts
            )

        if not isinstance(payload, dict):
            return self._error_result(
                url, "Fetch 响应 JSON 顶层不是对象", attempts=attempts
            )

        content = payload.get("content")
        title = payload.get("title")
        if not isinstance(content, str):
            return self._error_result(
                url, "Fetch 响应缺少字符串类型的 content 字段", attempts=attempts
            )
        if not isinstance(title, str):
            title = ""

        status: ReadStatus = "success" if content.strip() else "empty"
        return ReadResult(
            url=url,
            title=title,
            status=status,
            content=content,
            metadata=PageMetadata(
                title=title or None,
                url_source=url,
                raw=payload,
            ),
            error=None if status == "success" else "正文为空",
            attempts=attempts,
            kind=detect_content_kind(url),
        )

    @staticmethod
    def _error_result(
        url: str,
        message: str,
        attempts: int,
        title: str = "",
    ) -> ReadResult:
        return ReadResult(
            url=url,
            title=title,
            status="error",
            content="",
            metadata=PageMetadata(),
            error=message,
            attempts=attempts,
            kind=detect_content_kind(url),
        )
