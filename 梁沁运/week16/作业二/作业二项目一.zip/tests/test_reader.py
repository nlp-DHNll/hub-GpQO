"""Reader 离线单元测试（Mock HTTP 客户端，不访问真实 API）。

Reader 已改为调用 DeepSeek Fetch API，鉴权复用 DEEPSEEK_SEARCH_API_KEY。
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

import httpx
import pytest

from agents.reader import (
    DEEPSEEK_FETCH_API_URL,
    Reader,
    detect_content_kind,
    page_to_rerank_input,
)
from agents.researcher import (
    QuerySearchResult,
    ResearchResult,
    SearchResultItem,
)
from config.settings import ConfigurationError, Settings

FAKE_KEY = "test-deepseek-key"
FAKE_JINA_KEY = "jina-should-not-be-used"
TARGET_URL = "https://example.com/article?id=1"


def make_item(url: str, title: str = "测试标题", source_ids: list[str] | None = None) -> SearchResultItem:
    return SearchResultItem(
        title=title,
        url=url,
        snippet="摘要",
        summary="长摘要",
        source_query_ids=source_ids or ["q1"],
    )


def make_research(
    items: list[SearchResultItem],
    query_count: int = 2,
) -> ResearchResult:
    query_results = [
        QuerySearchResult(
            query_id=f"q{i}",
            topic=f"主题{i}",
            search_query=f"搜索语句{i}",
            time_range="2026年10月1日-2026年10月31日",
            status="success",
            results=items,
        )
        for i in range(1, query_count + 1)
    ]
    return ResearchResult(
        company="中国神华",
        report_month="2026-10",
        query_results=query_results,
        results=items,
    )


def make_settings(timeout: float = 5.0, concurrency: int = 3) -> Settings:
    return Settings(
        deepseek_search_api_key=FAKE_KEY,
        jina_api_key=FAKE_JINA_KEY,
        request_timeout_seconds=timeout,
        search_concurrency=concurrency,
    )


def fetch_body(content: str, title: str = "示例网页", **extra: Any) -> dict[str, Any]:
    data = {"title": title, "content": content}
    data.update(extra)
    return data


def make_client(handler: Callable[[httpx.Request], Any]) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


def run(reader: Reader, research: ResearchResult):
    return asyncio.run(reader.read(research))


# 1. Fetch POST 请求地址正确
def test_fetch_endpoint_and_method() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=fetch_body("正文"))

    run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    assert len(received) == 1
    assert received[0].method == "POST"
    assert str(received[0].url) == DEEPSEEK_FETCH_API_URL
    assert str(received[0].url) == "https://api.deepseek.com/v1/tools/fetch"


# 2. 请求 JSON 正确传递 URL
def test_request_json_contains_url() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=fetch_body("正文"))

    run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    assert json.loads(received[0].content) == {"url": TARGET_URL}


# 3. Authorization 使用 DeepSeek 官方 Key 配置，不使用 Jina Key
def test_authorization_uses_deepseek_key() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=fetch_body("正文"))

    run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    auth = received[0].headers["authorization"]
    assert auth == f"Bearer {FAKE_KEY}"
    assert FAKE_JINA_KEY not in auth
    assert received[0].headers["content-type"] == "application/json"


# 4. 正常返回 title 和 Markdown content
def test_normal_read_returns_title_and_markdown() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("# 标题\n\n正文内容", title="示例网页"))

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    assert len(result.pages) == 1
    page = result.pages[0]
    assert page.status == "success"
    assert page.title == "示例网页"
    assert page.content == "# 标题\n\n正文内容"
    assert page.url == TARGET_URL
    assert page.error is None
    assert page.attempts == 1
    assert result.company == "中国神华"
    assert len(result.query_context) == 2
    assert result.query_context[0].query_id == "q1"


# 5. 多网页并发读取
def test_multiple_pages_read() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("正文"))

    items = [make_item(f"https://example.com/{i}") for i in range(6)]
    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research(items))

    assert len(result.pages) == 6
    assert all(page.status == "success" for page in result.pages)


# 6. 最大并发不超过 3
def test_max_concurrency_not_exceeded() -> None:
    active = 0
    max_active = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal active, max_active
        active += 1
        max_active = max(max_active, active)
        await asyncio.sleep(0.05)
        active -= 1
        return httpx.Response(200, json=fetch_body("正文"))

    items = [make_item(f"https://example.com/{i}") for i in range(8)]
    run(Reader(settings=make_settings(), client=make_client(handler)), make_research(items))

    assert max_active <= 3
    assert max_active >= 2


# 7. URL 去重
def test_url_deduplication() -> None:
    fetched_urls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        fetched_urls.append(json.loads(request.content)["url"])
        return httpx.Response(200, json=fetch_body("正文"))

    items = [
        make_item("https://example.com/a", source_ids=["q1"]),
        make_item("https://Example.com/a/", source_ids=["q1", "q2"]),
        make_item("https://example.com/b"),
    ]
    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research(items))

    assert len(fetched_urls) == 2
    assert len(result.pages) == 2


# 8. 单个网页失败不影响其他网页
def test_single_failure_does_not_stop_others() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        url = json.loads(request.content)["url"]
        if "bad" in url:
            return httpx.Response(404, json={"error": {"message": "not found"}})
        return httpx.Response(200, json=fetch_body("正文"))

    items = [
        make_item("https://example.com/good-1"),
        make_item("https://example.com/bad"),
        make_item("https://example.com/good-2"),
    ]
    result = run(
        Reader(settings=make_settings(), client=make_client(handler), max_attempts=1),
        make_research(items),
    )

    statuses = {page.url.split("/")[-1]: page.status for page in result.pages}
    assert statuses == {"good-1": "success", "bad": "error", "good-2": "success"}
    bad = next(page for page in result.pages if "bad" in page.url)
    assert "HTTP 404" in (bad.error or "")
    assert "网页无法获取或无法提取正文" in (bad.error or "")


# 9. 401、402、403、404 错误处理（不重试）
@pytest.mark.parametrize(
    ("status_code", "hint"),
    [
        (400, "请求参数错误"),
        (401, "API Key 缺失或无效"),
        (402, "账户余额不足"),
        (403, "安全策略拒绝"),
        (404, "网页无法获取或无法提取正文"),
    ],
)
def test_client_errors_are_not_retried(status_code: int, hint: str) -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(status_code, json={"error": {"message": "mock error"}})

    result = run(
        Reader(
            settings=make_settings(),
            client=make_client(handler),
            max_attempts=2,
            retry_backoff_seconds=0,
        ),
        make_research([make_item(TARGET_URL)]),
    )

    page = result.pages[0]
    assert calls == 1
    assert page.status == "error"
    assert page.attempts == 1
    assert f"HTTP {status_code}" in (page.error or "")
    assert hint in (page.error or "")
    assert page.content == ""


# 10. 429、500、504 重试处理（408 也按官方建议重试）
@pytest.mark.parametrize("status_code", [408, 429, 500, 504])
def test_retryable_http_statuses(status_code: int) -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls == 1:
            return httpx.Response(status_code, json={"error": {"message": "temporary"}})
        return httpx.Response(200, json=fetch_body("重试后的正文"))

    result = run(
        Reader(
            settings=make_settings(),
            client=make_client(handler),
            max_attempts=2,
            retry_backoff_seconds=0,
        ),
        make_research([make_item(TARGET_URL)]),
    )

    page = result.pages[0]
    assert calls == 2
    assert page.status == "success"
    assert page.content == "重试后的正文"
    assert page.attempts == 2


# 11. 请求超时处理
def test_timeout_recorded() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        # MockTransport 不执行 httpx 的超时计时，这里直接模拟超时异常。
        raise httpx.ReadTimeout("timed out", request=request)

    result = run(
        Reader(settings=make_settings(timeout=0.01), client=make_client(handler), max_attempts=1),
        make_research([make_item(TARGET_URL)]),
    )

    page = result.pages[0]
    assert page.status == "error"
    assert "请求超时" in (page.error or "")


# 12. 空正文处理
def test_empty_content_handled() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("   "))

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    page = result.pages[0]
    assert page.status == "empty"
    assert page.content.strip() == ""
    assert page.error == "正文为空"


# 13. 元数据保留
def test_metadata_preserved() -> None:
    payload = fetch_body("正文", title="元数据标题", request_id="req-test", description="额外字段")

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    page = result.pages[0]
    assert page.metadata.title == "元数据标题"
    assert page.metadata.url_source == TARGET_URL
    assert page.metadata.raw == payload
    assert page.metadata.raw["request_id"] == "req-test"


# 14. API Key 不出现在日志中
def test_api_key_not_logged(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.INFO)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("正文"))

    run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))
    assert FAKE_KEY not in caplog.text
    assert FAKE_JINA_KEY not in caplog.text


# 其他行为
def test_missing_deepseek_key_reports_clearly() -> None:
    settings = Settings(jina_api_key="some-jina-key")

    with pytest.raises(ConfigurationError, match="DEEPSEEK_SEARCH_API_KEY"):
        run(
            Reader(
                settings=settings,
                client=make_client(lambda request: httpx.Response(200, json=fetch_body("正文"))),
            ),
            make_research([make_item(TARGET_URL)]),
        )


def test_title_falls_back_to_search_result_title() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("正文", title=""))

    item = make_item(TARGET_URL, title="搜索标题")
    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([item]))

    assert result.pages[0].title == "搜索标题"


def test_invalid_url_rejected_without_request() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200, json=fetch_body("正文"))

    result = run(
        Reader(settings=make_settings(), client=make_client(handler)),
        make_research([make_item("ftp://example.com/a")]),
    )

    assert calls == 0
    assert result.pages[0].status == "error"
    assert "URL 不合法" in (result.pages[0].error or "")


def test_invalid_json_on_http_200() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not json", headers={"content-type": "text/plain"})

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    assert result.pages[0].status == "error"
    assert "不是合法 JSON" in (result.pages[0].error or "")


def test_missing_content_field_on_http_200() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"title": "只有标题"})

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))

    assert result.pages[0].status == "error"
    assert "content 字段" in (result.pages[0].error or "")


def test_rerank_input_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=fetch_body("正文"))

    result = run(Reader(settings=make_settings(), client=make_client(handler)), make_research([make_item(TARGET_URL)]))
    payload = page_to_rerank_input(result.pages[0])

    assert set(payload) == {"url", "title", "content", "source_query_ids"}
    assert payload["url"] == TARGET_URL


@pytest.mark.parametrize(
    ("url", "kind"),
    [
        ("https://example.com/a.pdf", "pdf"),
        ("https://example.com/a.docx", "office"),
        ("https://example.com/a.png", "image"),
        ("https://example.com/a", "page"),
    ],
)
def test_detect_content_kind(url: str, kind: str) -> None:
    assert detect_content_kind(url) == kind
