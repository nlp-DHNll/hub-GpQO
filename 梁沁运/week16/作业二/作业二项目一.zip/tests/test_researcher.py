"""Researcher 离线单元测试（使用 Mock HTTP 客户端，不访问真实 API）。"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

import httpx
import pytest

from agents.planner import SearchPlan, SearchQuery
from agents.researcher import (
    Researcher,
    build_search_endpoint,
    normalize_url,
)
from config.settings import ConfigurationError, Settings

TIME_RANGE = "2026年10月1日-2026年10月31日"
FAKE_KEY = "test-search-key"


def make_query(index: int, search_query: str | None = None) -> SearchQuery:
    return SearchQuery(
        query_id=f"q{index}",
        topic=f"测试主题{index}",
        search_query=search_query or f"中国神华 2026年10月 ESG 测试{index}",
        time_range=TIME_RANGE,
    )


def make_plan(query_count: int = 3) -> SearchPlan:
    return SearchPlan(
        company="中国神华",
        report_month="2026-10",
        queries=[make_query(i) for i in range(1, query_count + 1)],
    )


def make_settings(timeout: float = 1.0, concurrency: int = 3) -> Settings:
    return Settings(
        deepseek_search_api_key=FAKE_KEY,
        deepseek_search_base_url="https://api.deepseek.com/v1/tools",
        request_timeout_seconds=timeout,
        search_concurrency=concurrency,
    )


def search_response(items: list[dict[str, Any]]) -> dict[str, Any]:
    return {"results": items, "request_id": "req-test"}


def make_item(url: str, title: str = "示例标题", **extra: Any) -> dict[str, Any]:
    item = {
        "rerank_score": 2.4,
        "title": title,
        "url": url,
        "snippet": "示例摘要",
        "summary": "示例长摘要",
        "content": "",
        "site_name": "示例站点",
        "site_icon": "https://example.com/favicon.ico",
        "date": "2026-10-01T00:00:00+00:00",
        "authority": 3,
    }
    item.update(extra)
    return item


def make_client(handler: Callable[[httpx.Request], Any]) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


def run(researcher: Researcher, plan: SearchPlan):
    return asyncio.run(researcher.research(plan))


def test_normal_search_results_preserved() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=search_response([make_item("https://example.com/a")]))

    plan = make_plan(2)
    result = run(Researcher(settings=make_settings(), client=make_client(handler)), plan)

    assert result.company == "中国神华"
    assert result.report_month == "2026-10"
    assert [item.status for item in result.query_results] == ["success", "success"]
    assert len(result.results) == 1

    item = result.results[0]
    assert item.title == "示例标题"
    assert item.url == "https://example.com/a"
    assert item.snippet == "示例摘要"
    assert item.summary == "示例长摘要"
    assert item.raw["authority"] == 3
    assert result.query_results[0].raw_response == search_response(
        [make_item("https://example.com/a")]
    )

    first_payload = json.loads(received[0].content)
    assert first_payload["query"] == plan.queries[0].search_query
    assert first_payload["count"] == 10
    assert first_payload["need_content"] is False
    assert received[0].headers["authorization"] == f"Bearer {FAKE_KEY}"


def test_multiple_queries_all_executed() -> None:
    queries: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        queries.append(json.loads(request.content)["query"])
        return httpx.Response(200, json=search_response([make_item(f"https://example.com/{len(queries)}")]))

    plan = make_plan(4)
    result = run(Researcher(settings=make_settings(), client=make_client(handler)), plan)

    assert len(queries) == 4
    assert set(queries) == {query.search_query for query in plan.queries}
    assert len(result.query_results) == 4
    assert all(item.status == "success" for item in result.query_results)


def test_max_concurrency_not_exceeded() -> None:
    active = 0
    max_active = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal active, max_active
        active += 1
        max_active = max(max_active, active)
        await asyncio.sleep(0.05)
        active -= 1
        return httpx.Response(200, json=search_response([make_item("https://example.com/a")]))

    plan = make_plan(5)
    run(Researcher(settings=make_settings(), client=make_client(handler)), plan)

    assert max_active <= 3
    assert max_active >= 2


def test_url_deduplication_across_queries() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        query = json.loads(request.content)["query"]
        if query.endswith("测试1"):
            items = [
                make_item("https://Example.com/a/", title="A"),
                make_item("https://example.com/a#section", title="A duplicate"),
            ]
        else:
            items = [
                make_item("https://example.com/a", title="A again"),
                make_item("https://example.com/b", title="B"),
            ]
        return httpx.Response(200, json=search_response(items))

    plan = make_plan(2)
    result = run(Researcher(settings=make_settings(), client=make_client(handler)), plan)

    assert len(result.query_results[0].results) == 1
    assert len(result.query_results[1].results) == 2
    assert len(result.results) == 2

    item_a = next(item for item in result.results if normalize_url(item.url) == "https://example.com/a")
    assert item_a.source_query_ids == ["q1", "q2"]
    assert "#" not in item_a.url
    assert len({normalize_url(item.url) for item in result.results}) == len(result.results)


def test_single_query_failure_does_not_stop_others() -> None:
    executed: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        query = json.loads(request.content)["query"]
        executed.append(query)
        if query.endswith("测试2"):
            return httpx.Response(500, json={"error": "server error"})
        return httpx.Response(200, json=search_response([make_item(f"https://example.com/{len(executed)}")]))

    plan = make_plan(3)
    result = run(
        Researcher(
            settings=make_settings(),
            client=make_client(handler),
            max_attempts=1,
            retry_backoff_seconds=0,
        ),
        plan,
    )

    assert len(executed) == 3
    statuses = [item.status for item in result.query_results]
    assert statuses == ["success", "error", "success"]
    failed = result.query_results[1]
    assert failed.error is not None and "HTTP 500" in failed.error
    assert failed.results == []


def test_http_error_recorded_without_raising() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": {"message": "invalid key"}})

    result = run(
        Researcher(
            settings=make_settings(),
            client=make_client(handler),
            max_attempts=1,
        ),
        make_plan(2),
    )

    assert all(item.status == "error" for item in result.query_results)
    assert "HTTP 401" in (result.query_results[0].error or "")
    assert result.results == []


def test_timeout_recorded() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        # MockTransport 不执行 httpx 的超时计时，这里直接模拟超时异常。
        raise httpx.ReadTimeout("timed out", request=request)

    result = run(
        Researcher(
            settings=make_settings(timeout=0.01),
            client=make_client(handler),
            max_attempts=1,
        ),
        make_plan(2),
    )

    assert all(item.status == "error" for item in result.query_results)
    assert "请求超时" in (result.query_results[0].error or "")


def test_empty_results_handled() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=search_response([]))

    result = run(
        Researcher(settings=make_settings(), client=make_client(handler)),
        make_plan(2),
    )

    assert all(item.status == "empty" for item in result.query_results)
    assert all(item.error is None for item in result.query_results)
    assert result.query_results[0].raw_response == search_response([])
    assert result.results == []


def test_retry_on_server_error() -> None:
    attempts: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        attempts.append(1)
        if len(attempts) == 1:
            return httpx.Response(503, json={"error": "busy"})
        return httpx.Response(200, json=search_response([make_item("https://example.com/retry")]))

    result = run(
        Researcher(
            settings=make_settings(),
            client=make_client(handler),
            max_attempts=2,
            retry_backoff_seconds=0,
        ),
        make_plan(2),
    )

    assert len(attempts) == 3  # 第一条 Query 重试一次，第二条 Query 一次
    assert result.query_results[0].status == "success"
    assert result.query_results[0].attempts == 2


def test_raw_json_fields_are_preserved() -> None:
    item = make_item(
        "https://example.com/full",
        custom_field="keep-me",
        extra_nested={"key": "value"},
    )
    payload = search_response([item])

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    result = run(
        Researcher(settings=make_settings(), client=make_client(handler)),
        make_plan(2),
    )

    assert result.query_results[0].raw_response == payload
    preserved = result.results[0]
    assert preserved.raw == item
    assert preserved.raw["custom_field"] == "keep-me"
    assert preserved.raw["extra_nested"] == {"key": "value"}


def test_api_key_not_logged(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.INFO)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=search_response([make_item("https://example.com/a")]))

    run(Researcher(settings=make_settings(), client=make_client(handler)), make_plan(2))
    assert FAKE_KEY not in caplog.text


def test_missing_search_settings_reports_clearly() -> None:
    settings = Settings(deepseek_search_base_url="https://api.deepseek.com/v1/tools")

    with pytest.raises(ConfigurationError, match="DEEPSEEK_SEARCH_API_KEY"):
        run(
            Researcher(
                settings=settings,
                client=make_client(lambda request: httpx.Response(200, json=search_response([]))),
            ),
            make_plan(2),
        )


@pytest.mark.parametrize(
    ("base_url", "expected"),
    [
        ("https://api.deepseek.com", "https://api.deepseek.com/v1/tools/search"),
        ("https://api.deepseek.com/v1", "https://api.deepseek.com/v1/tools/search"),
        ("https://api.deepseek.com/v1/tools", "https://api.deepseek.com/v1/tools/search"),
        ("https://api.deepseek.com/v1/tools/", "https://api.deepseek.com/v1/tools/search"),
        (
            "https://api.deepseek.com/v1/tools/search",
            "https://api.deepseek.com/v1/tools/search",
        ),
    ],
)
def test_build_search_endpoint_variants(base_url: str, expected: str) -> None:
    assert build_search_endpoint(base_url) == expected
