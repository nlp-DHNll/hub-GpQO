"""Planner 单元测试（不访问真实 API）。"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
from typing import Any

import pytest
from pydantic import ValidationError

from agents.planner import (
    Planner,
    PlannerValidationError,
    ReportRequest,
    SearchPlan,
    parse_report_request,
    validate_plan_against_request,
)
from config.settings import Settings

REQUEST_TEXT = "请帮我生成中国神华 2026 年 10 月 ESG 月报。"
TIME_RANGE = "2026年10月1日-2026年10月31日"


def make_query(index: int, search_query: str | None = None, topic: str | None = None) -> dict[str, str]:
    return {
        "query_id": f"q{index}",
        "topic": topic or f"测试主题{index}",
        "search_query": search_query or f"中国神华 2026年10月 ESG 动态 主题{index}",
        "time_range": TIME_RANGE,
    }


def make_plan_payload(query_count: int = 3) -> dict[str, Any]:
    return {
        "company": "中国神华",
        "report_month": "2026-10",
        "queries": [make_query(i) for i in range(1, query_count + 1)],
    }


@pytest.fixture
def request_info() -> ReportRequest:
    return parse_report_request(REQUEST_TEXT)


# 1. 正常输出
def test_valid_plan(request_info: ReportRequest) -> None:
    plan = SearchPlan.model_validate(make_plan_payload(3))
    validated = validate_plan_against_request(plan, request_info)

    assert validated.company == "中国神华"
    assert validated.report_month == "2026-10"
    assert len(validated.queries) == 3
    assert validated.queries[0].query_id == "q1"


def test_report_month_is_normalized() -> None:
    payload = make_plan_payload(2)
    payload["report_month"] = "2026年10月"
    plan = SearchPlan.model_validate(payload)
    assert plan.report_month == "2026-10"


# 2. Query 少于 2 条
def test_too_few_queries() -> None:
    payload = make_plan_payload(1)
    with pytest.raises(ValidationError, match="Query 数量必须在 2～5 条之间"):
        SearchPlan.model_validate(payload)


# 3. Query 超过 5 条
def test_too_many_queries() -> None:
    payload = make_plan_payload(6)
    with pytest.raises(ValidationError, match="Query 数量必须在 2～5 条之间"):
        SearchPlan.model_validate(payload)


# 4. Query 为空
def test_empty_query() -> None:
    payload = make_plan_payload(2)
    payload["queries"][0]["search_query"] = "   "
    with pytest.raises(ValidationError, match="search_query 不能为空"):
        SearchPlan.model_validate(payload)


# 5. Query 重复
def test_duplicate_query() -> None:
    payload = make_plan_payload(2)
    payload["queries"][1]["search_query"] = payload["queries"][0]["search_query"]
    with pytest.raises(ValidationError, match="存在重复的 search_query"):
        SearchPlan.model_validate(payload)


# 6. 报告月份不一致
def test_report_month_mismatch(request_info: ReportRequest) -> None:
    payload = make_plan_payload(2)
    payload["report_month"] = "2026-11"
    plan = SearchPlan.model_validate(payload)

    with pytest.raises(PlannerValidationError, match="报告月份被修改"):
        validate_plan_against_request(plan, request_info)


def test_company_mismatch(request_info: ReportRequest) -> None:
    payload = make_plan_payload(2)
    payload["company"] = "中国石油"
    plan = SearchPlan.model_validate(payload)

    with pytest.raises(PlannerValidationError, match="企业名称被修改"):
        validate_plan_against_request(plan, request_info)


def test_time_range_must_cover_report_month(request_info: ReportRequest) -> None:
    payload = make_plan_payload(2)
    payload["queries"][0]["time_range"] = "2026年11月1日-2026年11月30日"
    plan = SearchPlan.model_validate(payload)

    with pytest.raises(PlannerValidationError, match="time_range 未覆盖报告月份"):
        validate_plan_against_request(plan, request_info)


def test_parse_report_request() -> None:
    request_info = parse_report_request(REQUEST_TEXT)
    assert request_info.company == "中国神华"
    assert request_info.report_month == "2026-10"
    assert request_info.report_month_cn == "2026年10月"
    assert request_info.time_range == TIME_RANGE


class FakeCompletions:
    """模拟 AsyncOpenAI 的 chat.completions。"""

    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload
        self.last_kwargs: dict[str, Any] | None = None

    async def create(self, **kwargs: Any) -> Any:
        self.last_kwargs = kwargs
        content = json.dumps(self.payload, ensure_ascii=False)
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=content))]
        )


class FakeClient:
    """只实现 Planner 使用到的最小客户端接口。"""

    def __init__(self, payload: dict[str, Any]) -> None:
        self.completions = FakeCompletions(payload)
        self.chat = SimpleNamespace(completions=self.completions)


def make_test_settings() -> Settings:
    return Settings(
        siliconflow_api_key="test-key",
        siliconflow_base_url="https://example.invalid/v1",
        deepseek_model="test-model",
    )


def test_planner_with_fake_client_uses_configured_model() -> None:
    payload = make_plan_payload(3)
    payload["queries"][0]["topic"] = "ESG 政策、评级与监管动态"
    payload["queries"][1]["topic"] = "煤炭行业 ESG 新闻与最佳实践"
    payload["queries"][2]["topic"] = "中国神华 ESG 动态"

    client = FakeClient(payload)
    planner = Planner(settings=make_test_settings(), client=client)  # type: ignore[arg-type]

    plan = asyncio.run(planner.plan(REQUEST_TEXT))

    assert plan.company == "中国神华"
    assert len(plan.queries) == 3
    assert client.completions.last_kwargs is not None
    assert client.completions.last_kwargs["model"] == "test-model"
    messages = client.completions.last_kwargs["messages"]
    assert messages[0]["role"] == "system"
    assert "中国神华" in messages[0]["content"]
    assert "2026年10月" in messages[0]["content"]


def test_planner_rejects_changed_month_with_fake_client() -> None:
    payload = make_plan_payload(3)
    payload["report_month"] = "2026-11"
    planner = Planner(settings=make_test_settings(), client=FakeClient(payload))  # type: ignore[arg-type]

    with pytest.raises(PlannerValidationError, match="报告月份被修改"):
        asyncio.run(planner.plan(REQUEST_TEXT))
