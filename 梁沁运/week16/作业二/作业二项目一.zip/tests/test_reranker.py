"""Reranker 离线单元测试（Mock HTTP 客户端，不访问真实 API）。"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

import httpx
import pytest

from agents.planner import SearchPlan, SearchQuery
from agents.reader import PageMetadata, ReaderOutput, ReadResult
from agents.reranker import (
    DEFAULT_TOP_K,
    Reranker,
    RerankerError,
    build_document_text,
    build_rerank_endpoint,
)
from config.settings import ConfigurationError, Settings

FAKE_KEY = "test-siliconflow-key"
MODEL = "BAAI/bge-reranker-v2-m3"
TIME_RANGE = "2026年10月1日-2026年10月31日"


def make_plan(query_count: int = 2) -> SearchPlan:
    return SearchPlan(
        company="中国神华",
        report_month="2026-10",
        queries=[
            SearchQuery(
                query_id=f"q{i}",
                topic=f"主题{i}",
                search_query=f"搜索语句{i}",
                time_range=TIME_RANGE,
            )
            for i in range(1, query_count + 1)
        ],
    )


def make_page(
    url: str,
    title: str = "标题",
    content: str = "正文",
    status: str = "success",
    source_ids: list[str] | None = None,
) -> ReadResult:
    return ReadResult(
        url=url,
        title=title,
        status=status,  # type: ignore[arg-type]
        content=content,
        metadata=PageMetadata(),
        source_query_ids=source_ids or ["q1"],
    )


def single_query_context() -> list[SearchQuery]:
    """单个主题的 Query 上下文（用于只观察单次调用的测试）。

    SearchPlan 本身要求 2～5 条 Query，但 ReaderOutput 的 query_context
    是普通列表，Reader 在 Query 全部失败时也可能只带 1 条。
    """
    return [make_plan(2).queries[0]]


def make_reader_output(pages: list[ReadResult], query_count: int = 2) -> ReaderOutput:
    context = single_query_context() if query_count == 1 else list(make_plan(query_count).queries)
    return ReaderOutput(
        company="中国神华",
        report_month="2026-10",
        query_context=context,
        pages=pages,
    )


def make_settings(timeout: float = 5.0) -> Settings:
    return Settings(
        siliconflow_api_key=FAKE_KEY,
        siliconflow_base_url="https://api.siliconflow.cn/v1",
        bge_reranker_model=MODEL,
        request_timeout_seconds=timeout,
    )


def rerank_payload(scores: list[float], with_documents: bool = False) -> dict[str, Any]:
    results = [{"index": index, "relevance_score": score} for index, score in enumerate(scores)]
    if with_documents:
        for item in results:
            item["document"] = {"text": f"doc-{item['index']}"}
    return {"id": "req-test", "results": results, "meta": {"tokens": {"input_tokens": 10}}}


def make_client(handler: Callable[[httpx.Request], Any]) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


def run(reranker: Reranker, reader_output: ReaderOutput, plan: SearchPlan):
    return asyncio.run(reranker.rerank(reader_output, plan))


# 1. 正常 Reranker API 调用
def test_normal_rerank() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([0.2, 0.9, 0.5]))

    pages = [
        make_page("https://example.com/a", content="A"),
        make_page("https://example.com/b", content="B"),
        make_page("https://example.com/c", content="C"),
    ]
    result = run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output(pages), make_plan())

    assert len(result.selected) == 3
    assert result.company == "中国神华"
    assert result.report_month == "2026-10"
    assert len(result.query_context) == 2


# 2. 正确的 Endpoint 和请求结构
def test_request_endpoint_and_payload() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=rerank_payload([0.5]))

    pages = [make_page("https://example.com/a", title="标题A", content="# 正文A")]
    run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output(pages, query_count=1), make_plan(2))

    assert len(received) == 1
    request = received[0]
    assert request.method == "POST"
    assert str(request.url) == "https://api.siliconflow.cn/v1/rerank"
    assert request.headers["authorization"] == f"Bearer {FAKE_KEY}"
    assert request.headers["content-type"] == "application/json"

    body = json.loads(request.content)
    assert body["query"] == "主题1"
    assert body["documents"] == ["标题A\n\n# 正文A"]
    assert body["return_documents"] is False
    assert body["top_n"] == 1


# 3. 正确的模型 ID
def test_model_from_settings() -> None:
    received: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        received.append(request)
        return httpx.Response(200, json=rerank_payload([0.5]))

    run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output([make_page("https://example.com/a")], query_count=1),
        make_plan(2),
    )

    assert json.loads(received[0].content)["model"] == MODEL
    assert MODEL == "BAAI/bge-reranker-v2-m3"


# 4. API Key 不出现在日志中
def test_api_key_not_logged(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.INFO)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([0.5]))

    run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output([make_page("https://example.com/a")]), make_plan())
    assert FAKE_KEY not in caplog.text


# 5. 根据分数降序排列
def test_sorted_by_score_desc() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([0.1, 0.8, 0.4, 0.95]))

    pages = [make_page(f"https://example.com/{name}") for name in ("a", "b", "c", "d")]
    result = run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output(pages, query_count=1),
        make_plan(2),
    )

    scores = [page.relevance_score for page in result.selected]
    assert scores == sorted(scores, reverse=True)
    assert result.selected[0].url == "https://example.com/d"
    assert result.selected[1].url == "https://example.com/b"


# 6. 只保留 Top 5
def test_keeps_only_top_5() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([i / 10 for i in range(8)]))

    pages = [make_page(f"https://example.com/{i}") for i in range(8)]
    result = run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output(pages, query_count=1),
        make_plan(2),
    )

    assert DEFAULT_TOP_K == 5
    assert len(result.selected) == 5
    assert {page.url for page in result.selected} == {f"https://example.com/{i}" for i in range(3, 8)}


# 7. 有效网页不足 5 条时全部保留
def test_fewer_than_top_k_keeps_all() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([0.3, 0.7]))

    pages = [make_page("https://example.com/a"), make_page("https://example.com/b")]
    result = run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output(pages, query_count=1),
        make_plan(2),
    )

    assert len(result.selected) == 2


# 8. 空正文和失败网页被过滤
def test_invalid_pages_filtered() -> None:
    documents_received: list[list[str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        documents_received.append(json.loads(request.content)["documents"])
        return httpx.Response(200, json=rerank_payload([0.5]))

    pages = [
        make_page("https://example.com/good"),
        make_page("https://example.com/empty", content="   ", status="empty"),
        make_page("https://example.com/error", status="error"),
    ]
    result = run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output(pages, query_count=1),
        make_plan(2),
    )

    assert documents_received[0] == ["标题\n\n正文"]
    assert len(result.selected) == 1
    assert result.selected[0].url == "https://example.com/good"


# 9. 保留 URL、标题、正文和来源 Query ID
def test_fields_preserved() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=rerank_payload([0.88]))

    page = make_page(
        "https://example.com/article",
        title="中国神华 ESG 动态",
        content="# 标题\n\n完整正文内容",
        source_ids=["q1", "q3"],
    )
    result = run(
        Reranker(settings=make_settings(), client=make_client(handler)),
        make_reader_output([page], query_count=1),
        make_plan(2),
    )

    selected = result.selected[0]
    assert selected.url == "https://example.com/article"
    assert selected.title == "中国神华 ESG 动态"
    assert selected.content == "# 标题\n\n完整正文内容"
    assert selected.source_query_ids == ["q1", "q3"]
    assert selected.relevance_score == pytest.approx(0.88)
    assert selected.topic_scores == {"主题1": pytest.approx(0.88)}


# 10. API 错误时抛出明确异常
def test_api_error_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"code": 20012, "message": "invalid token"})

    with pytest.raises(RerankerError, match="HTTP 401"):
        run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output([make_page("https://example.com/a")]), make_plan())


def test_missing_results_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"code": 20012, "message": "bad request"})

    with pytest.raises(RerankerError, match="缺少 results"):
        run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output([make_page("https://example.com/a")]), make_plan())


def test_network_error_raises() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection failed", request=request)

    with pytest.raises(RerankerError, match="Reranker 请求异常"):
        run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output([make_page("https://example.com/a")]), make_plan())


# 其他行为：多主题分别评分并合并
def test_multiple_topics_scored_and_merged() -> None:
    calls: list[str] = []
    score_map = {"主题1": [0.9, 0.2], "主题2": [0.3, 0.85]}

    def handler(request: httpx.Request) -> httpx.Response:
        query = json.loads(request.content)["query"]
        calls.append(query)
        return httpx.Response(200, json=rerank_payload(score_map[query]))

    pages = [make_page("https://example.com/a"), make_page("https://example.com/b")]
    result = run(Reranker(settings=make_settings(), client=make_client(handler)), make_reader_output(pages), make_plan())

    assert sorted(calls) == ["主题1", "主题2"]
    assert len(result.selected) == 2
    by_url = {page.url: page for page in result.selected}
    assert by_url["https://example.com/a"].relevance_score == pytest.approx(0.9)
    assert by_url["https://example.com/a"].topic_scores == {"主题1": pytest.approx(0.9), "主题2": pytest.approx(0.3)}
    assert by_url["https://example.com/b"].topic_scores["主题2"] == pytest.approx(0.85)


def test_no_valid_pages_returns_empty_without_api_call() -> None:
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200, json=rerank_payload([0.5]))

    pages = [make_page("https://example.com/a", status="error"), make_page("https://example.com/b", content="")]
    # 即使没有配置 Key 也不应调用 API
    result = run(Reranker(settings=Settings(), client=make_client(handler)), make_reader_output(pages), make_plan())

    assert calls == 0
    assert result.selected == []
    assert result.company == "中国神华"


def test_missing_settings_raises_clearly() -> None:
    with pytest.raises(ConfigurationError, match="SILICONFLOW_API_KEY"):
        run(
            Reranker(
                settings=Settings(bge_reranker_model=MODEL),
                client=make_client(lambda request: httpx.Response(200, json=rerank_payload([0.5]))),
            ),
            make_reader_output([make_page("https://example.com/a")]),
            make_plan(),
        )


def test_build_document_text_truncates_long_content() -> None:
    page = make_page("https://example.com/a", title="标题", content="x" * 10000)
    text = build_document_text(page)
    assert len(text) == 4000
    assert text.startswith("标题")


@pytest.mark.parametrize(
    ("base_url", "expected"),
    [
        ("https://api.siliconflow.cn/v1", "https://api.siliconflow.cn/v1/rerank"),
        ("https://api.siliconflow.cn/v1/", "https://api.siliconflow.cn/v1/rerank"),
        ("https://api.siliconflow.cn/v1/rerank", "https://api.siliconflow.cn/v1/rerank"),
    ],
)
def test_build_rerank_endpoint(base_url: str, expected: str) -> None:
    assert build_rerank_endpoint(base_url) == expected
