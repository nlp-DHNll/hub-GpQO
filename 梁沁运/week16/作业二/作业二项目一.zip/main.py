"""ESG Monthly Report Agent 主流程。

Planner → Researcher → Reader → Reranker → Writer → 保存 Markdown 报告。
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import re
import sys
from dataclasses import replace
from pathlib import Path

from agents.planner import Planner
from agents.reader import Reader
from agents.reranker import Reranker
from agents.researcher import Researcher
from agents.writer import Writer, ReportOutput
from config.settings import PROJECT_ROOT, Settings, get_settings

MONTH_PATTERN = re.compile(r"^(?P<year>\d{4})[-/年](?P<month>\d{1,2})月?$")
INVALID_FILENAME_CHARS = re.compile(r'[\\/:*?"<>|\s]+')
# 5 篇长文生成报告时 30 秒不够；仅本次运行放宽 Writer 超时，不改 .env 或 settings.py。
WRITER_TIMEOUT_SECONDS = 180.0


class PipelineError(RuntimeError):
    """主流程某一阶段失败。"""

    def __init__(self, stage: str) -> None:
        super().__init__(stage)
        self.stage = stage


def parse_month(value: str) -> tuple[str, int, int]:
    """把 2026-10 / 2026/10 / 2026年10月 统一为 (2026-10, 2026, 10)。"""
    match = MONTH_PATTERN.match(value.strip())
    if match is None:
        raise ValueError("报告月份格式应为 YYYY-MM，例如 2026-10")
    year = int(match.group("year"))
    month = int(match.group("month"))
    if not 1 <= month <= 12:
        raise ValueError(f"报告月份不合法：{year}年{month}月")
    return f"{year:04d}-{month:02d}", year, month


def build_user_request(company: str, year: int, month: int) -> str:
    return f"请帮我生成{company} {year}年{month}月 ESG 月报。"


def safe_filename_part(value: str) -> str:
    cleaned = INVALID_FILENAME_CHARS.sub("_", value.strip())
    return cleaned.strip("._") or "企业"


def save_report(report: ReportOutput, company: str, month: str, settings: Settings) -> Path:
    output_dir = settings.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{safe_filename_part(company)}_ESG月报_{month}.md"
    path = output_dir / filename
    path.write_text(report.markdown.rstrip() + "\n", encoding="utf-8")
    return path


async def run_stage(stage: str, coro):
    """执行单个阶段；失败时打印节点和原因。"""
    try:
        return await coro
    except Exception as exc:
        print(f"[失败] {stage} 阶段失败：{exc}", file=sys.stderr)
        raise PipelineError(stage) from exc


async def run_pipeline(company: str, month: str) -> Path:
    settings = get_settings()
    report_month, year, month_number = parse_month(month)
    user_request = build_user_request(company, year, month_number)

    print("ESG Monthly Report Agent")
    print(f"企业：{company}")
    print(f"报告月份：{year}年{month_number}月")
    print()

    print("正在生成搜索计划……")
    plan = await run_stage("Planner", Planner(settings=settings).plan(user_request))
    print(f"  完成：生成 {len(plan.queries)} 条搜索 Query")

    print("正在采集网页……")
    research = await run_stage("Researcher", Researcher(settings=settings).research(plan))
    failed_queries = sum(1 for item in research.query_results if item.status == "error")
    print(
        f"  完成：获得 {len(research.results)} 条唯一搜索结果"
        f"（失败 Query {failed_queries} 条）"
    )

    print("正在读取网页正文……")
    reader_output = await run_stage("Reader", Reader(settings=settings).read(research))
    success_pages = sum(1 for page in reader_output.pages if page.status == "success")
    print(f"  完成：成功读取 {success_pages}/{len(reader_output.pages)} 个网页")

    print("正在进行相关性排序……")
    rerank_result = await run_stage(
        "Reranker", Reranker(settings=settings).rerank(reader_output, plan)
    )
    print(f"  完成：精排入选 {len(rerank_result.selected)} 条网页")

    print("正在生成 ESG 月报……")
    writer_settings = replace(settings, request_timeout_seconds=WRITER_TIMEOUT_SECONDS)
    report = await run_stage("Writer", Writer(settings=writer_settings).write(rerank_result))
    print(f"  完成：报告 {len(report.markdown)} 字，引用来源 {len(report.cited_source_ids)} 条")

    path = save_report(report, company, report_month, settings)
    try:
        display_path = path.relative_to(PROJECT_ROOT)
    except ValueError:
        display_path = path
    print(f"报告已保存：{display_path}")

    print()
    print("—— 流程完成 ——")
    print(
        f"搜索结果 {len(research.results)} 条；"
        f"成功读取网页 {success_pages} 个；"
        f"精排入选 {len(rerank_result.selected)} 条"
    )
    return path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="生成指定企业、指定月份的 ESG 月报（Markdown）。",
    )
    parser.add_argument("--company", help="企业名称，例如：中国神华")
    parser.add_argument("--month", help="报告月份，例如：2026-10")
    return parser


def print_usage() -> None:
    print("用法：")
    print("  python main.py --company 中国神华 --month 2026-10")
    print()
    print("参数：")
    print("  --company  企业名称")
    print("  --month    报告月份，格式 YYYY-MM，例如 2026-10")


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.company or not args.month:
        print_usage()
        return 2

    company = args.company.strip()
    if not company:
        print_usage()
        return 2

    try:
        parse_month(args.month)
    except ValueError as exc:
        print(f"[参数错误] {exc}")
        print_usage()
        return 2

    try:
        asyncio.run(run_pipeline(company, args.month))
    except PipelineError as exc:
        print(f"流程在 {exc.stage} 阶段终止，未生成报告。", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n已取消。", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"[失败] 未预期错误：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
