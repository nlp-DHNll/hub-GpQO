# CLAUDE.md — ESG Monthly Report Agent

## 1. 项目介绍

项目名称：ESG Monthly Report Agent

项目类型：课程作业——Skill / Agent 开发

开发目标：

构建一个 ESG 月报生成 Agent，能够自主搜索互联网信息、筛选有效信息、阅读网页、提取关键信息，最终自动生成结构完整、内容可靠、来源可追溯的 ESG 月报。

本项目以中国神华为案例。

开发原则：

- 优先完成课程作业的基本要求。
- 保持代码简单、清晰、容易理解。
- 不进行不必要的架构扩展。
- 优先使用 Python Script 控制确定性流程。
- 使用 Agent 处理需要语言理解和内容生成的任务。
- 所有报告内容必须有真实信息来源。
- 不允许模型脱离搜索材料自由编造内容。

## 2. 开发环境

- IDE：PyCharm
- Python 环境：Miniconda3
- Python：优先使用当前已配置的 Python 解释器。
- 不要擅自创建新的 Conda 环境。
- 不要擅自修改现有环境配置。
- API Key 通过 `.env` 文件读取。
- `.env` 不允许提交到代码仓库。

开发前先检查现有环境和依赖，避免重复安装。

## 3. 技术架构

采用简单的五节点工作流：

Planner → Researcher → Reader → Reranker → Writer

### 节点一：Planner（任务拆解）

模型：硅基流动 DeepSeek 4.1 Flash。

功能：

接收用户需求，例如：

"请生成中国神华 2026 年 10 月 ESG 月报。"

将宏观需求拆解成 2～5 个具体搜索 Query。

搜索内容至少覆盖：

1. ESG 政策、评级、标准等相关动态。
2. 客户所属行业的新闻动态和最佳实践。
3. 中国神华自身的 ESG 相关动态，以及对企业的影响和改进建议所需的信息。

要求：

- Query 必须具体。
- 不允许只生成宽泛关键词。
- 输出结构化 JSON。
- 使用 Python 校验 Query 数量和格式。
- 不允许模型自行改变用户指定的报告月份。

### 节点二：Researcher（信息搜索）

工具：DeepSeek Web Search API。

功能：

- 接收 Planner 输出的 Query 列表。
- 逐条调用搜索 API。
- 获取标题、摘要、网页 URL 等信息。
- 保留搜索原始 JSON。
- 使用 Python asyncio 控制并发。
- 最大并发数为 3。

要求：

- 实现超时和失败重试。
- 记录搜索失败信息。
- 不允许虚构搜索结果。
- 不允许丢失原始 URL。

### 节点三：Reader（网页读取）

工具：Jina Reader API。

功能：

- 遍历搜索结果中的有效 URL。
- 调用 Jina Reader 获取网页正文。
- 获取 Markdown 格式内容。
- 保存网页标题、原始 URL 和正文。

要求：

- 优先保留 Markdown 原文。
- 不需要复杂格式转换。
- 对读取失败的网页进行记录。
- 避免重复读取相同 URL。

### 节点四：Reranker（精排降噪）

模型：硅基流动 BGE-reranker-v2-m3。

功能：

- 将用户原始需求作为 Query。
- 将 Reader 获取的网页内容作为 Documents。
- 调用 Reranker 计算相关性分数。
- 按照相关性分数降序排列。
- 保留 Top 3～5 个高质量文本块。

要求：

- 使用 Python 完成排序和筛选。
- 保留相关性分数。
- 保留来源 URL。
- 不允许丢失来源信息。
- 如果有效内容不足，不得通过重复内容凑数。

### 节点五：Writer（报告生成）

模型：硅基流动 DeepSeek 4.1 Flash。

功能：

将 Reranker 筛选后的内容交给模型，生成最终 ESG 月报。

报告至少包含以下三个部分：

#### 第一部分：ESG 政策、评级和标准动态

汇总过去一个月 ESG 相关政策、评级、标准及监管动态。

#### 第二部分：行业新闻动态与最佳实践

汇总中国神华所属行业相关的 ESG 新闻、行业动态和优秀实践。

#### 第三部分：中国神华 ESG 动态及建议

汇总中国神华自身的 ESG 相关动态，分析其影响，并参考优秀企业实践提出 ESG 改进建议。

报告要求：

- 使用 Markdown 格式。
- 标题层级清晰。
- 内容有逻辑。
- 避免重复。
- 区分事实、分析和建议。
- 重要事实必须有来源 URL。
- 不允许编造企业动态。
- 没有搜索到的信息必须明确说明。
- 建议必须基于前面收集到的材料。

最终生成 Markdown 文件，保存到 output 目录。

## 4. Script 开发原则

Script 是本项目的重要组成部分，用于约束模型行为。

以下工作必须优先使用 Python 实现：

1. Query 数量检查。
2. JSON 格式校验。
3. 搜索任务并发控制。
4. API 超时和重试。
5. URL 去重。
6. Reranker 分数排序。
7. Top 3～5 内容筛选。
8. 报告结构检查。
9. Markdown 文件保存。

不要让大模型执行可以由确定性 Python 代码完成的工作。

## 5. 项目目录结构

采用简单模块化结构：

```text
ESG_Monthly_Report_Agent/
│
├── CLAUDE.md
├── main.py
├── config/
│   └── settings.py
│
├── agents/
│   ├── planner.py
│   ├── researcher.py
│   ├── reader.py
│   ├── reranker.py
│   └── writer.py
│
├── services/
│   ├── search_service.py
│   ├── reader_service.py
│   └── rerank_service.py
│
├── scripts/
│   └── report_validator.py
│
├── prompts/
│   ├── planner_prompt.txt
│   └── writer_prompt.txt
│
├── output/
│
├── tests/
│
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

可以根据实际开发需要调整，但不要无故增加复杂目录。

## 6. API 配置

所有 API 配置集中管理。

至少包括：

- SILICONFLOW_API_KEY
- SILICONFLOW_BASE_URL
- DEEPSEEK_MODEL
- DEEPSEEK_SEARCH_API_KEY
- DEEPSEEK_SEARCH_BASE_URL
- JINA_API_KEY
- BGE_RERANKER_MODEL

具体模型 ID 和 API 地址必须以服务商实际提供的接口文档为准，不得自行猜测。

禁止将 API Key 写入 Python 源代码。

## 7. 开发质量要求

1. 使用 Python 类型注解。
2. 统一异常处理。
3. 使用 logging 记录执行日志。
4. 核心模块编写必要的测试。
5. 各节点输入输出尽量使用明确的数据结构。
6. 每个节点可以独立测试。
7. 外部 API 暂时不可用时，使用 Mock 数据进行流程测试，但必须明确标记为测试数据。
8. 不允许使用 Mock 数据生成正式报告。
9. 不允许用 TODO 或 pass 代替核心功能。
10. 不要擅自引入数据库、Docker、复杂前端或不必要的 Agent。

## 8. Agent 与 Script 的边界

Agent 负责：

- 理解用户需求。
- 拆解搜索任务。
- 理解网页内容。
- 提取有效信息。
- 分析材料。
- 生成报告。

Python Script 负责：

- 流程控制。
- 数据格式检查。
- 并发管理。
- 数据去重。
- 相关性排序。
- 内容数量限制。
- 文件保存。
- 结果验证。

Agent 不得绕过 Script 直接决定最终数据筛选规则。

## 9. 开发方式

必须采用分阶段开发，不允许一次性生成整个项目。

每次只执行用户指定的开发任务。

每个阶段完成后：

1. 汇报创建和修改的文件。
2. 说明实现的功能。
3. 运行必要的测试。
4. 报告测试结果。
5. 列出尚未解决的问题。
6. 停止并等待下一条指令。

不得擅自开始下一阶段。

## 10. 最终验收标准

项目必须能够：

1. 接收用户指定的报告月份和企业名称。
2. 自动拆解搜索 Query。
3. 调用 DeepSeek Web Search 获取真实搜索结果。
4. 调用 Jina Reader 获取网页 Markdown。
5. 调用 BGE Reranker 进行相关性排序。
6. 自动保留 Top 3～5 有效材料。
7. 调用 DeepSeek 生成 ESG 月报。
8. 输出结构清晰的 Markdown 报告。
9. 提供真实、可点击的信息来源。
10. 具备必要的 Script 控制和异常处理。

最终目标是：完成一个能够真实运行、能够展示完整工作流、能够生成高质量 ESG 月报的课程作业项目。